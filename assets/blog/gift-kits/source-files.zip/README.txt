Choose Checks Before Releasing Gift Kits — revised source materials

The main PDF is the exact supplied 22-page requirements-and-views revision,
dated 13 November 2026. The website retains the article URL and original
12 November publication date, with a 13 November update date. Its expanded
narrative, executive summary, five learning steps, requirements trace R1–R6
(R3 not applied), reviewer views V1–V6, 27 tables, eight figures, and three
formulas follow the revised PDF. Print page references become web links.
Body wording is retained with paragraph wrapping, typographical ligatures,
and print-only references adapted for the web. Formula notation is native
MathML, with spoken labels and plain-text annotations.

Figures 1, 2, 3, 7 and 8 are native SVG adaptations. Figure 2 is a schematic
dependency view, with unestimated work durations and an axis that is not a
minute scale. Figure 7 reconstructs model readiness outputs. Figure 8 is the
new single general ontology; the case-equivalence table is separate HTML.
cover.svg remains the existing editorial cover illustration.

Figures 4, 5 and 6 are PNG crops of the revised PDF's embedded JPEG captures,
using its exact normalized clipping rectangles. original-screenshots/ retains
the JPEG streams. screenshot-extraction.json records source/crop coordinates,
dimensions, and SHA-256 hashes. No report content was redrawn or changed.

archived-captures-2026-11-12/ retains the prior PDF and original app captures,
including the input screen, original detailed timing chart, and full simulated
outcomes screenshot mentioned in the revision. It is a clearly labeled archive;
the main web article uses the revised source PDF and figure numbering.

The input recipe and calculation checks distinguish declared model premises,
app previews and fictional business records. SCOPE-01 records accepted scope;
CHECK-01 starts open. LOG-01 and the physical outcome are fictional examples.
The source demo retains no physical run. The model-fit result supports one
correction instruction among the supplied investigations; it grants no authority
and does not settle the unestimated whole-dispatch schedule.

Diagnostic credits are resource units. Four credits price modeled checks on
the longer TARGETED path. Other scheduled work has no separate resource price;
replacement printing and revised-card rehearsal are outside that figure.
USD 100 is a fictional printing quote/invoice subtotal, USD 6,000 is campaign
allocation, and USD 960 is conditional handling exposure, not a measured saving
or calculated return. Tax, delivery and payment status are outside the invoice
excerpt. Direct alternatives lacking price/readiness inputs remain unranked.

The Eleventy/Nunjucks HTML template uses the website's shared reader, filters,
MathML styles, metadata, contents navigation, and follow-up links. Scripts run
from the website checkout: generate-gift-kit-figures.py builds native SVGs;
extract-gift-kit-screenshots.py uses macOS Swift ImageIO with the supplied PDF;
package-gift-kit-source.py verifies provenance/arithmetic and rebuilds this ZIP.
