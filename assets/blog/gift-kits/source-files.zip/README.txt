Choose Checks Before Releasing Gift Kits — source materials

The PDF is the supplied essay dated 12 November 2026. Its original wording,
eight section headings, seven figures, five tables, and case limitations are
preserved in the web post, with print wrapping and one page reference adapted.

Figures 1–2 are native SVG adaptations. Figure 2 includes the previous post's
original ontology unchanged. cover.svg is a separate editorial illustration.
Figures 3–7 are lossless PNG crops of the PDF's embedded JPEG captures, using
the same image clipping rectangles as the PDF. original-screenshots/ retains
those original JPEG streams; screenshot-extraction.json records their hashes
and crop coordinates. No report findings were redrawn or changed.

The input recipe and calculation checks document the PDF's fictional premises,
calculated timing, and simulated example; they are not an app import or a
physical evidence log. USD 960 is potential handling exposure, not a measured
or app-calculated saving. The printer cutoff applies to the correction choice;
production and the story's replacement-insert rehearsal follow afterward.

The HTML is an Eleventy/Nunjucks source template. The website supplies the
shared reader, cover metadata, follow-up links, and URL filters. The included scripts run in the website checkout. Diagrams use the supplied
original-ontology.svg (the previous article’s unchanged ontology). Screenshot
extraction uses macOS Swift ImageIO and the original PDF.
