"""Extract the supplied PDF's five screenshot regions without changing findings.

The PDF embeds JPEG captures and clips each to a normalized rectangle. Keep the
original streams and export those same visible regions as lossless PNGs. ImageIO
requires macOS; deployed sites use the checked-in assets without running this.
"""

import hashlib
import json
import math
from pathlib import Path
import re
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent.parent
ASSETS = ROOT / 'assets/blog/gift-kits'
SOURCE = ASSETS / 'choose-checks-before-releasing-gift-kits.pdf'
CLIPS = [
    (3, 4, 90, (.208, .027, .737, .455)),
    (4, 5, 94, (.215, .167, .662, .433)),
    (5, 6, 98, (.209, .230, .743, .332)),
    (6, 7, 102, (.211, .173, .733, .503)),
    (7, 8, 106, (.096, .157, .785, .714)),
]
pdf = SOURCE.read_bytes()
objects = {int(match[1]): match[2] for match in re.finditer(rb'(\d+)\s+0\s+obj\b([\s\S]*?)endobj', pdf)}
originals = ASSETS / 'original-screenshots'
originals.mkdir(exist_ok=True)
entries = []
for number, page, object_id, clip in CLIPS:
    obj = objects[object_id]
    header, stream = obj.split(b'stream', 1)
    assert b'/Subtype/Image' in header and b'/Filter/DCTDecode' in header
    width = int(re.search(rb'/Width\s+(\d+)', header)[1])
    height = int(re.search(rb'/Height\s+(\d+)', header)[1])
    length = int(re.search(rb'/Length\s+(\d+)', header)[1])
    stream = stream[2:] if stream.startswith(b'\r\n') else stream[1:]
    jpeg = stream[:length]
    assert jpeg.startswith(b'\xff\xd8') and jpeg.endswith(b'\xff\xd9')
    original = originals / f'figure-{number:02}.jpg'
    original.write_bytes(jpeg)
    x, y, w, h = clip
    left, top = math.floor(x * width), math.floor((1 - y - h) * height)
    right, bottom = math.ceil((x + w) * width), math.ceil((1 - y) * height)
    entries.append({
        'number': number, 'pdf_page': page, 'pdf_object': object_id,
        'original': str(original.relative_to(ASSETS)),
        'original_width': width, 'original_height': height,
        'original_sha256': hashlib.sha256(jpeg).hexdigest(),
        'pdf_clip': list(clip), 'crop_pixels': [left, top, right - left, bottom - top],
        'file': f'figure-{number:02}.png', 'width': right - left, 'height': bottom - top,
    })

swift = '''import Foundation
import ImageIO
import CoreGraphics
let entries = try JSONSerialization.jsonObject(with: Data(contentsOf: URL(fileURLWithPath: CommandLine.arguments[1]))) as! [[String:Any]]
let base = URL(fileURLWithPath: CommandLine.arguments[2], isDirectory: true)
for entry in entries {
 let input = base.appendingPathComponent(entry["original"] as! String)
 guard let source = CGImageSourceCreateWithURL(input as CFURL, nil), let image = CGImageSourceCreateImageAtIndex(source, 0, nil) else { fatalError("Cannot decode original") }
 let crop = entry["crop_pixels"] as! [Int]
 guard let clipped = image.cropping(to: CGRect(x: crop[0], y: crop[1], width: crop[2], height: crop[3])) else { fatalError("Cannot crop") }
 let output = base.appendingPathComponent(entry["file"] as! String)
 guard let destination = CGImageDestinationCreateWithURL(output as CFURL, "public.png" as CFString, 1, nil) else { fatalError("Cannot create PNG") }
 CGImageDestinationAddImage(destination, clipped, nil)
 guard CGImageDestinationFinalize(destination) else { fatalError("Cannot write PNG") }
}
'''
with tempfile.TemporaryDirectory(prefix='gift-kit-extraction-') as temporary:
    folder = Path(temporary)
    program, recipe = folder / 'extract.swift', folder / 'clips.json'
    program.write_text(swift)
    recipe.write_text(json.dumps(entries))
    subprocess.run(['swift', '-module-cache-path', '/private/tmp/hermod-pdf-module-cache', str(program), str(recipe), str(ASSETS)], check=True)

for entry in entries:
    entry['png_sha256'] = hashlib.sha256((ASSETS / entry['file']).read_bytes()).hexdigest()
(ASSETS / 'screenshot-extraction.json').write_text(json.dumps({
    'source_pdf': SOURCE.name,
    'source_pdf_sha256': hashlib.sha256(pdf).hexdigest(),
    'method': 'Original embedded JPEG streams; PNG crops match the normalized clipping rectangles in the supplied PDF. No report content is changed.',
    'screenshots': entries,
}, indent=2) + '\n')
print('Extracted five original screenshots and matching PDF crops.')
