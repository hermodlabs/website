"""Rebuild the two native SVG diagrams while retaining the original marble ontology."""
from html import escape
from pathlib import Path
import re
ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'assets/blog/gift-kits'
OUT.mkdir(parents=True, exist_ok=True)
NAVY='#193743'; TEAL='#177681'; MUTED='#536873'; LINE='#d3dfe5'
def t(x,y,v,size=20,color=NAVY,weight=400,anchor='start'):
 return f'<text x="{x}" y="{y}" font-size="{size}" fill="{color}" font-weight="{weight}" text-anchor="{anchor}">{escape(v)}</text>'
def lines(x,y,vs,size=20,leading=26,**kw):
 return ''.join(t(x,y+i*leading,v,size=size,**kw) for i,v in enumerate(vs))
def rect(x,y,w,h,fill='white'):
 return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="8" fill="{fill}" stroke="{LINE}" stroke-width="1.5"/>'
def arrow(d):
 return f'<path d="{d}" fill="none" stroke="{MUTED}" stroke-width="2" stroke-linejoin="round" marker-end="url(#gift-journey-arrow)"/>'
marker='<defs><marker id="gift-journey-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="context-stroke"/></marker></defs>'
b=t(24,43,'What is in the gift-kit journey?',29,weight=700)
nodes=[
(24,115,'Gift kit',"One recipient's package",'Part of a 120-kit campaign','white'),
(379,115,'Printed insert','QR code on the card','Print may be unreadable','#edf5f5'),
(734,115,'Encoded link','Address stored in the QR','May point to a wrong page','#edf5f5'),
(24,435,'Matching artwork','Source used for this print','Available for inspection','white'),
(379,435,'Checkout',"The intended customer's access",'May allow or block an order','#edf5f5'),
(734,435,'Approved page','The intended preorder page','Reference for this campaign','white'),
]
for x,y,name,d1,d2,fill in nodes:
 b+=rect(x,y,282,145,fill)
 b+=t(x+17,y+38,name,23,weight=700)
 b+=t(x+17,y+84,d1,17.5,MUTED)
 b+=t(x+17,y+117,d2,17.5,TEAL)
b+=arrow('M 314 188 H 368')+t(342,157,'contains',17,MUTED,anchor='middle')
b+=arrow('M 669 188 H 723')+t(696,157,'encodes',17,MUTED,anchor='middle')
b+=arrow('M 875 268 V 424')+lines(896,338,['should','open'],size=18,leading=24,color=MUTED)
b+=arrow('M 725 508 H 672')+t(699,477,'leads to',17,MUTED,anchor='middle')
b+=arrow('M 165 427 V 349 H 520 V 270')+t(342,324,'is used to print',18,MUTED,anchor='middle')
b+=t(24,643,'Print, link and checkout faults can exist together.',21,TEAL)
svg=f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1040 678" width="1040" height="678" role="img" aria-labelledby="gift-journey-title gift-journey-desc">
<title id="gift-journey-title">What is in the gift-kit journey?</title>
<desc id="gift-journey-desc">A gift kit is one recipient's package in a 120-kit campaign. It contains a printed insert with a QR code that may be unreadable. The insert encodes a link, the address stored in the QR, which may point to a wrong page. The encoded link should open the approved page: the intended preorder page and campaign reference. The approved page leads to checkout, the intended customer's access, which may allow or block an order. Matching artwork is the source used for this print, is available for inspection, and is used to print the insert. Print, link and checkout faults can exist together.</desc>
{marker}<rect width="1040" height="678" fill="white"/><g font-family="Helvetica, Arial, sans-serif">{b}</g>
</svg>
'''
(OUT/'figure-01.svg').write_text(svg)
# Include the complete original SVG byte-for-byte, then reuse its geometry for the case.
original=(ROOT / 'assets/blog/question-worth/figure-02.svg').read_text()
body=re.search(r'(<g font-family=.*</g>)',original,re.S).group(1)
replacements={
'One structure for the four versions':"The same structure in Leah's gift-kit decision",
'Bags, marbles, membership,':'120 kits; insert, artwork,',
'allocation rule':'page and checkout',
'Possible explanations;':'Print, link and checkout faults;',
'probabilities when given':'may coexist',
'Marble identity, bag identity,':'Which corrections does',
'or payout tier':'the evidence justify?',
'Comparison, possible results,':'Read insert; try checkout;',
'error premise':'inspect artwork',
'Available choices and':'Correct, rehearse or hold;',
'how they are valued':'launch, delay, rework',
'Cost, resources, availability,':'Reviewer, access, 15 credits,',
'deadline':'3:00 p.m. cutoff',
'Facts and requirements change between cases;':'Familiar relationships guide the investigation;',
'these concept families can remain the same.':'this case supplies its own facts and rules.'
}
for before,after in replacements.items():
 assert before in body,before
 body=body.replace(before,after)
svg=f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1040 1607" width="1040" height="1607" role="img" aria-labelledby="gift-ontology-title gift-ontology-desc">
<title id="gift-ontology-title">The same decision pattern in both cases</title>
<desc id="gift-ontology-desc">Two diagrams share six concept families and their relationships. The top is the original ontology from What Is a Question Worth?, embedded unchanged. The bottom applies it to Leah's gift-kit decision. Physical situation: 120 kits, insert, artwork, page and checkout. Uncertainty: print, link and checkout faults that may coexist. Question and evidence target: which corrections does the evidence justify? Experiments and observations: read insert, try checkout, inspect artwork. Actions and consequences: correct, rehearse or hold; launch, delay, rework. Execution conditions: reviewer, access, 15 credits, 3:00 p.m. cutoff. In each diagram, physical situation defines uncertainty cases; uncertainty predicts results; the question sets sufficiency for experiments; observations support action; execution conditions limit tests and choice.</desc>
<rect width="1040" height="1607" fill="white"/>
{original}
<path d="M24 799H1016" fill="none" stroke="#e4e8ec" stroke-width="1.5"/>
<g transform="translate(0,826)">{body}</g>
</svg>
'''
(OUT/'figure-02.svg').write_text(svg)
assert original in svg
print('Wrote gift-kit diagrams. Original question-worth figure-02.svg is embedded byte-for-byte unchanged.')
