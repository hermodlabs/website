"""Rebuild the revised gift-kit essay's five native SVG figures.

Geometry and labels adapt the supplied requirements-trace PDF (13 Nov 2026).
Figure 2 is a schematic dependency view: its widths are not durations.
Figure 7 uses model outputs, not observations of a physical run.
"""
from html import escape
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'assets/blog/gift-kits'
OUT.mkdir(parents=True, exist_ok=True)
NAVY = '#193743'
TEAL = '#177681'
MUTED = '#536873'
LINE = '#d3dfe5'


def t(x, y, value, size=20, color=NAVY, weight=400, anchor='start'):
    return f'<text x="{x}" y="{y}" font-size="{size}" fill="{color}" font-weight="{weight}" text-anchor="{anchor}">{escape(value)}</text>'


def lines(x, y, values, size=20, leading=26, **kwargs):
    return ''.join(t(x, y + i * leading, value, size=size, **kwargs) for i, value in enumerate(values))


def rect(x, y, width, height, fill='white'):
    return f'<rect x="{x}" y="{y}" width="{width}" height="{height}" rx="8" fill="{fill}" stroke="{LINE}" stroke-width="1.5"/>'


def arrow(path, color=MUTED):
    return f'<path d="{path}" fill="none" stroke="{color}" stroke-width="2" stroke-linejoin="round" marker-end="url(#gift-arrow)"/>'


marker = '<defs><marker id="gift-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="context-stroke"/></marker></defs>'


def write(number, width, height, title, desc, body, defs=''):
    (OUT / f'figure-{number:02}.svg').write_text(f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}" width="{width}" height="{height}" role="img" aria-labelledby="gift-figure-{number}-title gift-figure-{number}-desc">
<title id="gift-figure-{number}-title">{escape(title)}</title>
<desc id="gift-figure-{number}-desc">{escape(desc)}</desc>
{marker}{defs}<rect width="{width}" height="{height}" fill="white"/><g font-family="Helvetica, Arial, sans-serif">{body}</g>
</svg>
''')


# Figure 1: distinguish a recorded observation from explanations, possible reports,
# proposed corrections, and complete response plans.
b = t(24, 43, 'What is known, possible and proposed?', 29, weight=700)
nodes = [
    (24, 96, 'Recorded observation', ['R0-01: the journey failed', 'Cause and correction unresolved'], '#edf5f5'),
    (394, 96, 'Candidate explanation', ['Print, link, device or account', 'Several faults may coexist', 'Scope still needs agreement'], 'white'),
    (764, 96, 'Corrective action set', ['Reprint or change link/access', 'Work depends on accepted faults', 'Actions are still proposals'], 'white'),
    (24, 340, 'Diagnostic check', ['Proposed phone/account tests', 'Method and access to be chosen', 'Cost and duration still open'], 'white'),
    (394, 340, 'Possible check outcome', ['Readability, link or access result', 'If observed, record and interpret', 'Assess scope and adequacy'], '#edf5f5'),
    (764, 340, 'Candidate response plan', ['Act now; or check, then correct', 'Bind scope, work and resources', 'Keep an explicit fallback'], 'white'),
]
for x, y, title, details, fill in nodes:
    b += rect(x, y, 300, 145, fill)
    b += t(x + 150, y + 34, title, 21, weight=700, anchor='middle')
    b += lines(x + 150, y + 71, details, size=17, leading=26, color=MUTED, anchor='middle')
b += arrow('M 330 168 H 384') + lines(357, 121, ['consistent', 'with'], size=16, leading=20, anchor='middle', color=MUTED)
b += arrow('M 700 168 H 754') + lines(727, 121, ['requires', 'if true'], size=16, leading=20, anchor='middle', color=MUTED)
b += arrow('M 544 331 V 251') + lines(561, 285, ['narrows', 'if observed'], size=16, leading=20, color=MUTED)
b += arrow('M 330 412 H 384') + t(357, 386, 'yields', 16, MUTED, anchor='middle')
b += arrow('M 700 412 H 754') + lines(727, 367, ['informs', 'choice'], size=16, leading=20, color=MUTED, anchor='middle')
b += arrow('M 914 331 V 251') + lines(931, 285, ['selects', 'work'], size=16, leading=20, color=MUTED)
b += arrow('M 914 494 V 535 H 174 V 495')
b += t(544, 569, 'A response plan may include diagnostic work', 21, TEAL, anchor='middle')
write(1, 1090, 600, 'What is known, possible and proposed?', 'The recorded failed journey is consistent with candidate explanations, which require corrective actions if true. A diagnostic check yields possible outcomes; observed outcomes narrow explanations and inform a candidate response plan. That plan selects corrective work and may include diagnostic work. Possibilities and proposals are distinct from recorded evidence, and observed outcomes require scope and adequacy review.', b)

# Figure 2: faithfully schematic; never imply the widths are a timed schedule.
b = t(24, 40, 'One instruction gates the whole dispatch job', 29, weight=700)
b += t(24, 75, 'Schematic Gantt for a replacement-insert route', 21, MUTED)
x = [320, 448, 575, 702, 829, 956, 1082]
ys = [151, 211, 271, 331, 391, 451, 511]
b += '<rect x="300" y="116" width="148" height="432" fill="#edf5f5"/>'
for v in x:
    b += f'<path d="M {v} 116 V 548" stroke="{LINE}" stroke-width="1"/>'
b += '<path d="M 448 116 V 548" stroke="#b74f3e" stroke-width="2" stroke-dasharray="6 5"/>'
labels = [['Checks + interpretation', '(if chosen)'], ["Leah’s instruction"], ['Revised files + approval'], ['Replacement printing'], ['Rehearsal + Leah release'], ['Packing / sealing'], ['Dispatch: 120 kits']]
for y, label in zip(ys, labels):
    b += lines(278, y + (0 if len(label) > 1 else 6), label, size=20, leading=23, anchor='end')
b += '<rect x="310" y="140" width="105" height="26" fill="#d7eaec" stroke="#177681" stroke-width="2"/>'
b += t(362.5, 159, 'to fit', 17, anchor='middle')
b += arrow('M 415 153 H 433 V 211 H 440')
b += '<path d="M 448 201 L 458 211 L 448 221 L 438 211 Z" fill="#b74f3e"/>'
b += arrow('M 448 222 V 271 H 465')
for start, end, y, fill in [(469, 575, 271, 'url(#gift-hatch)'), (575, 702, 331, 'url(#gift-hatch)'), (702, 829, 391, 'url(#gift-hatch-teal)'), (829, 956, 451, 'url(#gift-hatch-teal)')]:
    b += f'<rect x="{start}" y="{y-13}" width="{end-start}" height="26" fill="{fill}" stroke="{TEAL if y>=391 else MUTED}" stroke-width="2"/>'
    if y < 451:
        b += arrow(f'M {end} {y+16} V {y+45}')
b += arrow('M 956 467 V 511 H 1074')
b += '<path d="M 1082 501 L 1092 511 L 1082 521 L 1072 511 Z" fill="#193743"/>'
for v, label in zip(x, [['Review', 'opens'], ['3:00 p.m.', 'cutoff'], ['Files', 'approved'], ['Printed'], ['Release', 'approved'], ['Packed'], ['Tomorrow', 'morning']]):
    b += lines(v, 579, label, size=18, leading=22, anchor='middle')
b += t(300, 644, 'Hatching: task durations still to be estimated.', 20, MUTED)
b += t(300, 674, 'Widths show order only; the axis is not a minute scale.', 20, MUTED)
b += '<rect x="24" y="699" width="1080" height="39" fill="#f6f1e7"/>'
b += t(36, 726, 'If sealed kits must be reopened: 120 × USD 8 = USD 960 estimated handling.', 20)
hatch = '<defs><pattern id="gift-hatch" width="10" height="10" patternUnits="userSpaceOnUse"><rect width="10" height="10" fill="#f3f5f6"/><path d="M -2 2 L 2 -2 M 0 10 L 10 0 M 8 12 L 12 8" stroke="#536873" stroke-width="2"/></pattern><pattern id="gift-hatch-teal" width="10" height="10" patternUnits="userSpaceOnUse"><rect width="10" height="10" fill="#edf5f5"/><path d="M -2 2 L 2 -2 M 0 10 L 10 0 M 8 12 L 12 8" stroke="#177681" stroke-width="2"/></pattern></defs>'
write(2, 1130, 758, 'One instruction gates the whole dispatch job', 'A schematic Gantt-style dependency view runs from optional checks and interpretation through Leah’s instruction by 3:00 p.m., revised files and approval, replacement printing, rehearsal and Leah’s release, packing and sealing, and dispatch of 120 kits tomorrow morning. Hatched tasks have unestimated duration. Widths show order only, and the axis is not a minute scale. Conditional reopening exposure, outside the normal route, is 120 times USD 8, or USD 960 estimated handling.', b, hatch)

# Figure 3 is the original journey diagram, with its source meanings unchanged.
b = t(24, 43, 'What is in the gift-kit journey?', 29, weight=700)
nodes = [
    (24, 115, 'Gift kit', "One recipient’s package", 'Part of a 120-kit campaign', 'white'),
    (379, 115, 'Printed insert', 'QR code on the card', 'Print may be unreadable', '#edf5f5'),
    (734, 115, 'Encoded link', 'Address stored in the QR', 'May point to a wrong page', '#edf5f5'),
    (24, 435, 'Matching artwork', 'Source used for this print', 'Available for inspection', 'white'),
    (379, 435, 'Checkout', 'The intended customer’s access', 'May allow or block an order', '#edf5f5'),
    (734, 435, 'Approved page', 'The intended preorder page', 'Reference for this campaign', 'white'),
]
for x, y, name, d1, d2, fill in nodes:
    b += rect(x, y, 282, 145, fill)
    b += t(x + 17, y + 38, name, 23, weight=700)
    b += t(x + 17, y + 84, d1, 17.5, MUTED)
    b += t(x + 17, y + 117, d2, 17.5, TEAL)
b += arrow('M 314 188 H 368') + t(342, 157, 'contains', 17, MUTED, anchor='middle')
b += arrow('M 669 188 H 723') + t(696, 157, 'encodes', 17, MUTED, anchor='middle')
b += arrow('M 875 268 V 424') + lines(896, 338, ['should', 'open'], size=18, leading=24, color=MUTED)
b += arrow('M 725 508 H 672') + t(699, 477, 'leads to', 17, MUTED, anchor='middle')
b += arrow('M 165 427 V 349 H 520 V 270') + t(342, 324, 'is used to print', 18, MUTED, anchor='middle')
b += t(24, 643, 'Print, link and checkout faults can exist together.', 21, TEAL)
write(3, 1040, 678, 'What is in the gift-kit journey?', 'A gift kit contains a printed insert. The insert encodes a link that should open the approved preorder page, which leads to checkout. Matching artwork is used to print the insert and remains available for inspection. Print, link and checkout faults can coexist.', b)

# Figure 7: minute-scaled model outputs, not the unestimated global Gantt.
b = t(24, 43, 'Useful evidence must leave time to choose', 29, weight=700)
left, right = 260, 1040
scale = (right - left) / 30
b += t(24, 83, 'Printer cutoff: minute 16', 21, MUTED)
for minute in range(0, 31, 5):
    xx = left + minute * scale
    b += f'<path d="M {xx} 111 V 309" stroke="{LINE}" stroke-width="1"/>'
    b += t(xx, 340, str(minute), 19, MUTED, anchor='middle')
cutoff = left + 16 * scale
b += f'<path d="M {cutoff} 102 V 310" stroke="#b74f3e" stroke-width="2" stroke-dasharray="6 5"/>'
for name, evidence, choice, y in [('Targeted diagnosis', 14, 15, 166), ('Broader audit', 28, 29, 270)]:
    b += t(24, y + 7, name, 23)
    xe, xc = left + evidence * scale, left + choice * scale
    b += f'<path d="M {left} {y} H {xc}" stroke="{TEAL}" stroke-width="3"/>'
    b += f'<circle cx="{xe}" cy="{y}" r="9" fill="{TEAL}"/>'
    b += f'<path d="M {xc} {y-10} L {xc+10} {y} L {xc} {y+10} L {xc-10} {y} Z" fill="{NAVY}"/>'
    b += t(xc, y - 25, f'Evidence {evidence} | Choice {choice}', 20, anchor='end')
b += t((left + right) / 2, 379, 'Elapsed minutes from a 2:44 p.m. start', 21, MUTED, anchor='middle')
b += '<circle cx="285" cy="423" r="8" fill="#177681"/>' + t(306, 430, 'Useful evidence ready', 19)
b += '<path d="M 660 414 L 669 423 L 660 432 L 651 423 Z" fill="#193743"/>' + t(682, 430, 'Correction choice ready', 19)
write(7, 1080, 463, 'Useful evidence must leave time to choose', 'Timing reconstructed from model outputs on longer permitted outcome paths. TARGETED has useful evidence at minute 14 and a correction choice at minute 15. AUDIT has evidence at minute 28 and a choice at minute 29. The printer cutoff is minute 16. QUICK has no established correction-ready time and is omitted.', b)

# Figure 8: single general ontology, not the former two-domain stacked diagram.
b = t(24, 43, 'One general decision ontology', 29, weight=700)
nodes = [
    (24, 94, 'Physical situation', ['Objects, relationships and', 'governing rules'], 'white'),
    (596, 94, 'Uncertainty', ['Possible explanations;', 'likelihoods when stated'], 'white'),
    (24, 319, 'Question and evidence target', ['Required answer and', 'evidence standard'], '#edf5f5'),
    (596, 319, 'Experiments and observations', ['Checks, possible results and', 'error assumptions'], 'white'),
    (24, 544, 'Actions and consequences', ['Available responses and', 'their effects'], 'white'),
    (596, 544, 'Execution conditions', ['Access, resources, cost,', 'timing and authority'], 'white'),
]
for x, y, name, details, fill in nodes:
    b += rect(x, y, 420, 130, fill)
    b += t(x + 210, y + 39, name, 22, weight=700, anchor='middle')
    b += lines(x + 210, y + 77, details, size=18, leading=26, color=MUTED, anchor='middle')
b += arrow('M 450 159 H 586') + t(520, 135, 'defines cases', 17, MUTED, anchor='middle')
b += arrow('M 806 231 V 307') + t(829, 274, 'predicts results', 17, MUTED)
b += arrow('M 450 384 H 586', TEAL) + t(520, 358, 'sets sufficiency', 17, TEAL, anchor='middle')
b += arrow('M 626 456 V 491 H 234 V 532') + t(405, 479, 'supports action', 17, MUTED)
b += arrow('M 806 535 V 459') + t(829, 503, 'limits tests', 17, MUTED)
b += arrow('M 587 609 H 454') + t(520, 584, 'limits choice', 17, MUTED, anchor='middle')
b += t(24, 719, 'The relationships remain general;', 20, TEAL)
b += t(24, 745, 'each case supplies its own facts and rules.', 20, TEAL)
write(8, 1040, 781, 'One general decision ontology', 'Six general concept families. Physical situation covers objects, relationships and governing rules and defines uncertainty cases. Uncertainty covers possible explanations and likelihoods when stated and predicts results of experiments and observations. The question and evidence target sets sufficiency. Observations support actions and consequences. Execution conditions, including access, resources, cost, timing and authority, limit tests and choices. The arrows describe relationships rather than a work sequence.', b)

print('Rebuilt five native SVG figures for the requirements-trace gift-kit revision.')
