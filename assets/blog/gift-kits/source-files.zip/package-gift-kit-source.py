"""Verify the supplied case's arithmetic and package its reproducible assets."""

import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent.parent
ASSETS = ROOT / 'assets/blog/gift-kits'
extraction = json.loads((ASSETS / 'screenshot-extraction.json').read_text())
assert hashlib.sha256((ASSETS / extraction['source_pdf']).read_bytes()).hexdigest() == extraction['source_pdf_sha256']
for image in extraction['screenshots']:
    for file_key, hash_key in [('original', 'original_sha256'), ('file', 'png_sha256')]:
        assert hashlib.sha256((ASSETS / image[file_key]).read_bytes()).hexdigest() == image[hash_key]
assert (ROOT / 'assets/blog/question-worth/figure-02.svg').read_text() in (ASSETS / 'figure-02.svg').read_text()

recipe = {
    'source': 'Choose Checks Before Releasing Gift Kits, Jonathan Nacionales, 12 November 2026',
    'scope': 'Setup and narrative premises from the supplied PDF, not an application import file or a recorded physical run.',
    'example': 'Choose checks before releasing gift kits',
    'campaign': {'kits': 120, 'budget_usd': 6000},
    'decision': 'Which corrections does the evidence justify before the printer cutoff?',
    'correction_deadline_minutes': 16,
    'reviewer_available_from_minute': 0,
    'work_durations_minutes': {'preparation': 2, 'recording_per_check': 1, 'interpretation': 2, 'final_choice': 1},
    'diagnostic_allowance_credits': 15,
    'selected_plans': ['QUICK', 'TARGETED', 'AUDIT'],
    'selected_requirements': ['SUFFICIENCY', 'APPLICABILITY', 'TIME', 'COST', 'COVERAGE'],
    'workflow': ['Workspaces', 'New workspace', 'Choose checks before releasing gift kits', 'Guided questions', 'Update reports', 'Preview reports'],
    'simulation': {'plan': 'TARGETED', 'configuration': '110', 'faults': ['unreadable print', 'incorrect link'], 'checkout': 'approved checkout allowed'},
    'story_assumptions': ['Retail-buyer audience', '2:44 p.m. investigation start and 3:00 p.m. printer correction-choice cutoff', 'USD 8 per kit potential reopening handling rate', 'Physical checks and successful 3:30 p.m. replacement-insert rehearsal'],
    'evidence_limit': 'The source screenshots show calculations and a simulation. The demo has no retained physical run. The physical resolution belongs to the fictional story.',
}
start = 14 * 60 + 44
clock = lambda elapsed: f'{(start + elapsed) // 60:02}:{(start + elapsed) % 60:02}'
calculations = {
    'scope': 'Arithmetic under the supplied PDF premises. Potential handling exposure is not an app-calculated return or an observed saving; credits are not dollars.',
    'potential_handling_exposure_usd': 120 * 8,
    'targeted_reports_recorded_minutes': 12,
    'targeted_useful_evidence_ready_minutes': 12 + 2,
    'targeted_choice_ready_minutes': 12 + 2 + 1,
    'cutoff_minutes': 16,
    'targeted_deadline_slack_minutes': 16 - (12 + 2 + 1),
    'audit_choice_ready_minutes': 29,
    'audit_deadline_slack_minutes': 16 - 29,
    'clock_times': {str(elapsed): clock(elapsed) for elapsed in [12, 14, 15, 16, 29]},
    'investigation_costs_credits': {'QUICK': 1, 'TARGETED': 4, 'AUDIT': 12},
    'quick_choice': 'Not established; a repeated failure can leave several correction sets possible.',
}
assert calculations['potential_handling_exposure_usd'] == 960
assert calculations['targeted_choice_ready_minutes'] == 15
assert calculations['targeted_deadline_slack_minutes'] == 1
assert calculations['clock_times'] == {'12': '14:56', '14': '14:58', '15': '14:59', '16': '15:00', '29': '15:13'}
for file, value in [('input-recipe.json', recipe), ('verification-calculations.json', calculations)]:
    (ASSETS / file).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

readme = '''Choose Checks Before Releasing Gift Kits — source materials

The PDF is the supplied essay dated 12 November 2026. Its original wording,
eight section headings, seven figures, five tables, and case limitations are
preserved in the web post, with print wrapping and one page reference adapted.

Figures 1–2 are native SVG adaptations. Figure 2 includes the previous post's
original ontology unchanged. cover.svg is a separate editorial illustration.
Figures 3–7 are lossless PNG crops of the PDF's embedded JPEG captures, using
the same image clipping rectangles as the PDF. original-screenshots/ retains
those original JPEG streams; screenshot-extraction.json records their hashes
and crop coordinates. No report findings were redrawn or changed.

The input recipe and calculation checks document the PDF's fictional premises,
calculated timing, and simulated example; they are not an app import or a
physical evidence log. USD 960 is potential handling exposure, not a measured
or app-calculated saving. The printer cutoff applies to the correction choice;
production and the story's replacement-insert rehearsal follow afterward.

The HTML is an Eleventy/Nunjucks source template. The website supplies the
shared reader, cover metadata, follow-up links, and URL filters. The included scripts run in the website checkout. Diagrams use the supplied
original-ontology.svg (the previous article’s unchanged ontology). Screenshot
extraction uses macOS Swift ImageIO and the original PDF.
'''
with zipfile.ZipFile(ASSETS / 'source-files.zip', 'w', zipfile.ZIP_DEFLATED) as bundle:
    bundle.writestr('README.txt', readme)
    for asset in sorted(ASSETS.rglob('*')):
        if asset.is_file() and asset.suffix in {'.svg', '.png', '.jpg', '.pdf', '.json'}:
            bundle.write(asset, str(asset.relative_to(ASSETS)))
    for source in [ROOT / 'src/blog/posts/choose-checks-before-releasing-gift-kits.html', ROOT / 'src/_data/giftKitFigures.json', ROOT / 'scripts/generate-gift-kit-figures.py', ROOT / 'scripts/extract-gift-kit-screenshots.py', Path(__file__).resolve()]:
        bundle.write(source, source.name)
    bundle.write(ROOT / 'assets/blog/question-worth/figure-02.svg', 'original-ontology.svg')
print('Verified gift-kit source, screenshot hashes, ontology reuse, and arithmetic; packaged source-files.zip.')
