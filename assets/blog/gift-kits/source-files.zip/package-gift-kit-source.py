"""Verify the revised gift-kit essay's provenance/arithmetic and package sources."""

import hashlib
import json
from pathlib import Path
import re
import zipfile

ROOT = Path(__file__).resolve().parent.parent
ASSETS = ROOT / 'assets/blog/gift-kits'
extraction = json.loads((ASSETS / 'screenshot-extraction.json').read_text())
assert hashlib.sha256((ASSETS / extraction['source_pdf']).read_bytes()).hexdigest() == extraction['source_pdf_sha256']
assert [image['number'] for image in extraction['screenshots']] == [4, 5, 6]
for image in extraction['screenshots']:
    for file_key, hash_key in [('original', 'original_sha256'), ('file', 'png_sha256')]:
        assert hashlib.sha256((ASSETS / image[file_key]).read_bytes()).hexdigest() == image[hash_key]

figures = json.loads((ROOT / 'src/_data/giftKitFigures.json').read_text())
for figure in figures:
    number = figure['number']
    extension = 'png' if number in (4, 5, 6) else 'svg'
    asset = ASSETS / f'figure-{number:02}.{extension}'
    assert asset.is_file()
    if extension == 'svg':
        svg = asset.read_text()
        assert '<title ' in svg and '<desc ' in svg and 'role="img"' in svg
        assert f'viewBox="0 0 {figure["width"]} {figure["height"]}"' in svg
    else:
        import struct
        assert struct.unpack('>II', asset.read_bytes()[16:24]) == (figure['width'], figure['height'])
assert 'One general decision ontology' in (ASSETS / 'figure-08.svg').read_text()
assert 'the axis is not a minute scale' in (ASSETS / 'figure-02.svg').read_text()
assert 'Evidence 14 | Choice 15' in (ASSETS / 'figure-07.svg').read_text()

recipe = {
    'source': 'Choose Checks Before Releasing Gift Kits, requirements-and-views revision, Jonathan Nacionales, 13 November 2026',
    'source_pdf_sha256': extraction['source_pdf_sha256'],
    'scope': 'Declared setup, requirements derivation, and fictional business records from the supplied PDF; not an application import or retained physical run.',
    'example': 'Choose checks before releasing gift kits',
    'campaign': {'job': 'GK-120', 'kits': 120, 'allocation_usd': 6000},
    'decision': 'Which complete proposed investigation can establish the correction set and leave time for Leah to authorize and send the instruction by 3:00 p.m., within the available access and modeled resources?',
    'case_basis': {
        'scope_record': 'SCOPE-01', 'initial_insert': 'INSERT-R1', 'matching_artwork': 'AW-R1',
        'approved_destination': 'P-01', 'test_account': 'buyer-test-01',
        'faults_can_coexist': ['unreadable print', 'incorrect encoded destination', 'checkout restriction'],
        'check_reliability': 'Scoped checks are performed and reported accurately; no check or reporting error is modeled.',
        'acceptance': 'At least one modeled explanation remains and every compatible explanation requires the same complete correction set.',
        'authority': 'Leah can authorize scoped corrections and retain the packing hold. Model fit does not grant permission.',
    },
    'correction_cutoff_minutes': 16,
    'planned_start_clock': '14:44',
    'remaining_authorization_and_transmission_minutes': 1,
    'latest_usable_evidence_minutes': 15,
    'planned_targeted_usable_evidence_minutes': 14,
    'reviewer_available_from_minute': 0,
    'work_durations_minutes': {'preparation': 2, 'recording_per_check': 1, 'interpretation': 2, 'final_choice': 1},
    'diagnostic_allowance_credits': 15,
    'selected_plans': ['QUICK', 'TARGETED', 'AUDIT'],
    'active_requirement_trace': {'R1': 'SUFFICIENCY', 'R2': 'APPLICABILITY', 'R4': 'TIME', 'R5': 'COST', 'R6': 'COVERAGE'},
    'inactive_requirement_trace': {'R3': 'No check-count limit declared; no count requirement applied, and no pass supplied by an absent limit.'},
    'views': {'V1': 'Complete-plan comparison', 'V2': 'Basis matrix', 'V3': 'Finding and reason', 'V4': 'Evidence and commitment timing', 'V5': 'Evidence kind and provenance', 'V6': 'Case basis and revision'},
    'workflow': ['Workspaces', 'New workspace', 'Choose checks before releasing gift kits', 'Guided questions', 'Update reports', 'Preview reports'],
    'simulation': {'plan': 'TARGETED', 'configuration': '110', 'faults': ['unreadable print', 'incorrect link'], 'checkout': 'approved checkout allowed'},
    'direct_alternatives': {'reprint_now': 'Could preserve wrong link or checkout fault.', 'correct_all_three': 'Unranked: complete cost, work, side effects and timing not supplied.', 'validated_replacement': 'Unranked: availability, cost and readiness not supplied.', 'hold': 'Available fallback pending review.'},
    'business_records': ['BRIEF-01', 'PR-Q-01', 'R0-01', 'FUL-EST-01', 'SCOPE-01', 'CHECK-01', 'LOG-01', 'PR-WO-01', 'PR-INV-01', 'REL-01', 'PK-01'],
    'named_learning_commitment_slots': ['decision_question', 'evidence_plan', 'evidence_condition', 'supported_action', 'fallback_action', 'usable_evidence_deadline', 'learning_plan_cost'],
    'priced_scope': 'Up to four diagnostic credits for modeled checks on the longer permitted TARGETED branch.',
    'unpriced_work': 'Preparation, recording, interpretation and final choice consume scheduled time with no separate resource price here. Replacement printing and revised-card release rehearsal lie outside diagnostic cost.',
    'story_assumptions': ['Retail-buyer audience', 'Clock-time production timetable', 'USD 8 per kit conditional reopening handling estimate', 'Physical diagnostic findings and successful 3:30 p.m. revised-card rehearsal', 'All reconstructed business records, including USD 100 quote/invoice subtotal'],
    'evidence_limit': 'Current screenshots show model calculations and a simulated path. The demo has no retained physical run. LOG-01 and the physical resolution are fictional examples; model coverage is not established by one preview or one illustrated run.',
    'economic_limit': 'No dollar conversion, complete monetary acquisition cost or calculated economic information value is supplied. Campaign allocation does not establish remaining spending authority. USD 960 is potential exposure, not a measured saving.',
    'schedule_limit': 'The global Gantt establishes dependencies only; production and packing durations and capacity remain to be confirmed. The minute-scale model assesses the earlier correction-instruction commitment.',
}
start = 14 * 60 + 44
clock = lambda elapsed: f'{(start + elapsed) // 60:02}:{(start + elapsed) % 60:02}'
calculations = {
    'scope': 'Arithmetic under the revised PDF premises. Keep campaign allocation, production charges, diagnostic credits and conditional handling exposure separate.',
    'potential_handling_exposure_usd': 120 * 8,
    'printing_setup_usd': 40,
    'printing_cards_usd': 120 * 0.5,
    'quote_subtotal_usd': 40 + 120 * 0.5,
    'invoice_subtotal_usd': 40 + 120 * 0.5,
    'printing_exclusions': ['Tax', 'Delivery', 'Payment status'],
    'targeted_reports_recorded_minutes': 12,
    'targeted_usable_evidence_ready_minutes': 12 + 2,
    'remaining_commitment_work_minutes': 1,
    'cutoff_minutes': 16,
    'latest_usable_evidence_minutes': 16 - 1,
    'targeted_instruction_authorized_and_sent_minutes': 12 + 2 + 1,
    'targeted_deadline_slack_minutes': 16 - (12 + 2 + 1),
    'audit_usable_evidence_ready_minutes': 28,
    'audit_choice_ready_minutes': 29,
    'audit_deadline_slack_minutes': 16 - 29,
    'clock_times': {str(elapsed): clock(elapsed) for elapsed in [12, 14, 15, 16, 28, 29]},
    'investigation_costs_credits': {'QUICK': 1, 'TARGETED': 4, 'AUDIT': 12},
    'diagnostic_allowance_credits': 15,
    'quick_choice': 'Not established: an accurate failure report can leave different complete correction sets possible.',
    'fictional_revised_insert_rehearsal_clock': '15:30',
    'revised_insert': 'INSERT-R2', 'revised_artwork': 'AW-R2',
}
assert calculations['potential_handling_exposure_usd'] == 960
assert calculations['quote_subtotal_usd'] == calculations['invoice_subtotal_usd'] == 100
assert calculations['targeted_usable_evidence_ready_minutes'] == 14
assert calculations['latest_usable_evidence_minutes'] == calculations['targeted_instruction_authorized_and_sent_minutes'] == 15
assert calculations['targeted_deadline_slack_minutes'] == 1
assert calculations['clock_times'] == {'12': '14:56', '14': '14:58', '15': '14:59', '16': '15:00', '28': '15:12', '29': '15:13'}
for file, value in [('input-recipe.json', recipe), ('verification-calculations.json', calculations)]:
    (ASSETS / file).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

readme = '''Choose Checks Before Releasing Gift Kits — revised source materials

The main PDF is the exact supplied 22-page requirements-and-views revision,
dated 13 November 2026. The website retains the article URL and original
12 November publication date, with a 13 November update date. Its expanded
narrative, executive summary, five learning steps, requirements trace R1–R6
(R3 not applied), reviewer views V1–V6, 27 tables, eight figures, and three
formulas follow the revised PDF. Print page references become web links.
Body wording is retained with paragraph wrapping, typographical ligatures,
and print-only references adapted for the web. Formula notation is native
MathML, with spoken labels and plain-text annotations.

Figures 1, 2, 3, 7 and 8 are native SVG adaptations. Figure 2 is a schematic
dependency view, with unestimated work durations and an axis that is not a
minute scale. Figure 7 reconstructs model readiness outputs. Figure 8 is the
new single general ontology; the case-equivalence table is separate HTML.
cover.svg remains the existing editorial cover illustration.

Figures 4, 5 and 6 are PNG crops of the revised PDF's embedded JPEG captures,
using its exact normalized clipping rectangles. original-screenshots/ retains
the JPEG streams. screenshot-extraction.json records source/crop coordinates,
dimensions, and SHA-256 hashes. No report content was redrawn or changed.

archived-captures-2026-11-12/ retains the prior PDF and original app captures,
including the input screen, original detailed timing chart, and full simulated
outcomes screenshot mentioned in the revision. It is a clearly labeled archive;
the main web article uses the revised source PDF and figure numbering.

The input recipe and calculation checks distinguish declared model premises,
app previews and fictional business records. SCOPE-01 records accepted scope;
CHECK-01 starts open. LOG-01 and the physical outcome are fictional examples.
The source demo retains no physical run. The model-fit result supports one
correction instruction among the supplied investigations; it grants no authority
and does not settle the unestimated whole-dispatch schedule.

Diagnostic credits are resource units. Four credits price modeled checks on
the longer TARGETED path. Other scheduled work has no separate resource price;
replacement printing and revised-card rehearsal are outside that figure.
USD 100 is a fictional printing quote/invoice subtotal, USD 6,000 is campaign
allocation, and USD 960 is conditional handling exposure, not a measured saving
or calculated return. Tax, delivery and payment status are outside the invoice
excerpt. Direct alternatives lacking price/readiness inputs remain unranked.

The Eleventy/Nunjucks HTML template uses the website's shared reader, filters,
MathML styles, metadata, contents navigation, and follow-up links. Scripts run
from the website checkout: generate-gift-kit-figures.py builds native SVGs;
extract-gift-kit-screenshots.py uses macOS Swift ImageIO with the supplied PDF;
package-gift-kit-source.py verifies provenance/arithmetic and rebuilds this ZIP.
'''
with zipfile.ZipFile(ASSETS / 'source-files.zip', 'w', zipfile.ZIP_DEFLATED) as bundle:
    bundle.writestr('README.txt', readme)
    for asset in sorted(ASSETS.rglob('*')):
        if asset.is_file() and asset.suffix in {'.svg', '.png', '.jpg', '.pdf', '.json', '.txt'}:
            bundle.write(asset, str(asset.relative_to(ASSETS)))
    for source in [ROOT / 'src/blog/posts/choose-checks-before-releasing-gift-kits.html', ROOT / 'src/_data/giftKitFigures.json', ROOT / 'scripts/generate-gift-kit-figures.py', ROOT / 'scripts/extract-gift-kit-screenshots.py', Path(__file__).resolve()]:
        bundle.write(source, source.name)
print('Verified revised gift-kit figures, screenshot hashes and arithmetic; packaged source-files.zip.')
