What Is a Question Worth? — source materials

The PDF is the supplied essay dated 12 November 2026. Figures 11–14 are
screenshots extracted from that PDF, with page furniture cropped away.
Figures 1–10 are native SVG adaptations for the web, with the same data
and relationships. The generator is included.

input-recipe.json transcribes the article's fictional application setup.
It is a readable recipe, not an application import file.
verification-calculations.json checks the article's numerical examples.
It does not represent physical observations, error probabilities, or
economic-value fields calculated by the application.

The HTML is an Eleventy/Nunjucks source template, not the built page.
Figure dimensions are included as questionWorthFigures.json. The website
supplies its shared layout and relative-URL filters.
