What Is a Question Worth? — source materials

The PDF is the supplied essay dated 12 November 2026, with its views revision
of 13 November 2026. The stable PDF asset contains the exact supplied revised
file. Figures 11–14 are screenshots extracted from revised PDF pages 25–28,
with page headings and captions cropped away. Their extent matches the new
PDF, including its cropped plan-comparison screenshot. The Swift extractor
and native SVG generator are included. Figures 1–10 are native SVG
adaptations preserving the source data and relationships in revised order;
the shared ontology is now figure 10. The SVG cover is unchanged.

The revision develops the Learn enough before committing pattern, seven
named slots and their marble bindings, Q0–Q6, R1–R6 with acceptance rules,
and V1–V6 before the final existing-app walkthrough. requirements-trace.json
retains the illustrative derivation and basis matrix. The worked fallback
permission is an added illustrative operating rule, explicitly distinguished
from observed app behavior.

The published case was inspected on 13 November 2026 in the source. The
archived workspace-preview screenshots remain dated 12 November 2026.

input-recipe.json transcribes the article's fictional application setup.
It is a readable recipe, not an application import file.
verification-calculations.json checks the article's numerical examples.
It does not represent physical observations, error probabilities, or
economic-value fields calculated by the application.

The HTML is an Eleventy/Nunjucks source template, not the built page.
Figure dimensions are included as questionWorthFigures.json. The website
supplies its shared layout and relative-URL filters.
