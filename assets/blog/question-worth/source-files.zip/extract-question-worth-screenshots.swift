// Reproduce figures 11–14 from the supplied views revision PDF.
// Run with: swift scripts/extract-question-worth-screenshots.swift [source.pdf]
// Crops retain the exact screenshot extent in that revision, excluding PDF headings/captions.
import Foundation
import PDFKit
import AppKit
let root = URL(fileURLWithPath: #filePath).deletingLastPathComponent().deletingLastPathComponent()
let output = root.appendingPathComponent("assets/blog/question-worth", isDirectory: true)
let source = CommandLine.arguments.count > 1 ? URL(fileURLWithPath: CommandLine.arguments[1]) : output.appendingPathComponent("what-is-a-question-worth.pdf")
guard let document = PDFDocument(url: source) else { fatalError("Cannot open the source PDF") }
let crops: [(page: Int, figure: Int, x: CGFloat, y: CGFloat, width: CGFloat, height: CGFloat)] = [
    (25, 11, 0.09, 0.097, 0.82, 0.261),
    (26, 12, 0.064, 0.195, 0.873, 0.619),
    (27, 13, 0.09, 0.3915, 0.82, 0.271),
    (28, 14, 0.064, 0.195, 0.847, 0.571)
]
var dimensions: [[String: Int]] = []
for crop in crops {
    guard let page = document.page(at: crop.page - 1) else { fatalError("Missing source page") }
    let rendered = page.thumbnail(of: NSSize(width: 2400, height: 3400), for: .mediaBox)
    let bitmap = NSBitmapImageRep(data: rendered.tiffRepresentation!)!
    let original = bitmap.cgImage!
    let region = CGRect(x: CGFloat(original.width) * crop.x,
                        y: CGFloat(original.height) * crop.y,
                        width: CGFloat(original.width) * crop.width,
                        height: CGFloat(original.height) * crop.height).integral
    let result = NSBitmapImageRep(cgImage: original.cropping(to: region)!)
    try result.representation(using: .png, properties: [:])!.write(to: output.appendingPathComponent(String(format: "figure-%02d.png", crop.figure)))
    dimensions.append(["number": crop.figure, "width": result.pixelsWide, "height": result.pixelsHigh])
    print("Figure \(crop.figure): \(result.pixelsWide)×\(result.pixelsHigh)")
}
let metadata = root.appendingPathComponent("src/_data/questionWorthFigures.json")
var figures = try JSONSerialization.jsonObject(with: Data(contentsOf: metadata)) as! [[String: Int]]
for dimension in dimensions { figures[dimension["number"]! - 1] = dimension }
let data = try JSONSerialization.data(withJSONObject: figures, options: [.prettyPrinted, .sortedKeys])
try (String(data: data, encoding: .utf8)! + "\n").write(to: metadata, atomically: true, encoding: .utf8)
