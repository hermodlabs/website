#!/usr/bin/env python3
"""Rebuild the ten native SVG diagrams from What Is a Question Worth?.

The supplied views revision of 13 November 2026 is the source of labels,
counts, relationships, and figure numbering. The ontology is figure 10.
Charts enumerate every integer N from 1 through 1,024; dot diagrams retain
their actual candidate counts. Run from any working directory.
"""

from html import escape
from pathlib import Path
import math

OUT = Path(__file__).resolve().parents[1] / "assets/blog/question-worth"
OUT.mkdir(parents=True, exist_ok=True)
NAVY = "#193743"
PURPLE = "#7850c2"
TEAL = "#177681"
MUTED = "#536873"
LINE = "#d3dfe5"
PALE = "#e0e7ec"
RED = "#b44539"
BLUE = "#326e9c"
AMBER = "#946211"


def t(x, y, value, size=20, color=NAVY, weight=400, anchor="start"):
    return f'<text x="{x}" y="{y}" font-size="{size}" fill="{color}" font-weight="{weight}" text-anchor="{anchor}">{escape(str(value))}</text>'


def lines(x, y, values, size=20, leading=26, **kwargs):
    return "".join(t(x, y + i * leading, v, size=size, **kwargs) for i, v in enumerate(values))


def rect(x, y, w, h, fill="white", stroke=LINE, radius=8):
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{radius}" fill="{fill}" stroke="{stroke}" stroke-width="1.5"/>'


def path(d, color=MUTED, width=2, arrow=False, dash=None):
    extra = ' marker-end="url(#arrow)"' if arrow else ""
    extra += f' stroke-dasharray="{dash}"' if dash else ""
    return f'<path d="{d}" fill="none" stroke="{color}" stroke-width="{width}" stroke-linejoin="round"{extra}/>'


def dot(x, y, r=2, color=TEAL):
    return f'<circle cx="{x}" cy="{y}" r="{r}" fill="{color}"/>'


def grid(x, y, cols, rows, step=9, r=1.8, color=TEAL, condition=None):
    return "".join(dot(x + c * step, y + row * step, r,
                       color if condition is None or condition(c, row) else PALE)
                   for row in range(rows) for c in range(cols))


def svg(num, height, title, desc, body):
    value = f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1040 {height}" width="1040" height="{height}" role="img" aria-labelledby="figure-{num:02d}-title figure-{num:02d}-desc">
<title id="figure-{num:02d}-title">{escape(title)}</title>
<desc id="figure-{num:02d}-desc">{escape(desc)}</desc>
<defs><marker id="arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="context-stroke"/></marker></defs>
<rect width="1040" height="{height}" fill="white"/>
<g font-family="Helvetica, Arial, sans-serif">{body}</g>
</svg>
'''
    (OUT / f"figure-{num:02d}.svg").write_text(value)


# 1. The physical rules and success criteria stay explicit in all four panels.
b = t(24, 43, "What changed about the decision?", 29, weight=700)
cases = [
    (24, 80, "1. Find the marble", TEAL,
     "1,024 marbles; one heavy in total", "Exact marble identity", "Fewest worst-case weighings", 1),
    (544, 80, "2. Find the containing bag", PURPLE,
     "Same marbles: 512 red + 512 blue", "Containing bag", "Enough detail for the question", 1),
    (24, 407, "3. Choose the valuable bag", TEAL,
     "New game: one heavy in each bag", "Which bag to redeem", "Expected payout less test cost", 2),
    (544, 407, "4. Choose before handoff", PURPLE,
     "Nine marbles; one heavy in total", "Containing bag, with reliable evidence", "Choice completed by minute 12", 2),
]
for x, y, heading, color, physical, answer, criterion, highlight in cases:
    b += rect(x, y, 472, 300)
    b += t(x + 20, y + 37, heading, 23, color, 700)
    for i, (label, value) in enumerate(zip(
            ["PHYSICAL SITUATION", "REQUIRED ANSWER", "JUDGE THE PLAN BY"],
            [physical, answer, criterion])):
        by = y + 86 + i * 75
        b += t(x + 20, by, label, 14, MUTED, 700)
        if i == highlight:
            b += rect(x + 11, by + 9, 450, 36, "#f2edf8" if color == PURPLE else "#edf5f5", "none", 3)
        b += t(x + 20, by + 33, value, 18.5, weight=700 if i == highlight else 400)
svg(1, 731, "What changed about the decision?",
    "Four cases state their physical situation, required answer, and success criterion. Exact search: 1,024 marbles, one heavy in total, exact identity, fewest worst-case weighings. Bag search: the same marbles split 512 red and 512 blue, containing bag, enough detail. Payout game: one heavy in each bag, choose a bag, expected payout less test cost. Handoff: nine marbles, one heavy in total, reliable bag identification, choice by minute 12.", b)


# 10. Arrows describe relationships, not a schedule.
b = t(24, 43, "One structure for the four versions", 29, weight=700)
nodes = [
    (24, 94, "Physical situation", ["Bags, marbles, membership,", "allocation rule"], "white"),
    (596, 94, "Uncertainty", ["Possible explanations;", "probabilities when given"], "white"),
    (24, 319, "Question and evidence target", ["Marble identity, bag identity,", "or payout tier"], "#edf5f5"),
    (596, 319, "Experiments and observations", ["Comparison, possible results,", "error premise"], "white"),
    (24, 544, "Actions and consequences", ["Available choices and", "how they are valued"], "white"),
    (596, 544, "Execution conditions", ["Cost, resources, availability,", "deadline"], "white"),
]
for x, y, heading, detail, fill in nodes:
    b += rect(x, y, 420, 130, fill)
    b += t(x + 210, y + 39, heading, 22, weight=700, anchor="middle")
    b += lines(x + 210, y + 77, detail, size=18, color=MUTED, anchor="middle")
b += path("M 450 159 H 586", arrow=True)
b += t(520, 135, "defines cases", 17, MUTED, anchor="middle")
b += path("M 806 231 V 307", arrow=True)
b += t(829, 274, "predicts results", 17, MUTED)
b += path("M 450 384 H 586", TEAL, arrow=True)
b += t(520, 358, "sets sufficiency", 17, TEAL, anchor="middle")
b += path("M 626 456 V 491 H 234 V 532", arrow=True)
b += t(405, 479, "supports action", 17, MUTED)
b += path("M 806 535 V 459", arrow=True)
b += t(829, 503, "limits tests", 17, MUTED)
b += path("M 587 609 H 454", arrow=True)
b += t(520, 584, "limits choice", 17, MUTED, anchor="middle")
b += lines(24, 719, ["Facts and requirements change between cases;", "these concept families can remain the same."], size=20, color=TEAL)
svg(10, 781, "One structure for the four versions",
    "Six concept families and their relationships. Physical situation defines uncertainty cases. Uncertainty predicts experiment results. The question and evidence target sets sufficiency for experiments and observations. Observations support actions and consequences. Execution conditions limit tests and choices. These relationships do not schedule the work.", b)


# 2. Every dot is one possible heavy-marble location.
b = t(24, 43, "Many possible explanations, one actual heavy marble", 27, weight=700)
b += t(24, 86, "All 1,024 locations are still possible", 20, weight=700)
b += t(458, 86, "Three of the 1,024 possible explanations", 20, weight=700)
b += rect(24, 108, 364, 476)
b += grid(66, 140, 32, 32, step=9, r=1.8)
b += t(49, 470, "32 × 32 = 1,024 locations", 22, weight=700)
b += t(49, 512, "No location ruled out yet.", 19)
b += t(49, 546, "Each dot is one candidate location.", 18, MUTED)
b += path("M 399 344 H 445", TEAL, arrow=True)
for row, (name, heavy) in enumerate([("Possibility 1: marble 1 is heavy", 0), ("Possibility 2: marble 2 is heavy", 1), ("Possibility 1,024: marble 1,024 is heavy", 2)]):
    y = 108 + row * 164
    b += rect(458, y, 558, 148)
    b += t(480, y + 36, name, 21, weight=700)
    for i, (cx, label) in enumerate([(521, "1"), (650, "2"), (949, "1,024")]):
        b += f'<circle cx="{cx}" cy="{y + 83}" r="13" fill="{PURPLE if i == heavy else "#edf5f5"}" stroke="{PURPLE if i == heavy else LINE}" stroke-width="2"/>'
        if i == heavy:
            b += t(cx, y + 88, "H", 15, "white", 700, "middle")
        b += t(cx, y + 122, label, 19, PURPLE if i == heavy else MUTED, 700 if i == heavy else 400, "middle")
    b += t(793, y + 91, "…", 31, MUTED, anchor="middle")
b += lines(458, 625, ["H = heavy in that explanation;", "other shown marbles are normal."], size=18, color=MUTED)
b += lines(24, 694, ["Exactly one possibility is true. Before testing,", "each is assigned probability 1/1,024."], size=21, color=TEAL, weight=700)
svg(2, 754, "Many possible explanations, one actual heavy marble",
    "A 32 by 32 grid shows all 1,024 possible heavy-marble locations. Three cards show alternative explanations: marble 1 is heavy, marble 2 is heavy, or marble 1,024 is heavy. In each explanation all other marbles are normal. Exactly one explanation is true; each has prior probability 1/1,024. Ellipses omit intermediate marble labels on the cards.", b)


# 3. The curves enumerate the exact worst-case counts for every integer N.
b = t(24, 42, "How the search grows", 29, weight=700)
for x, color, label, dashed in [(27, PURPLE, "One at a time", False), (343, TEAL, "Divide into halves", False), (686, AMBER, "Divide into thirds", True)]:
    b += path(f"M {x} 85 h 45", color, width=4, dash="10 7" if dashed else None)
    b += t(x + 57, 91, label, 19)

def ceil_log(n, base):
    # Integer arithmetic avoids a floating-point extra step at exact powers.
    k, cap = 0, 1
    while cap < n:
        cap *= base
        k += 1
    return k


def chart(x0, y0, w, h, ymax, ticks, heading, full):
    result = t(x0, y0 - 27, heading, 22, weight=700)
    sx = lambda n: x0 + (n - 1) * w / 1023
    sy = lambda k: y0 + h - k * h / ymax
    for tick in ticks:
        yy = sy(tick)
        result += path(f"M {x0} {yy:.3f} H {x0 + w}", LINE, 1)
        result += t(x0 - 11, yy + 6, str(tick), 16, MUTED, anchor="end")
    result += path(f"M {x0} {y0} V {y0 + h} H {x0 + w}", MUTED, 1.5)
    for n in [1, 256, 512, 768, 1024]:
        xx = sx(n)
        result += path(f"M {xx:.3f} {y0 + h} v 6", MUTED, 1)
        result += t(round(xx, 3), y0 + h + 29, f"{n:,}", 16, MUTED, anchor="middle")
    funcs = [(lambda n: n - 1, PURPLE, None)] if full else []
    funcs += [(lambda n: ceil_log(n, 2), TEAL, None), (lambda n: ceil_log(n, 3), AMBER, "10 7")]
    for fn, color, dash in funcs:
        coords = [(sx(n), sy(fn(n))) for n in range(1, 1025)]
        d = f"M {coords[0][0]:.3f} {coords[0][1]:.3f}"
        if color == PURPLE:
            # N - 1 lies on an exact straight line.
            d += f" L {coords[-1][0]:.3f} {coords[-1][1]:.3f}"
        else:
            # Horizontal then vertical makes each integer-ceiling step explicit.
            previous_y = coords[0][1]
            for xx, yy in coords[1:]:
                if yy != previous_y:
                    d += f" H {xx:.3f} V {yy:.3f}"
                    previous_y = yy
            d += f" H {coords[-1][0]:.3f}"
        result += path(d, color, 3.5, dash=dash)
    result += t(x0 + w / 2, y0 + h + 69, "Number of marbles, N", 19, anchor="middle")
    result += f'<text transform="translate({x0 - 59},{y0 + h / 2}) rotate(-90)" text-anchor="middle" font-size="18" fill="{NAVY}">Worst-case weighings</text>'
    if full:
        result += dot(sx(1024), sy(1023), 5, PURPLE)
        result += t(sx(1024) - 6, sy(1023) - 17, "1,023", 22, PURPLE, 700, "end")
    else:
        for val, color in [(10, TEAL), (7, AMBER)]:
            result += dot(sx(1024), sy(val), 5, color)
            result += t(sx(1024) - 6, sy(val) - 15, val, 22, color, 700, "end")
    return result

b += chart(92, 164, 373, 286, 1125, [0, 250, 500, 750, 1000], "A  All three strategies", True)
b += chart(633, 164, 373, 286, 11.5, [0, 2, 4, 6, 8, 10], "B  Grouped strategies, zoomed", False)
b += lines(24, 565, ["At 1,024 marbles: 1,023 individual checks,", "10 halvings, or 7 three-way checks."], size=22, color=TEAL, weight=700)
b += t(24, 642, "Counts: N − 1; ⌈log₂ N⌉; ⌈log₃ N⌉. Both horizontal axes are linear.", 18, MUTED)
svg(3, 672, "How the search grows",
    "Two plots show exact worst-case weighing counts for integer marble counts from 1 to 1,024 on linear horizontal axes. One at a time is N minus 1. Halving is ceiling log base 2 of N. Three-way splitting is ceiling log base 3 of N. The left plot shows all three with a full vertical scale; the right zooms to show the grouped staircases. At 1,024 marbles their counts are 1,023, 10, and 7, respectively. Assumes an ideal balance and one known-heavier marble.", b)


# 4. Same 1,024 dots in each panel, with ruled-out locations shown in pale gray.
b = t(24, 43, "A smaller set of possible locations needs fewer bits", 27, weight=700)
for x, stage, count, entropy, keep in [
        (24, "Before any result", "1,024 possible", 10, lambda c, r: True),
        (374, "After 1 halving", "512 possible", 9, lambda c, r: c < 16),
        (724, "After 10 halvings", "1 possible", 0, lambda c, r: c == 15 and r == 15)]:
    b += rect(x, 93, 292, 400)
    b += t(x + 146, 128, stage, 20, weight=700, anchor="middle")
    b += t(x + 146, 168, count, 27, weight=700, anchor="middle")
    b += grid(x + 37.5, 201, 32, 32, step=7, r=1.45, condition=keep)
    if entropy == 0:
        b += f'<circle cx="{x + 142.5}" cy="306" r="10" fill="none" stroke="{TEAL}" stroke-width="2"/>'
    b += t(x + 146, 464, f"H = {entropy} bits", 25, TEAL, 700, "middle")
for x in [325, 675]:
    b += path(f"M {x} 303 h 36", TEAL, arrow=True)
b += dot(31, 535, 4, TEAL) + t(45, 541, "Still possible", 18)
b += dot(290, 535, 4, PALE) + t(304, 541, "Ruled out", 18)
b += t(24, 581, "Each dot is one possible heavy-marble location.", 19, MUTED)
svg(4, 611, "A smaller set of possible locations needs fewer bits",
    "Three panels show the same 1,024 locations. Before a result all 1,024 candidates remain and entropy is 10 bits. After one equal binary split 512 remain and entropy is 9 bits. After ten equal binary splits one candidate remains and entropy is zero. Pale dots are ruled out; a circle highlights the final candidate. Remaining candidates are equally likely.", b)


# 5. Partition widths preserve the exact result probabilities.
b = lines(24, 42, ["One weighing divides the same 1,024 candidates", "in different ways"], size=27, leading=34, weight=700)
b += t(253, 124, "Possible results partition the candidates", 18, MUTED)
b += lines(889, 112, ["Expected", "information gain"], size=18, leading=23, color=MUTED, anchor="middle")
for y, heading, groups, note, gain, remainder in [
        (188, ["Check one", "candidate"], [1, 1023], "1 or 1,023 candidates remain", "0.011 bits", "9.989 bits remain"),
        (322, ["Ask which", "half"], [512, 512], "512 candidates remain in either outcome", "1.000 bits", "9.000 bits remain"),
        (456, ["Use three", "outcomes"], [341, 341, 342], "341, 341, or 342 candidates remain", "1.585 bits", "8.415 bits remain")]:
    b += lines(24, y + 12, heading, size=21, leading=26, weight=700)
    x = 253
    for i, group in enumerate(groups):
        width = 500 * group / 1024
        b += f'<rect x="{x:.5f}" y="{y}" width="{width:.5f}" height="44" fill="{["#bedfdf", "#ddd0ee", "#e0e7ec"][i]}"/>'
        if group > 1:
            b += t(round(x + width / 2, 3), y + 30, f"{group:,}", 21, weight=700, anchor="middle")
        else:
            b += path(f"M {x + width/2:.5f} {y - 2} V {y - 22} H {x + 25}", TEAL, 1.5)
            b += t(x + 30, y - 16, "1", 18, TEAL, 700)
        if i:
            b += path(f"M {x:.5f} {y} v 44", "white", 1)
        x += width
    b += t(253, y + 73, note, 17.5, MUTED)
    b += t(889, y + 26, gain, 26, TEAL, 700, "middle")
    b += t(889, y + 64, remainder, 18, MUTED, anchor="middle")
b += lines(24, 586, ["Widths show result probabilities.", "Remaining entropy is averaged over the possible results."], size=19, leading=27, color=MUTED)
svg(5, 650, "One weighing divides the same 1,024 candidates in different ways",
    "First-weighing result partitions under a uniform prior. Checking one candidate produces groups of 1 and 1,023, expected gain 0.011 bits and expected remaining entropy 9.989 bits. Halving produces 512 and 512, gain 1.000 bits and 9.000 bits remain. Three-way splitting produces 341, 341, and 342, gain 1.585 bits and 8.415 bits remain. Segment widths show exact probabilities; reported entropy values are rounded to three decimals.", b)


# 6. Only the physical weighing stage has an assigned credit price.
b = lines(24, 42, ["Price the weighings, then plan the work around them"], size=27, weight=700)
b += t(24, 82, "2 credits per weighing", 21, TEAL, 700)
for x, name, formula, cost, color in [
        (24, "One at a time", "1,023 × 2", "2,046 credits", PURPLE),
        (374, "Divide into halves", "10 × 2", "20 credits", TEAL),
        (724, "Divide into thirds", "7 × 2", "14 credits", AMBER)]:
    b += rect(x, 112, 292, 181)
    b += t(x + 146, 153, name, 21, color, 700, "middle")
    b += t(x + 146, 213, formula, 35, weight=700, anchor="middle")
    b += t(x + 146, 263, cost, 26, color, 700, "middle")
b += lines(24, 341, ["The complete learning plan also needs time and resources for"], size=22, weight=700)
stages = [["Prepare", "& sort"], ["Weigh"], ["Record"], ["Interpret"], ["Choose"]]
for i, stage in enumerate(stages):
    x = 24 + 204 * i
    b += rect(x, 378, 176, 89, "#f2edf8" if i == 1 else "#edf5f5", PURPLE if i == 1 else LINE)
    b += lines(x + 88, 413 if len(stage) > 1 else 431, stage, size=21, leading=25, weight=700 if i == 1 else 400, anchor="middle")
    if i < 4:
        b += path(f"M {x + 181} 423 h 16", arrow=True)
b += lines(24, 514, ["Only the highlighted weighing step is priced in the credit totals above;", "no durations are assumed here."], size=19, leading=28, color=MUTED)
svg(6, 579, "Price the weighings, then plan the work around them",
    "At two credits per physical weighing, worst-case costs are 1,023 times 2 equals 2,046 credits for individual checking; 10 times 2 equals 20 credits for halving; 7 times 2 equals 14 credits for three-way splitting. A separate sequence is prepare and sort, weigh, record, interpret, choose. Only the weighing step is priced in these totals. Other stages consume resources; no stage durations are assumed.", b)


# 7. Exactly 512 locations in each bag; no actual heavy position is revealed.
b = lines(24, 42, ["Change the required answer; keep the same 1,024 marbles"], size=27, weight=700)
b += lines(24, 81, ["Exactly one heavy marble across both groups.", "All locations start equally likely."], size=20, leading=27, color=MUTED)
for x, label, color, tint in [(24, "Red", RED, "#fbf0ee"), (544, "Blue", BLUE, "#eef4fa")]:
    b += rect(x, 140, 472, 280)
    b += t(x + 236, 181, f"{label}: 512 candidate locations", 23, color, 700, "middle")
    b += grid(x + 65.5, 208, 32, 16, step=11, r=1.9, color=color)
    b += path(f"M {x + 236} 430 v 31", color, arrow=True)
    b += rect(x, 475, 472, 65, tint)
    b += t(x + 236, 515, f"{label} pan heavier → identify {label.lower()}", 22, color, 700, "middle")
b += lines(24, 589, ["Before: bag 1 bit; marble 10 bits.", "After: bag 0 bits; marble 9 bits."], size=23, leading=32, color=TEAL, weight=700)
svg(7, 657, "Change the required answer; keep the same 1,024 marbles",
    "Two panels each show 512 candidate locations, red and blue. Exactly one marble across both bags is heavy, with all 1,024 locations equally likely. A reliable balance comparison of the two full groups identifies red if the red pan is heavier and blue if the blue pan is heavier. Before: bag entropy 1 bit, marble entropy 10 bits. After: bag entropy zero, marble entropy 9 bits. The dots are candidate locations, not revealed heavy marbles.", b)


# 8. This is a new physical game: ONE heavy IN EACH bag (two in total).
def bag_icon(x, y, color, tint, label):
    result = f'<path d="M {x + 28} {y} H {x + 84} L {x + 78} {y + 21} Q {x + 119} {y + 57} {x + 103} {y + 108} Q {x + 55} {y + 115} {x + 9} {y + 103} Q {x - 4} {y + 61} {x + 34} {y + 21} Z" fill="{tint}" stroke="{color}" stroke-width="2.5"/>'
    result += path(f"M {x + 29} {y + 21} H {x + 84}", color, 3)
    result += lines(x + 57, y + 64, label, size=19, leading=26, color=color, weight=700, anchor="middle")
    return result

b = t(24, 42, "A useful test changes which bag you choose", 28, weight=700)
b += t(24, 80, "New game: one heavy marble in each bag; two heavy marbles in total.", 19, MUTED)
for x, color, tint, heading, detail, sub, value, icontext in [
        (24, RED, "#fbefec", "RED BAG", "9 marbles, all labeled $60", "", "Certain payout: $60", ["$60"]),
        (544, BLUE, "#edf4fa", "BLUE BAG", "512 × $100; 512 × $0", "1,024 equally likely locations", "Expected payout: $50", ["$100", "or $0"])]:
    b += rect(x, 106, 472, 180)
    b += bag_icon(x + 17, 143, color, tint, icontext)
    b += t(x + 157, 145, heading, 22, color, 700)
    b += t(x + 157, 185, detail, 19)
    if sub:
        b += t(x + 157, 218, sub, 17, MUTED)
    b += t(x + 157, 259, value, 24, color, 700)
b += rect(24, 307, 992, 56, "#edf5f5", "none")
b += t(520, 343, "Without testing: choose red and receive $60.", 23, weight=700, anchor="middle")
b += rect(24, 416, 221, 126, "#f2edf8", "#c8b7e4")
b += lines(134.5, 465, ["Test blue", "Pay $5 once"], size=24, leading=31, weight=700, anchor="middle")
b += path("M 255 455 L 428 410", BLUE, arrow=True)
b += t(323, 418, "50%", 21, BLUE, 700)
b += path("M 255 502 L 428 548", RED, arrow=True)
b += t(323, 550, "50%", 21, RED, 700)
b += rect(442, 380, 574, 92, "#edf4fa", "#c4d8ea")
b += t(465, 416, "The $100 group is heavier", 21)
b += t(465, 450, "Choose BLUE → receive $100", 24, BLUE, 700)
b += rect(442, 504, 574, 92, "#fbf0ee", "#e6ccc7")
b += t(465, 540, "The $0 group is heavier", 21)
b += t(465, 574, "Choose RED → receive $60", 24, RED, 700)
b += lines(24, 646, ["Expected payout with the result: $80. After the $5 test fee: $75.", "Gross information value: $80 − $60 = $20.", "Net gain: $20 − $5 = $15."], size=22, leading=32, color=TEAL, weight=700)
svg(8, 741, "A useful test changes which bag you choose",
    "A new payout game has one heavy marble in each bag, two heavy marbles in total. Red has nine marbles all labeled $60 and pays $60 certainly. Blue has 512 $100 labels and 512 $0 labels, so expected payout is $50. Without a test choose red. Pay $5 once to test blue's two payout groups. With probability one half the $100 group is heavier: choose blue and receive $100. With probability one half the $0 group is heavier: choose red and receive $60. Expected payout before the fee is $80, after it $75; gross information value $20 and net gain $15. Bag icons are schematic.", b)


# 9. Influence diagram: information arcs, dependencies, and value inputs.
b = t(24, 43, "A result has value through the choice it can change", 28, weight=700)
# Test cost takes an outer route to the value node.
b += path("M 777 128 V 87 H 28 V 600 H 53", PURPLE, arrow=True)
b += t(500, 76, "test cost", 18, PURPLE, anchor="middle")
# Underlying state affects the observation and the eventual payout.
b += path("M 390 188 L 605 348", arrow=True)
b += t(468, 231, "predicts", 18, MUTED)
b += path("M 220 221 V 532", arrow=True)
b += t(240, 402, "payout input", 18, MUTED)
# The selected test affects result, and is remembered at bag choice.
b += path("M 777 221 V 313", arrow=True)
b += t(801, 272, "depends on test", 18, MUTED)
b += path("M 953 173 H 1001 V 588 H 963", arrow=True)
b += f'<text transform="translate(1024,392) rotate(-90)" text-anchor="middle" font-size="18" fill="{MUTED}">test known</text>'
# Result informs the choice, which contributes to value.
b += path("M 777 407 V 532", arrow=True)
b += t(802, 477, "informs", 18, MUTED)
b += path("M 590 588 L 391 599", arrow=True)
b += t(489, 565, "payout input", 18, MUTED, anchor="middle")
# Nodes are drawn above their edge endpoints.
b += f'<ellipse cx="220" cy="173" rx="175" ry="47" fill="#edf5f5" stroke="{TEAL}" stroke-width="2"/>'
b += t(220, 181, "Unknown heavy positions", 22, weight=700, anchor="middle")
b += rect(601, 126, 352, 94, "#f2edf8", PURPLE, 2)
b += t(777, 181, "Choose a test", 24, weight=700, anchor="middle")
b += f'<ellipse cx="777" cy="360" rx="175" ry="47" fill="#edf5f5" stroke="{TEAL}" stroke-width="2"/>'
b += t(777, 368, "Scale result", 24, weight=700, anchor="middle")
b += rect(601, 541, 352, 94, "#f2edf8", PURPLE, 2)
b += t(777, 596, "Choose a bag", 24, weight=700, anchor="middle")
b += f'<path d="M 220 534 L 388 600 L 220 666 L 52 600 Z" fill="#edf5f5" stroke="{TEAL}" stroke-width="2"/>'
b += lines(220, 593, ["Payout less", "test cost"], size=22, leading=27, weight=700, anchor="middle")
b += lines(24, 714, ["Rounded: uncertain quantities     Rectangles: choices     Diamond: value", "Hidden positions are not directly observed before choosing."], size=19, leading=29, color=MUTED)
svg(9, 777, "A result has value through the choice it can change",
    "Decision network. Rounded uncertainty nodes: unknown heavy positions and scale result. Rectangular choices: choose a test and choose a bag. Diamond value: payout less test cost. Unknown positions predict the scale result and are payout inputs. Test choice determines the scale result, is known at bag choice, and contributes test cost. Scale result informs bag choice. Bag choice is a payout input. Hidden positions are not directly observed before choosing. Arrows express dependency, available information, or value inputs, not the full ontology.", b)

print(f"Wrote ten source-faithful SVG figures to {OUT}")
