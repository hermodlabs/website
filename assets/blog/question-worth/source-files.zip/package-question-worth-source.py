"""Package the essay's source materials and verify its worked arithmetic.

Run from any directory with Python 3. The input recipe records the PDF's
fictional setup; it is documentation, not an application import format.
"""

import json
import math
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent.parent
ASSETS = ROOT / "assets/blog/question-worth"


def entropy(probabilities):
    return -sum(p * math.log2(p) for p in probabilities if p)


recipe = {
    "source": "What Is a Question Worth?, 12 November 2026",
    "status": "Fictional case inputs from the essay; not physical observations or an app import file.",
    "example": "Marbles and colored bags",
    "required_identification": "Which bag should we hold?",
    "commitment_deadline_minutes": 12,
    "heavy_marble_rule": "Exactly one heavy marble across all nine marbles.",
    "number_of_bags": 3,
    "marbles_per_bag": 3,
    "reliability": "At most one incorrect result in the whole run, not per comparison; no error probabilities assumed.",
    "available_from_minute": {"all_bags": 0, "operator": 0, "balance": 0},
    "durations_minutes": {"preparation": 2, "sorting": 1, "each_weighing": 1, "each_recording": 1, "interpretation": 1, "final_choice": 1},
    "cost_per_physical_weighing_credits": 1,
    "maximum_cost_credits": 20,
    "physical_weighing_limit": None,
    "selected_plans": ["BAG-QUICK", "BAG-REPEAT", "MARBLE-EXACT"],
    "selected_requirements": ["SUFFICIENCY", "LEGAL", "COUNT", "TIME", "COST", "COVERAGE"],
    "workflow": ["Workspaces", "New workspace if necessary", "Marbles and colored bags", "Guided questions", "Update reports", "Preview reports"],
    "variations": ["Select Reliable reports: no incorrect result, update and preview; then restore the one-error bound.", "Change only the commitment deadline from minute 12 to minute 10, update and preview; then restore minute 12."],
}

counts = {"individual": 1024 - 1, "binary": math.ceil(math.log2(1024)), "ternary": math.ceil(math.log(1024, 3))}
gains = {
    "individual_check_bits": entropy([1 / 1024, 1023 / 1024]),
    "half_split_bits": entropy([0.5, 0.5]),
    "three_way_split_bits": entropy([341 / 1024, 341 / 1024, 342 / 1024]),
}
calculations = {
    "scope": "Arithmetic from the essay's stated premises. These are not recorded observations or dollar-value outputs from the app. Timing arithmetic does not itself prove a strategy's reliability.",
    "uniform_1024_entropy_bits": math.log2(1024),
    "worst_case_weighings": counts,
    "first_weighing_expected_information_gain": gains,
    "first_weighing_average_remaining_entropy_bits": {name: 10 - value for name, value in gains.items()},
    "direct_cost_at_two_credits_per_weighing": {name: count * 2 for name, count in counts.items()},
    "bag_resolution_bits": {"before_marble": 10, "before_bag": 1, "within_identified_bag": 9},
    "hypothetical_payout_game_dollars": {"red": 60, "blue_expected": 0.5 * 100 + 0.5 * 0, "best_without_test": 60, "expected_with_result": 0.5 * 100 + 0.5 * 60, "test_fee": 5, "gross_information_value": 20, "net_expected_payout": 75, "net_improvement": 15, "mixed_half_gross_value": 0},
    "app_uniform_uncertainty_bits": {"exact_marble": math.log2(9), "containing_bag": math.log2(3)},
    "app_plan_timing_arithmetic_minutes": {"BAG-QUICK_nominal_sequence_only": 2 + 1 + 1 * (1 + 1) + 1 + 1, "BAG-REPEAT_evidence_ready": 2 + 1 + 3 * (1 + 1) + 1, "BAG-REPEAT_choice_ready": 2 + 1 + 3 * (1 + 1) + 1 + 1, "MARBLE-EXACT_choice_ready": 2 + 1 + 6 * (1 + 1) + 1 + 1},
    "quick_plan_limitation": "The seven-minute nominal sequence does not establish reliable bag evidence under the global one-error bound.",
}

assert counts == {"individual": 1023, "binary": 10, "ternary": 7}
assert [round(value, 3) for value in gains.values()] == [0.011, 1.0, 1.585]
assert calculations["app_plan_timing_arithmetic_minutes"]["BAG-REPEAT_choice_ready"] == 11
assert calculations["app_plan_timing_arithmetic_minutes"]["MARBLE-EXACT_choice_ready"] == 17

for name, data in [("input-recipe.json", recipe), ("verification-calculations.json", calculations)]:
    (ASSETS / name).write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n")

readme = """What Is a Question Worth? — source materials

The PDF is the supplied essay dated 12 November 2026. Figures 11–14 are
screenshots extracted from that PDF, with page furniture cropped away.
Figures 1–10 are native SVG adaptations for the web, with the same data
and relationships. The generator is included.

input-recipe.json transcribes the article's fictional application setup.
It is a readable recipe, not an application import file.
verification-calculations.json checks the article's numerical examples.
It does not represent physical observations, error probabilities, or
economic-value fields calculated by the application.

The HTML is an Eleventy/Nunjucks source template, not the built page.
Figure dimensions are included as questionWorthFigures.json. The website
supplies its shared layout and relative-URL filters.
"""

archive = ASSETS / "source-files.zip"
with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as bundle:
    bundle.writestr("README.txt", readme)
    for source in sorted(ASSETS.iterdir()):
        if source.suffix in {".svg", ".png", ".pdf", ".json"}:
            bundle.write(source, source.name)
    for source in [ROOT / "src/blog/posts/what-is-a-question-worth.html", ROOT / "src/_data/questionWorthFigures.json", ROOT / "scripts/generate-question-worth-figures.py", Path(__file__).resolve()]:
        bundle.write(source, source.name)

print(f"Verified essay arithmetic and packaged {archive.relative_to(ROOT)}")
