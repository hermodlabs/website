"""Package the essay's source materials and verify its worked arithmetic.

Run from any directory with Python 3. The input recipe records the PDF's
fictional setup; it is documentation, not an application import format.
"""

import json
import math
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent.parent
ASSETS = ROOT / "assets/blog/question-worth"


def entropy(probabilities):
    return -sum(p * math.log2(p) for p in probabilities if p)


recipe = {
    "source": "What Is a Question Worth?, 12 November 2026; views revision 13 November 2026",
    "source_pdf": "What_Is_a_Question_Worth_Requirements_Views.pdf",
    "published_case_inspected": "2026-11-13",
    "archived_workspace_screenshots_captured": "2026-11-12",
    "status": "Fictional case inputs from the essay; not physical observations or an app import file.",
    "example": "Marbles and colored bags",
    "required_identification": "Which bag should we hold?",
    "commitment_deadline_minutes": 12,
    "heavy_marble_rule": "Exactly one heavy marble across all nine marbles.",
    "number_of_bags": 3,
    "marbles_per_bag": 3,
    "reliability": "At most one incorrect result in the whole run, not per comparison; no error probabilities assumed.",
    "available_from_minute": {"all_bags": 0, "operator": 0, "balance": 0},
    "durations_minutes": {"preparation": 2, "sorting": 1, "each_weighing": 1, "each_recording": 1, "interpretation": 1, "final_choice": 1},
    "cost_per_physical_weighing_credits": 1,
    "maximum_cost_credits": 20,
    "physical_weighing_limit": None,
    "selected_plans": ["BAG-QUICK", "BAG-REPEAT", "MARBLE-EXACT"],
    "selected_requirements": ["SUFFICIENCY", "LEGAL", "COUNT", "TIME", "COST", "COVERAGE"],
    "workflow": ["Published apps", "Use Marbles and colored bags", "Update reports"],
    "archived_screenshot_workflow": ["Workspaces", "Marbles and colored bags", "Guided questions", "Update reports", "Preview reports"],
    "illustrative_fallback_permission": "The decision owner permits an immediate hold of the handoff if identification is unresolved. This is an added illustrative operating rule.",
    "phrase_bindings": {
        "decision_question": "Which bag should we hold at the handoff?",
        "evidence_plan": "Prepare and sort; compare red with blue three times; record each report; interpret the majority using the one-error rule.",
        "evidence_condition": "A nonempty compatible explanation set under the global one-error rule, with the same containing bag b in every remaining explanation.",
        "supported_action": "Choose identified bag b; allow one minute to complete the choice.",
        "fallback_action": "Hold the handoff and record unresolved identification for review, under the added permission.",
        "usable_evidence_deadline": "Minute 11 after the case minute-0 start, reserving one minute for choice before minute 12.",
        "learning_plan_cost": "3 resource credits for three physical weighings; other scheduled work is unpriced; no monetary acquisition-cost estimate supplied."
    },
    "variations": ["Select Reliable reports: no incorrect result, update and preview; then restore the one-error bound.", "Change only the commitment deadline from minute 12 to minute 10, update and preview; then restore minute 12."],
}

counts = {"individual": 1024 - 1, "binary": math.ceil(math.log2(1024)), "ternary": math.ceil(math.log(1024, 3))}
gains = {
    "individual_check_bits": entropy([1 / 1024, 1023 / 1024]),
    "half_split_bits": entropy([0.5, 0.5]),
    "three_way_split_bits": entropy([341 / 1024, 341 / 1024, 342 / 1024]),
}
calculations = {
    "scope": "Arithmetic from the essay's stated premises. These are not recorded observations or dollar-value outputs from the app. Timing arithmetic does not itself prove a strategy's reliability.",
    "uniform_1024_entropy_bits": math.log2(1024),
    "worst_case_weighings": counts,
    "first_weighing_expected_information_gain": gains,
    "first_weighing_average_remaining_entropy_bits": {name: 10 - value for name, value in gains.items()},
    "direct_cost_at_two_credits_per_weighing": {name: count * 2 for name, count in counts.items()},
    "bag_resolution_bits": {"before_marble": 10, "before_bag": 1, "within_identified_bag": 9},
    "hypothetical_payout_game_dollars": {"red": 60, "blue_expected": 0.5 * 100 + 0.5 * 0, "best_without_test": 60, "expected_with_result": 0.5 * 100 + 0.5 * 60, "test_fee": 5, "gross_information_value": 20, "net_expected_payout": 75, "net_improvement": 15, "mixed_half_gross_value": 0},
    "app_uniform_uncertainty_bits": {"exact_marble": math.log2(9), "containing_bag": math.log2(3)},
    "app_plan_timing_arithmetic_minutes": {"BAG-QUICK_nominal_sequence_only": 2 + 1 + 1 * (1 + 1) + 1 + 1, "BAG-REPEAT_evidence_ready": 2 + 1 + 3 * (1 + 1) + 1, "BAG-REPEAT_choice_ready": 2 + 1 + 3 * (1 + 1) + 1 + 1, "MARBLE-EXACT_choice_ready": 2 + 1 + 6 * (1 + 1) + 1 + 1},
    "readiness_and_limits": {"planned_evidence_ready_minute": 10, "latest_usable_evidence_minute": 12 - 1, "commitment_deadline_minute": 12, "choice_ready_minute": 11, "slack_minutes": 12 - 11, "priced_resource_consumption_credits": 3, "resource_ceiling_credits": 20},
    "modeled_world_report_paths": {plan: 9 * (1 + 2 * n) for plan, n in [("BAG-QUICK", 1), ("BAG-REPEAT", 3), ("MARBLE-EXACT", 6)]},
    "path_count_basis": "Nine heavy-marble worlds; for n ternary reports at most one error gives one all-correct sequence plus two alternatives at each of n positions. These are modeled paths, not observed trials, probabilities, or empirical success rates.",
    "quick_plan_limitation": "The seven-minute nominal sequence does not establish reliable bag evidence under the global one-error bound.",
}

assert counts == {"individual": 1023, "binary": 10, "ternary": 7}
assert [round(value, 3) for value in gains.values()] == [0.011, 1.0, 1.585]
assert calculations["app_plan_timing_arithmetic_minutes"]["BAG-REPEAT_choice_ready"] == 11
assert calculations["app_plan_timing_arithmetic_minutes"]["MARBLE-EXACT_choice_ready"] == 17

assert calculations["modeled_world_report_paths"] == {"BAG-QUICK": 27, "BAG-REPEAT": 63, "MARBLE-EXACT": 117}

trace = {
    "scope": "Illustrative analyst derivation from the supplied essay revision, not an application import file or newly observed app behavior.",
    "Q0": "Which complete investigation plan establishes which bag to hold and leaves time to complete that choice by minute 12, within the available resources?",
    "requirements": [
        {"question": "Q1: Could the reported bag be the permitted incorrect result?", "id": "R1", "app_column": "SUFFICIENCY", "statement": "The plan shall establish the required bag for every permitted world/report path."},
        {"question": "Q2: Is each proposed comparison physically valid?", "id": "R2", "app_column": "LEGAL", "statement": "Each reachable weighing shall place equal positive numbers of marbles from disjoint sets on its two pans. Containers contribute no weight."},
        {"question": "Q3: Does the physical operation count exceed a supplied limit?", "id": "R3", "app_column": "COUNT", "statement": "If supplied, the physical-weighing limit shall not be exceeded on any permitted path. No limit is supplied here; its status is not applicable."},
        {"question": "Q4: Is there time to complete the choice after adequate evidence?", "id": "R4", "app_column": "TIME", "statement": "The plan shall make sufficient evidence usable and complete the final choice by minute 12."},
        {"question": "Q5: Does the plan fit the resource allowance?", "id": "R5", "app_column": "COST", "statement": "The plan shall consume at most 20 modeled resource credits on any permitted path."},
        {"question": "Q6: Are all permitted paths accounted for?", "id": "R6", "app_column": "COVERAGE", "statement": "The assessment shall cover all permitted world/report paths for the proposed policy."}
    ],
    "basis_matrix": {"columns": ["R1", "R2", "R3", "R4", "R5", "R6"], "BAG-QUICK": ["conflict", "satisfied", "not_applicable", "not_established", "satisfied", "satisfied"], "BAG-REPEAT": ["satisfied", "satisfied", "not_applicable", "satisfied", "satisfied", "satisfied"], "MARBLE-EXACT": ["satisfied", "satisfied", "not_applicable", "conflict", "satisfied", "satisfied"]},
    "views": {"V1": "Plan comparison", "V2": "Requirements", "V3": "Finding detail pane", "V4": "Evidence timing", "V5": "Evidence & sources", "V6": "Context & model"},
    "review_boundary": "Requirements validation reviews the need and assumptions. Candidate verification checks a plan against them. Fit does not rank economic value or grant execution authority."
}

for name, data in [("input-recipe.json", recipe), ("verification-calculations.json", calculations), ("requirements-trace.json", trace)]:
    (ASSETS / name).write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n")

readme = """What Is a Question Worth? — source materials

The PDF is the supplied essay dated 12 November 2026, with its views revision
of 13 November 2026. The stable PDF asset contains the exact supplied revised
file. Figures 11–14 are screenshots extracted from revised PDF pages 25–28,
with page headings and captions cropped away. Their extent matches the new
PDF, including its cropped plan-comparison screenshot. The Swift extractor
and native SVG generator are included. Figures 1–10 are native SVG
adaptations preserving the source data and relationships in revised order;
the shared ontology is now figure 10. The SVG cover is unchanged.

The revision develops the Learn enough before committing pattern, seven
named slots and their marble bindings, Q0–Q6, R1–R6 with acceptance rules,
and V1–V6 before the final existing-app walkthrough. requirements-trace.json
retains the illustrative derivation and basis matrix. The worked fallback
permission is an added illustrative operating rule, explicitly distinguished
from observed app behavior.

The published case was inspected on 13 November 2026 in the source. The
archived workspace-preview screenshots remain dated 12 November 2026.

input-recipe.json transcribes the article's fictional application setup.
It is a readable recipe, not an application import file.
verification-calculations.json checks the article's numerical examples.
It does not represent physical observations, error probabilities, or
economic-value fields calculated by the application.

The HTML is an Eleventy/Nunjucks source template, not the built page.
Figure dimensions are included as questionWorthFigures.json. The website
supplies its shared layout and relative-URL filters.
"""

archive = ASSETS / "source-files.zip"
with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as bundle:
    bundle.writestr("README.txt", readme)
    for source in sorted(ASSETS.iterdir()):
        if source.suffix in {".svg", ".png", ".pdf", ".json"}:
            bundle.write(source, source.name)
    for source in [ROOT / "src/blog/posts/what-is-a-question-worth.html", ROOT / "src/_data/questionWorthFigures.json", ROOT / "scripts/generate-question-worth-figures.py", ROOT / "scripts/extract-question-worth-screenshots.swift", Path(__file__).resolve()]:
        bundle.write(source, source.name)

print(f"Verified essay arithmetic and packaged {archive.relative_to(ROOT)}")
