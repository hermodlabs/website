# Continue a campaign and retain actual operating records

The CLI and React desk use custom calculation workflow
`resolve-gift-kit-handoff` **4.1.0**. They exchange the same ordinary native run.
The Marketplace's flexible and earliest workflows have different identities and
pins; their exported runs are not inputs to this desk.

Use Node 22.19+ and install the matching SDK, CLI and React-view archives as
each client README describes. All campaigns and received records below are
fictional. The commands record supplied assertions; they do not authenticate a
source, authorize production or perform a handoff.

## Screen and open one campaign

From `gift-kit-preflight/`, use a fresh output directory:

```sh
node review-journeys.mjs --input fixtures/journey-v4/campaigns.json \
  --output .output/article-1
```

Open `.output/article-1/campaigns.html`. GIFT-321's current scoped diagnostics
require complete correction. At minute 1,410, its $400 external package can
finish by 1,435; the $300 in-house package would miss the 1,440 cutoff. Missing
or old-revision bookings in other campaigns remain blockers. The $100 response
is supported only in GIFT-324, whose actual diagnostics narrow the fault basis.

From `gift-kit-handoff-desk/` in a second terminal:

```sh
npm run dev
```

Use **Open continuing review** to import
`gift-kit-preflight/.output/article-1/GIFT-321/review.workflow.json`. Read
**Decision summary**, then inspect the exact external arrangement. Importing
retains the source receipts and two native evaluations; it creates no reviewer
identity, operating choice or completed work.

Apply changed business records before recalculating. Pending drafts remain
separate from the portable applied case. Inspection changes no choice.

## Record a choice and the linked actual work

The [received-record fixtures](gift-kit-preflight/fixtures/received-records/README.md)
contain a separate $400 authorization, completed correction, successful fresh
rehearsal and kit handoff. Use these same values in the desk's operating-event
form, or reproduce the sequence through the existing CLI below.

For the browser route, name the person recording the choice and choose
**External replacement and repair**. Record each event independently. The
authorization and correction input cover `insert-4`, `destination-2` and
`checkout-1`. The correction output is `insert-5`, `destination-3` and
`checkout-2`; the rehearsal and handoff must name that corrected scope. Link
the rehearsal to `WORK-ACTUAL-321`, then the handoff to `TEST-ACTUAL-321`.
Planning a rehearsal does not record a pass.

For the headless route, start with the same screened native run and execute
from `gift-kit-preflight/`:

```sh
node continue-review.mjs --review .output/article-1/GIFT-321/review.workflow.json \
  --choose external-replace-and-repair --actor 'Fictional production coordinator' \
  --output .output/article-choice-1
node continue-review.mjs --review .output/article-choice-1/review.workflow.json \
  --kind authorization --record fixtures/received-records/authorization.json \
  --actor 'Fictional production coordinator' --recorded-at 2026-11-18T23:30:00.000Z \
  --output .output/article-authorized-1
node continue-review.mjs --review .output/article-authorized-1/review.workflow.json \
  --kind correction --record fixtures/received-records/correction.json \
  --actor 'Fictional production coordinator' --recorded-at 2026-11-18T23:40:00.000Z \
  --output .output/article-corrected-1
node continue-review.mjs --review .output/article-corrected-1/review.workflow.json \
  --kind rehearsal --record fixtures/received-records/rehearsal.json \
  --actor 'Fictional production coordinator' --recorded-at 2026-11-18T23:50:00.000Z \
  --output .output/article-rehearsed-1
node continue-review.mjs --review .output/article-rehearsed-1/review.workflow.json \
  --kind handoff --record fixtures/received-records/handoff.json \
  --actor 'Fictional production coordinator' --recorded-at 2026-11-18T23:55:00.000Z \
  --output .output/article-handoff-1
```

Each directory must be new. Only the complete linked chain supports the recorded
original handoff. The assessment clock remains at minute 1,410: actual events
do not rewrite the earlier decision basis. Import the final
`.output/article-handoff-1/review.workflow.json` into the desk to inspect its
native history and authored completion finding.

A later failed rehearsal must supersede the earlier pass. To demonstrate that
separate continuation:

```sh
node continue-review.mjs --review .output/article-handoff-1/review.workflow.json \
  --kind rehearsal --record fixtures/received-records/later-failed-rehearsal.json \
  --actor 'Fictional production coordinator' --recorded-at 2026-11-18T23:56:00.000Z \
  --output .output/article-later-failed-1
```

The earlier records remain in history; the earlier positive no longer proves a
current complete handoff. Recovery requires genuinely supplied valid records
and a linked chain, rather than falling back to the old pass.

## Return the browser's exact case to CLI

Download **Continuing review** from the desk, then from `gift-kit-preflight/`:

```sh
node continue-review.mjs --review /absolute/path/to/downloaded-review.workflow.json \
  --output .output/article-return-1
```

This reopens the same run, definition, sources and operating history. Do not
import the original campaign fixture over a changed desk case. Advance an
unstarted planning opportunity explicitly with `--as-of`; changing a planning
clock is distinct from recording work against a historical choice.

The existing production browser check accepts `GIFT_PREFLIGHT_REVIEW` pointing
to a CLI-exported run and retains exact-hash import evidence. Its narrow captures
include urgent external correction, stale booking, evidence-supported smaller
correction, chosen response, completed handoff and later failed rehearsal. Keep
the selected image, native run and capture receipt together when using them in
an article.
