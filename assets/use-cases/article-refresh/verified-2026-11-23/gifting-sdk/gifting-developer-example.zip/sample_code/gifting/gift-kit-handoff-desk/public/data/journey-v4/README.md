# Calculation-mode gift-kit integration release

The current workflow is version 4.1.0. Frozen evidence/planning apps, their version 3 configuration and worked cases remain unchanged. Synchronize and verify the authored current definition with `node scripts/build-integration-calculation-journeys.mjs [--check]` from the repository root. The preceding calculation 4.0.0 remains under `workflow-releases/4.0.0`; the reviewed workflow and its authoring receipts remain in `journey-v3`. These custom integration runs are distinct from the Marketplace gifting workflows.
