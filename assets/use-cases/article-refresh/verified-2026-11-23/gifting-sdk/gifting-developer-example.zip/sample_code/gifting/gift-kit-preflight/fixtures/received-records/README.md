# Fictional received operating records

These complete current-status records extend GIFT-321 from the current
`journey-v4/cases/urgent-window.json` teaching case. They do not replace its
original diagnostic scope or planning inputs. Follow the domain
[continuation recipe](../../../CONTINUATION.md) to record them through the
existing CLI or React desk.

| Record | Actual assertion | Event minute / UTC time on November 18, 2026 |
| --- | --- | --- |
| `authorization.json` | $400 authorization for the original input scope | 1,410 / 23:30 |
| `correction.json` | All 120 kits corrected; original input scope links to the declared new output revisions | 1,420 / 23:40 |
| `rehearsal.json` | Ten-minute successful rehearsal on that corrected output, linked to the correction reference | 1,430 / 23:50 |
| `handoff.json` | 120 corrected kits handed off, linked to the passed rehearsal | 1,435 / 23:55 |
| `later-failed-rehearsal.json` | A subsequent rehearsal on the same corrected scope failed | 1,436 / 23:56 |

All times are whole elapsed minutes from `2026-11-18T00:00:00.000Z`. The original
handoff cutoff is minute 1,440. `--recorded-at` supplies the separate time someone
recorded each assertion and must not precede the event it describes. These
fixtures use equal event and recording times for a deterministic teaching run.

Each file is supplied source data, not an authenticated production document.
The native workflow retains the assertion and checks its scope, chronology,
result and links. A changed reference or scope must come from a real replacement
record in an actual integration; recording a label does not perform the work.
