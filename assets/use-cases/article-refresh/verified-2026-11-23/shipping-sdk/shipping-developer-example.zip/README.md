# Shipping developer example

This snapshot pairs the CLI and React clients and includes the exact local SDK, CLI and React-view candidate archives used for this article refresh. It does not claim an npm publication. All business inputs are fictional.

Use Node 24.16.0 (the documented minimum is Node 22.19). From this directory run `npm install`, then follow `sample_code/shipping/CONTINUATION.md`. Keep both client directories as siblings so the cross-client browser test can import the CLI example. To run the React app, use `npm --prefix sample_code/shipping/shipment-reservation-desk run dev`.

The browser verification was performed against the matching workspace production build; the source/package identities and native results are linked separately in the article capture record. Original retained qualification receipts describe their own older builds.
