# Continue a shipment exception from CLI to React

This recipe uses the custom `resolve-shipment-exception` calculation workflow
**2.1.0**, not the Marketplace registration-and-verification workflow. All
records are fictional. Calculation, operating choice, spending authority,
carrier reservation and delivery remain separate.

Copy `shipment-exceptions/` and `shipment-reservation-desk/` together, retaining
their sibling directory names. Install the matching SDK, CLI and React-view
archives in each folder as its README describes. Use Node 22.19+; Node 24 is
recommended. The two runtimes can run independently, but the desk's production
browser check intentionally exercises the sibling CLI.

## Screen and open the same case

From `shipment-exceptions/`, choose a fresh output directory:

```sh
node run-demo.mjs --output .output/article-1
```

Open `.output/article-1/morning/shipments.html`. SHIP-105 has a real Direct
capacity shortfall and a Consolidated slot covering order revision 1 instead
of revision 2. No supplied arrangement passes. SHIP-107 is a separate input
error, not another blocked shipment; the demo checks that distinction.

From `shipment-reservation-desk/` in a second terminal:

```sh
npm run dev
```

Use **Import case** to import the CLI's
`.output/article-1/morning/shipments/SHIP-105/review.json`. The exact definition,
source receipts, original promise and calculated finding travel with the run.
Opening it requires no analytical signoff or new calculation.

## Apply a received confirmation

The supplied [replacement record](shipment-exceptions/fixtures/received-records/SHIP-105-slot-revision-2.json)
explicitly covers revision 2. In the desk's confirmation form, enter its
`slotConfirmation` values. Keep its own order, revision, destination, shipment
date, ship point and validity; do not copy scope from the current order to an
unrelated document. The whole-minute times use November 17, 2026 at UTC−06:00.

| Control | Received value |
| --- | --- |
| Confirmation reference | `SLOT-SHIP-105-REV2` |
| Confirmation order / revision | `ORD-105` / `2` |
| Destination / ship point | `DC-X` / `SP-B` |
| Shipment date / profile | `2026-11-18` / `1.0.0` |
| Confirmation status | Confirmed |
| Confirmed / known at | November 17, 07:55 / 08:00 |
| Valid from / until (exclusive) | November 17, 23:00 / November 18, 00:00 |

Choose **Apply inputs**, then **Recalculate**. The $5,000 Consolidated
arrangement now passes and is preferred. A replacement slot does not create
separate spending or release permissions; the supplied case already contains
those records. **Inspect** opens supporting findings without choosing it.

For a headless reproduction of the same source edit, run these commands from
`shipment-exceptions/` instead of editing the browser case:

```sh
node --input-type=module <<'JS'
import { readFile, writeFile } from 'node:fs/promises';
const run = JSON.parse(await readFile('.output/article-1/morning/shipments/SHIP-105/review.json', 'utf8'));
const received = JSON.parse(await readFile('fixtures/received-records/SHIP-105-slot-revision-2.json', 'utf8'));
const inputs = structuredClone(run.case.inputs);
inputs.tables.slotConfirmations = [received.slotConfirmation];
inputs.provenance.push({ id: received.slotConfirmation.slotReference, description: received.source });
await writeFile('.output/article-1/replacement-inputs.json', JSON.stringify(inputs), { flag: 'wx' });
JS
npx --no-install decision-lab workflow answer \
  --run .output/article-1/morning/shipments/SHIP-105/review.json \
  --question inputs --status supplied --value .output/article-1/replacement-inputs.json \
  --at 2026-11-17T14:00:00.000Z --output .output/article-1/received.run.json
node continue-review.mjs --review .output/article-1/received.run.json \
  --created-at 2026-11-17T14:00:00.000Z --output .output/article-fixed-1
```

Import `.output/article-fixed-1/review.json` into the desk to continue that
recalculated native history. This is an alternative reproduction, not a second
shipment or a command to import the original CSVs over an edited desk case.

## Retain the operating handoff

Separately name the recorder and choose Consolidated. The actual-event form
can retain an external authorization and quote-linked carrier reservation.
Enter only the source document's values; a calculation does not supply them.
A recorded reservation still leaves delivery incomplete.

Download **Continuation**. From `shipment-exceptions/`, reopen that downloaded
file in a fresh directory:

```sh
node continue-review.mjs --review /absolute/path/to/downloaded-continuation.json \
  --output .output/article-return-1
```

The CLI retains the same run identity and event history. Reopening current
findings does not create another assessment or book freight again. To inspect
a later unbooked opportunity, use a separate continuation with explicit
`--as-of 2026-11-17T11:30:00-06:00`; changing the business clock makes dependent
findings stale. Do not use that clock change to stand in for work performed.

The existing production browser check captures the queue, blocked finding,
applied revision-2 confirmation and separate reservation. From the desk folder:

```sh
npm run test:browser
```

Use those narrow states for the article. Keep the native continuation and its
capture receipt beside the image; a reservation screenshot does not prove
delivery or authenticate the fictional source.
