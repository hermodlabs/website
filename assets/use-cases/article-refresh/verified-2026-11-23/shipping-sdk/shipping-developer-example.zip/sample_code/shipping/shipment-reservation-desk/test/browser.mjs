/**
 * Exercise the copied, production-built client through its public interface.
 *
 * The CLI is only a test oracle here. The browser application never imports it:
 * its worker executes the installed SDK, and this test compares the resulting
 * retained reports with the same cases evaluated by the public CLI command.
 */
import assert from 'node:assert/strict';
import { existsSync } from 'node:fs';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { build, preview } from 'vite';
import { createHash } from 'node:crypto';
import { createServer as createHTTPServer } from 'node:http';
import { runBatch } from '../../shipment-exceptions/src/batch.mjs';
import { chromium } from 'playwright';
import { runCLI } from '@decision-lab/cli';
import { createDecisionLab } from '@decision-lab/sdk';

const root = fileURLToPath(new URL('../', import.meta.url));
const output = path.resolve(process.env.SHIPMENT_CAPTURE_DIR || path.join(root, '.output'));
const temporary = await fs.mkdtemp(path.join(os.tmpdir(), 'reservation-desk-browser-'));
const checks = [];
const originalNodeEnv = process.env.NODE_ENV;
let browser, server, observedPage;

const json = async filename => JSON.parse(await fs.readFile(filename, 'utf8'));
const cells = row => Object.fromEntries(Object.entries(row.cells).map(([key, cell]) => [key, cell.raw]));
const escapeRegex = value => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// Read the SDK's prepared report. These are calculated facts, not shipment rules.
function outcome(run) {
  assert.equal(run.format, 'decision-lab-run/1');
  assert.equal(run.execution.status, 'completed');
  assert.equal(run.report.completeness.assessmentComplete, true);
  assert.equal(run.report.completeness.truncated, false);
  const report = run.report;
  const dataset = report.datasets.commitment;
  assert.equal(dataset.assessment.coverage.complete, true);
  const contexts = report.contextIndexes.planScenarios.entries;
  const sectionTables = sectionId => dataset.sections[sectionId].map(section => report.datasets[section.datasetId]).filter(table => table?.kind === 'table');
  const tableWith = (sectionId, keys) => {
    const tables = sectionTables(sectionId).filter(table => keys.every(key => table.columns.some(column => column.id === key)));
    assert.equal(tables.length, 1);
    return tables[0];
  };
  const preferred = dataset.summary.recommendation?.tiedPlanIds ?? [];
  const plans = report.datasets['commitment:comparison'].rows.map(row => {
    const comparison = cells(row);
    const plan = dataset.plans.find(candidate => candidate.id === row.id);
    const situations = contexts.filter(context => context.planId === row.id).map(context => {
      const failedChecks = tableWith(context.sections.checks, ['check', 'status']).rows
        .filter(check => check.cells.status.raw === false).map(check => check.id).sort();
      const arrival = tableWith(context.sections.schedule, ['value', 'result']).rows.find(value => value.id === 'arrival');
      assert.ok(arrival);
      return { scenarioId: context.scenarioId, arrival: arrival.cells.result.raw, failedChecks };
    });
    return { arrangement: comparison['choice:arrangement'], feasible: plan.feasible, preferred: preferred.includes(row.id), expense: comparison.expense, situations };
  }).sort((a, b) => a.arrangement.localeCompare(b.arrangement));
  return { finding: run.assessment.finding, plans };
}

async function cliRun(caseFile, name) {
  const filename = path.join(temporary, `${name}.run.json`);
  let stderr = '';
  const code = await runCLI(['run', '--app', path.join(root, 'public/data/shipment-review.app.json'), '--case', caseFile,
    '--reports', 'all', '--run-id', `reservation-desk-browser-${name}`, '--created-at', '2026-11-17T14:00:00.000Z',
    '--timeout-ms', '30000', '--output', filename], {
    stdout: { write() {} }, stderr: { write(chunk) { stderr += chunk; } },
  });
  assert.equal(code, 0, `CLI ${name}: ${stderr}`);
  return json(filename);
}

async function downloadRun(page) {
  const [download] = await Promise.all([
    page.waitForEvent('download', { timeout: 45_000 }),
    page.getByRole('button', { name: 'Download SDK run', exact: true }).click({ timeout: 45_000 }),
  ]);
  const filename = await download.path();
  assert.ok(filename, 'The browser retained the complete review download.');
  const run = await json(filename);
  assert.equal(run.format, 'decision-lab-run/1');
  assert.ok(run.report, 'The download retains the native SDK report, not an application-specific wrapper.');
  return run;
}


const artifacts = [], exports = {};
const lab = createDecisionLab();
const operating = run => lab.workflows.output({ run }).brief.sections.find(section => section.id === 'actual-shipment').value;
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
async function apply(page) {
  const button = page.getByRole('button', { name: 'Apply inputs', exact: true });
  if (await button.isEnabled()) await button.click();
}
async function calculate(page) {
  await apply(page);
  const button = page.getByRole('button', { name: /^(Calculate|Recalculate)$/ });
  if (await button.isDisabled()) return false;
  await button.click();
  await page.getByRole('button', { name: 'Download SDK run', exact: true }).waitFor();
  await page.waitForFunction(() => ![...document.querySelectorAll('button')].find(node => node.textContent.trim() === 'Download SDK run')?.disabled);
  return true;
}
async function continuation(page, key) {
  const [download] = await Promise.all([page.waitForEvent('download'), page.getByRole('button', { name: 'Download continuation', exact: true }).click()]);
  const bytes = await fs.readFile(await download.path());
  const name = `${key}.workflow-run.json`;
  await fs.writeFile(path.join(output, name), bytes);
  const value = JSON.parse(bytes); exports[key] = { file: name, sha256: sha(bytes), runId: value.identity.runId, contentHash: value.contentHash };
  return value;
}
async function capture(page, key, target = '.results-panel') {
  await page.evaluate(() => document.activeElement?.blur());
  const locator = target ? page.locator(target) : null;
  const filename = `${key}.png`;
  const bytes = locator ? await locator.screenshot({ animations: 'disabled', caret: 'hide' }) : await page.screenshot({ fullPage: true, animations: 'disabled', caret: 'hide' });
  await fs.writeFile(path.join(output, filename), bytes);
  artifacts.push({ key, file: filename, sha256: sha(bytes), width: bytes.readUInt32BE(16), height: bytes.readUInt32BE(20), viewport: page.viewportSize(), target });
}
async function pageFlow(page, viewport) {
  await page.setViewportSize(viewport);
  const result = await page.evaluate(() => ({ viewport: innerWidth, width: document.documentElement.scrollWidth,
    nestedScroll: [...document.querySelectorAll('main, section, article, aside, [role="region"]')].filter(element => ['auto', 'scroll'].includes(getComputedStyle(element).overflowY) && element.scrollHeight > element.clientHeight + 2).map(element => element.className) }));
  assert.ok(result.width <= result.viewport + 1, JSON.stringify(result)); assert.deepEqual(result.nestedScroll, []);
}
let queueServer;
try {
  await fs.mkdir(output, { recursive: true });
  const cliRoot = path.resolve(root, '../shipment-exceptions');
  const shared = { retainedDir: path.join(cliRoot, 'fixtures/retained/baseline'), inputDir: path.join(cliRoot, 'fixtures/baseline') };
  const batchSource = process.env.SHIPMENT_BATCH_SOURCE;
  async function retainedBatch(name) {
    const outputDir = path.resolve(batchSource, name);
    const manifest = await json(path.join(outputDir, 'manifest.json'));
    for (const row of manifest.rows) for (const receipt of Object.values(row.artifacts ?? {})) {
      const bytes = await fs.readFile(path.join(outputDir, receipt.file));
      assert.equal(sha(bytes), receipt.sha256, `Retained CLI artifact unchanged: ${receipt.file}`);
    }
    return { outputDir, manifest, exitCode: manifest.exitCode };
  }
  const baseline = batchSource ? await retainedBatch('baseline-batch') : await runBatch({ ...shared, outputDir: path.join(output, 'baseline-batch'), createdAt: '2026-11-17T14:00:00Z' });
  const late = batchSource ? await retainedBatch('late-batch') : await runBatch({ ...shared, asOf: '2026-11-17T11:30:00-06:00', outputDir: path.join(output, 'late-batch'), createdAt: '2026-11-17T17:30:00Z', previousFile: path.join(baseline.outputDir, 'manifest.json') });
  const morning = batchSource ? await retainedBatch('morning-batch') : await runBatch({ inputDir: path.join(cliRoot, 'fixtures/morning'), retainedDir: path.join(cliRoot, 'fixtures/retained/morning'), outputDir: path.join(output, 'morning-batch'), createdAt: '2026-11-17T14:05:00Z', previousFile: path.join(baseline.outputDir, 'manifest.json') });
  assert.equal(baseline.exitCode, 0); assert.equal(late.exitCode, 0); assert.equal(morning.exitCode, 2);
  checks.push('Actual public CLI batch: baseline Direct; late booking clock Consolidated; morning source errors and blocked findings remain separate');
  await build({ configFile: path.join(root, 'vite.config.mjs') });
  server = await preview({ configFile: path.join(root, 'vite.config.mjs'), preview: { host: '127.0.0.1', port: 0, strictPort: false } });
  const address = server.httpServer.address(); const base = `http://127.0.0.1:${address.port}/`;
  browser = await chromium.launch({ headless: true, executablePath: process.env.HERMOD_CHROMIUM_PATH || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const context = await browser.newContext({ acceptDownloads: true, serviceWorkers: 'block', viewport: { width: 1600, height: 1100 } });
  await context.route('**/*', route => route.request().url().startsWith(base) ? route.continue() : route.abort());
  const page = await context.newPage(), errors = [], workers = []; observedPage = page;
  page.on('pageerror', error => errors.push(error.message)); page.on('worker', worker => workers.push(worker.url()));
  await page.goto(base);
  await page.getByRole('button', { name: 'Calculate', exact: true }).waitFor();
  assert.equal(await page.getByLabel('Recorded reviewer', { exact: true }).count(), 0);
  assert.equal(await page.getByRole('button', { name: /Accept reviewed/ }).count(), 0);
  const config = await json(path.join(root, 'public/data/config.json'));
  const selectCase = async id => {
    await page.getByRole('button', { name: new RegExp(escapeRegex(config.cases.find(value => value.id === id).label)) }).click();
    await page.waitForFunction(() => [...document.querySelectorAll('button')].some(node => node.textContent.trim() === 'Calculate' && !node.disabled));
  };
  for (const [id, preferred] of Object.entries({ confirmed: ['direct'], revised: [], permissions: [], urgent: ['consolidated'] })) {
    await selectCase(id); await calculate(page); const run = await downloadRun(page);
    assert.deepEqual(outcome(run), outcome(await cliRun(path.join(root, `public/data/cases/${id}.json`), id)));
    assert.deepEqual(outcome(run).plans.filter(plan => plan.preferred).map(plan => plan.arrangement).sort(), preferred);
    checks.push(`${id}: production browser worker and public CLI agree on every arrangement and failed requirement`);
  }
  const importReview = async file => { await page.getByLabel('Import canonical case JSON', { exact: true }).setInputFiles(file); await page.waitForFunction(() => !document.querySelector('[role=alert]'));  await page.getByRole('button', { name: 'Download SDK run', exact: true }).waitFor(); await page.waitForFunction(() => ![...document.querySelectorAll('button')].find(node => node.textContent.trim() === 'Download SDK run')?.disabled); };
  const reportGroups = () => page.getByRole('tablist', { name: 'Report views', exact: true });
  const summaryTab = () => reportGroups().getByRole('tab', { name: 'Decision summary', exact: true }).click();
  await importReview(path.join(baseline.outputDir, 'shipments/SHIP-104/review.json')); await summaryTab();
  assert.deepEqual(await reportGroups().getByRole('tab').allTextContents(), ['Decision summary', 'Supporting reports', 'Decision process']);
  assert.deepEqual(await page.getByRole('tablist', { name: 'Decision summary sections', exact: true }).getByRole('tab').allTextContents(), ['Options', 'Next actions', 'Assumptions', 'Questions']);
  let value = await continuation(page, 'baseline');
  assert.equal(value.definition.execution.mode, 'calculation'); assert.equal(value.reviews.length, 0); assert.equal(value.answers.inputs.status, 'supplied');
  assert.deepEqual(outcome(await downloadRun(page)).plans.filter(plan => plan.preferred).map(plan => plan.arrangement), ['direct']);
  await capture(page, 'baseline');
  const runHash = value.contentHash;
  await page.locator('[data-decision-summary]').getByRole('button', { name: 'Inspect Direct', exact: true }).click();
  await page.locator('[data-question-view="integration-arrangements"] [data-inspected-key]').waitFor();
  assert.match(await page.locator('[data-question-view="integration-arrangements"] [data-inspected-key]').getAttribute('data-inspected-key'), /plan-000001/);
  await capture(page, 'supporting-direct');
  await reportGroups().getByRole('tab', { name: 'Decision process', exact: true }).click();
  await page.locator('[data-decision-process]').waitFor(); await capture(page, 'decision-process');
  await page.getByRole('button', { name: 'Inspect calculation dependencies', exact: true }).click();
  await page.locator('[data-workflow-map]').waitFor(); await capture(page, 'calculation-dependencies');
  assert.equal((await continuation(page, 'inspected')).contentHash, runHash, 'Inspecting tabs never changes choices, inputs or native run history.');
  checks.push('Native Decision summary Inspect selects the exact option; Supporting reports, Decision process and dependencies preserve run identity');
  await importReview(path.join(late.outputDir, 'shipments/SHIP-104/review.json')); await summaryTab();
  await capture(page, 'late-cutoff'); await continuation(page, 'late-cutoff');
  assert.deepEqual(outcome(await downloadRun(page)).plans.filter(plan => plan.preferred).map(plan => plan.arrangement), ['consolidated']);
  await importReview(path.join(morning.outputDir, 'shipments/SHIP-105/review.json')); await summaryTab();
  await capture(page, 'blocked'); await continuation(page, 'blocked');
  const blockedRun = await downloadRun(page); assert.equal(outcome(blockedRun).plans.some(plan => plan.feasible), false);
  // Ordinary source-record edits: the fictional replacement explicitly covers revision 2.
  await page.getByLabel('Confirmation reference', { exact: true }).fill('SLOT-SHIP-105-REV2');
  const orderRevision = page.getByLabel('Confirmation order revision', { exact: true });
  if (!(await orderRevision.isVisible())) await page.locator('details').filter({ has: page.getByText('Order and location covered by this record', { exact: true }) }).locator('summary').click();
  await orderRevision.fill('2');
  assert.equal(await page.getByRole('button', { name: 'Recalculate', exact: true }).isDisabled(), true);
  assert.equal(await page.getByRole('button', { name: 'Download SDK run', exact: true }).isDisabled(), true);
  await capture(page, 'pending');
  await apply(page); await page.locator('[data-summary-status="stale"]').waitFor(); await capture(page, 'stale');
  await calculate(page); const fixed = await downloadRun(page);
  assert.deepEqual(outcome(fixed).plans.filter(plan => plan.preferred).map(plan => plan.arrangement), ['consolidated']);
  assert.deepEqual(fixed.input.inputs.tables.grants, blockedRun.input.inputs.tables.grants, 'A new confirmation does not manufacture separate permissions.');
  await capture(page, 'confirmed-revision'); await continuation(page, 'confirmed-revision');
  const fixedFile = path.join(output, 'confirmed-revision.case.json'); await fs.writeFile(fixedFile, JSON.stringify(fixed.input.inputs));
  assert.deepEqual(outcome(fixed), outcome(await cliRun(fixedFile, 'confirmed-revision')));
  checks.push('Genuine revision-2 confirmation: pending draft disables calculation; Apply makes the retained result stale; Recalculate changes blocked to Consolidated without changing permissions');
  await page.getByRole('button', { name: 'Save this review locally', exact: true }).click();
  await page.getByRole('alert').filter({ hasText: 'Review saved locally with its history and app version.' }).waitFor();
  const saved = await continuation(page, 'saved');
  await page.getByLabel('Confirmation reference', { exact: true }).fill('UNAPPLIED-DRAFT');
  await page.getByRole('button', { name: 'Restore saved review', exact: true }).click();
  await page.waitForFunction(() => [...document.querySelectorAll('input')].some(node => node.value === 'SLOT-SHIP-105-REV2'));
  assert.equal(await page.getByLabel('Confirmation reference', { exact: true }).inputValue(), 'SLOT-SHIP-105-REV2');
  assert.equal((await continuation(page, 'restored')).contentHash, saved.contentHash);
  checks.push('Save and reopen preserve applied inputs, findings, exact workflow version and history; unapplied form edits are discarded only by explicit restore');
  await page.getByLabel('Arrangement to hand off', { exact: true }).selectOption('consolidated');
  await page.getByRole('button', { name: 'Record chosen response', exact: true }).click();
  const chosen = await continuation(page, 'chosen'); assert.equal(chosen.case.journeyOperations.at(-1).kind, 'decision');
  await capture(page, 'chosen', '.review-column');
  const p = fixed.input.inputs.parameters, q = fixed.input.inputs.tables.arrangements.find(row => row.id === 'consolidated');
  await page.locator('details').filter({ has: page.getByText('Record an actual operating event or escalation', { exact: true }) }).locator('summary').click();
  const scope = { 'Event order': p.orderId, 'Event order revision': p.orderRevision, 'Event arrangement': 'consolidated', 'Event destination': p.recipient, 'Event shipment date': p.shipDate, 'Event profile version': p.profileVersion, 'Event ship point': q.shipPoint, 'Source of the received document': 'Fictional current carrier and operating records' };
  for (const [label, input] of Object.entries(scope)) await page.getByLabel(label, { exact: true }).fill(input);
  async function event(kind, reference, fields, positive = true) {
    await page.getByLabel('Event', { exact: true }).selectOption(kind);
    await page.getByLabel('External source reference', { exact: true }).fill(reference);
    await page.getByLabel('Document records a successful result', { exact: true }).selectOption(String(positive));
    for (const [label, input] of Object.entries(fields)) await page.getByLabel(label, { exact: true }).fill(input);
    await page.getByRole('button', { name: 'Record received event', exact: true }).click();
  }
  await event('authorization', 'FIN-SHIP-105', { 'Authorized amount (USD)': '5000', 'Actual authorization time': '2026-11-17T08:05', 'Authority valid from': '2026-11-17T08:00', 'Authority valid until (exclusive)': '2026-11-17T12:01' });
  await event('reservation', 'BOOK-SHIP-105', { 'Booked quote reference': q.quoteId, 'Booked quote revision': q.quoteRevision, 'Actual carrier reservation time': '2026-11-17T08:10' });
  const reserved = await continuation(page, 'reserved');
  assert.equal(operating(reserved).reservationRecorded, true);
  const received = reserved.case.journeyOperations.at(-1);
  assert.ok(Date.parse(received.record.recordedAt) % 60000 !== 0, 'The ordinary browser clock supplies seconds and milliseconds.');
  assert.equal(Date.parse(received.at) % 60000, 0);
  assert.ok(Date.parse(received.at) <= Date.parse(received.record.recordedAt));
  assert.equal(operating(reserved).originalCommitmentCompleted, false, 'A carrier reservation does not establish delivery.');
  await capture(page, 'reserved', '.review-column');
  await event('delivery', 'POD-SHIP-105', { 'Actual received quantity': String(p.quantity), 'Carrier reservation reference': 'BOOK-SHIP-105', 'Actual accepted delivery time': '2026-11-19T18:00' });
  const delivered = await continuation(page, 'completed');
  assert.equal(delivered.case.journeyOperations.at(-1).kind, 'delivery');
  assert.equal(operating(delivered).originalCommitmentCompleted, true, 'Current sourced delivery satisfies the separately authored original promise.');
  await capture(page, 'completed', '.review-column');
  await event('reservation', 'CANCEL-SHIP-105', { 'Booked quote reference': q.quoteId, 'Booked quote revision': q.quoteRevision, 'Actual carrier reservation time': '2026-11-17T08:15' }, false);
  const cancelled = await continuation(page, 'cancelled');
  assert.ok(cancelled.case.journeyOperations.some(row => row.record?.reference === 'BOOK-SHIP-105'));
  assert.equal(operating(cancelled).originalCommitmentCompleted, false, 'The later negative carrier record supersedes the earlier positive.');
  await capture(page, 'cancelled', '.review-column');
  checks.push('Operating choice, sourced authority, carrier reservation and delivery remain distinct; later negative records supersede historical support without erasing it');
  await pageFlow(page, { width: 390, height: 844 }); await summaryTab(); await capture(page, 'mobile', null);
  await pageFlow(page, { width: 1600, height: 1100 });
  await page.getByRole('group', { name: 'Arrangement to edit', exact: true }).getByRole('button', { name: 'Consolidated', exact: true }).click();
  await page.getByLabel('Quote currency', { exact: true }).selectOption('EUR'); await apply(page);
  await page.getByRole('alert').filter({ hasText: /USD/ }).waitFor();
  assert.equal(await page.getByRole('button', { name: 'Download SDK run', exact: true }).isDisabled(), true);
  await capture(page, 'input-error'); checks.push('Unsupported currency is diagnosed separately from a complete blocked finding; stale current downloads remain disabled');
  assert.deepEqual(errors, []); assert.ok(workers.length); assert.ok(workers.every(url => url.startsWith(base) && new URL(url).pathname.startsWith('/assets/')));
  await context.close();
  queueServer = createHTTPServer(async (request, response) => { try { const servingRoot = batchSource || output; const file = path.resolve(servingRoot, `.${decodeURIComponent(new URL(request.url, 'http://local').pathname)}`); if (!file.startsWith(`${servingRoot}${path.sep}`)) throw new Error('outside'); const bytes = await fs.readFile(file); response.writeHead(200, { 'Content-Type': file.endsWith('.html') ? 'text/html' : 'application/json' }); response.end(bytes); } catch { response.writeHead(404); response.end('Not found'); } });
  await new Promise(resolve => queueServer.listen(0, '127.0.0.1', resolve));
  const queueAddress = queueServer.address(); const queueContext = await browser.newContext({ viewport: { width: 1600, height: 1000 } });
  const queuePage = await queueContext.newPage();
  for (const [key, folder] of [['queue-baseline','baseline-batch'],['queue-late','late-batch'],['queue-morning','morning-batch']]) { const response = await queuePage.goto(`http://127.0.0.1:${queueAddress.port}/${folder}/shipments.html`); assert.equal(response.status(), 200); await queuePage.locator('[data-record-view="shipment-exception-queue"]').waitFor(); await capture(queuePage, key, null); }
  await capture(queuePage, 'batch-supported', '[data-record-view="shipment-SHIP-104-arrangements"]');
  await capture(queuePage, 'batch-blocked', '[data-record-view="shipment-SHIP-105-arrangements"]');
  await queueContext.close();
  const buildFiles = (await fs.readdir(path.join(root, 'dist/assets'))).filter(file => /\.(js|css)$/.test(file));
  const result = { suite: 'Shipment calculation integration production browser', origin: 'Local production build from an isolated source snapshot; fictional supplied records', capturedAt: new Date().toISOString(), checks, artifacts, exports,
    workflow: { version: config.workflowVersion, sourceContentHash: config.workflowHash, contentHash: value.definition.contentHash }, appBinding: config.binding,
    source: await Promise.all(['src/App.jsx', 'src/useShipmentReview.js', 'src/shipment.js', 'src/reviewJourney.js', 'src/styles.css', 'src/localReviews.js', 'test/browser.mjs', 'public/data/config.json', 'public/data/shipment.workflow.json'].map(async file => ({ file, sha256: sha(await fs.readFile(path.join(root, file))) }))),
    cliBatches: await Promise.all([baseline, late, morning].map(async batch => ({ path: batch.outputDir, manifestSHA256: sha(await fs.readFile(path.join(batch.outputDir, 'manifest.json'))) }))),
    build: await Promise.all(buildFiles.map(async file => ({ file: `assets/${file}`, sha256: sha(await fs.readFile(path.join(root, 'dist/assets', file))) }))), workers: workers.map(url => new URL(url).pathname), errors };
  await fs.writeFile(path.join(output, 'verification.json'), `${JSON.stringify(result, null, 2)}\n`); console.log(JSON.stringify({ checks, artifacts: artifacts.length, output }, null, 2));
} catch (error) {
  if (observedPage && !observedPage.isClosed()) {
    await fs.writeFile(path.join(output, 'failure.txt'), `${error.stack}\n\n${await observedPage.locator('body').innerText()}`);
    await observedPage.screenshot({ path: path.join(output, 'failure.png'), fullPage: true });
  }
  throw error;
} finally {
  if (browser) await browser.close();
  if (server?.httpServer.listening) await new Promise(resolve => server.httpServer.close(resolve));
  if (queueServer?.listening) await new Promise(resolve => queueServer.close(resolve));
  if (originalNodeEnv === undefined) delete process.env.NODE_ENV; else process.env.NODE_ENV = originalNodeEnv;
  await fs.rm(temporary, { recursive: true, force: true });
}
