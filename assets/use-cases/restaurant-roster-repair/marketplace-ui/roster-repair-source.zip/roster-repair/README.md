# Repair a published restaurant roster

This example authors and runs one operational workflow through the public Decision Lab CLI. An unpaid Saturday cancellation leaves a cook position open. Moving a cook from Sunday fills Saturday but leaves another service short. The calculation compares **four supplied complete repairs across every remaining service**, then optionally applies an explicit comparison priority.

The workflow uses the existing `complete-a-commitment/1` template. It always calculates feasibility. A selected priority activates one additional pinned app: preserve published assignments first, or minimize remaining payroll first. The three apps share the staffing facts and mandatory requirements. Changing priority does not relax a staffing requirement or invent a monetary value for disruption.

All people, records, fees and limits are fictional. The UI, CLI and SDK use the same canonical app definitions. This is a finite comparison of proposed repairs, not a search for every possible roster.

## Run the example

Use Node.js 22.19 or later and the matching qualified beta builds of `@decision-lab/sdk` and `@decision-lab/cli`. The preview version number alone does not establish that a package contains the required functionality. This walkthrough requires calculation workflows, routed decision summaries and artifact-sized YAML app definitions.

Copy this complete directory to a consumer project. Install the SDK and CLI builds supplied to you, for example:

```sh
npm install /path/to/decision-lab-sdk.tgz /path/to/decision-lab-cli.tgz
node walkthrough.mjs all --output-root .output/first-run
```

This installs packaged modules; it does not require the Decision Lab source repository. In the development workspace, the existing npm workspace links resolve the same public imports.

Workspace maintainers can also use `npm run demo:roster:cli`, `npm run test:roster`, `npm run build:roster:example` and `npm run check:roster:example`. The build command deliberately regenerates the unpublished sample and its product-distribution source; it is separate from working an operational case.

Run each stage separately to inspect its artifacts before continuing:

```sh
node walkthrough.mjs author --output-root .output/first-run
node walkthrough.mjs cases --output-root .output/first-run
node walkthrough.mjs changes --output-root .output/first-run
```

Choose either the `all` command or the three individual commands. Authoring requires a fresh output directory. Each stage refuses to overwrite an earlier stage. A failed command leaves its transcript and any completed artifacts for inspection; repeat with a fresh output root after correcting the error.

## Expected calculations

The published window includes Friday dinner, Saturday dinner and Sunday lunch. Every service has two distinct cook positions and one server position. The supplied positions last four hours. Earlier-week worked minutes and latest shift ends remain part of each employee's basis.

Nora's cancelled $88 assignment is unpaid and excluded from the **$656 retained remaining-payroll baseline**. The complete remaining-payroll limit is **$856**. That leaves $200 for additional labor; the limit is not an additional-expense allowance on top of $856.

| Supplied complete repair | Remaining payroll | Additional expense | Changed published positions | Full Saturday availability |
| --- | ---: | ---: | ---: | --- |
| Leave the gap | $656 | $0 | 1 | Blocked: Saturday cook position unfilled |
| Move Theo only | $656 | $0 | 2 | Blocked: Sunday cook position unfilled |
| Bring in Rowan | $836 | $180 | 1 | Passes |
| Repair three assignments | $736 | $80 | 3 | Passes |

Changed positions compare the employee at each position with the published roster. A cancelled position becoming unfilled counts as a change. This is not an employee count, fairness score or estimate of disruption cost.

| Supplied case | Expected finding |
| --- | --- |
| `full-availability` | Relief and coordinated repairs pass; no ranking is declared. |
| `short-availability` | Rowan's availability ends at 8 p.m.; only the coordinated repair passes. |
| `stability-first` | Relief is preferred: one changed position rather than three, with payroll used to break ties. |
| `cost-first` | Coordinated repair is preferred: $736 rather than $836, with changes used to break ties. |
| `no-passing-repair` | A $735.99 cap blocks every supplied repair. The calculation completes with no feasible option. |

Returning CLI exit code `0` means the calculation completed. It does not mean an option passes or that someone has agreed to work it.

## How the files fit together

| File or directory | Responsibility |
| --- | --- |
| `profile.json` | Authored employee/role/position identities, published assignments, complete repair catalog, unpaid cancellations, policies and starting facts. |
| `model.mjs` | Compiles that profile into ordinary canonical commitment models. It generates declarations, not feasibility findings. |
| `workflow-config.json` | Workflow identity, collection/use-case metadata, focused availability control and display clock. |
| `workflow.mjs` | Authors questions, input mappings, priority routing, output projections, decision summary and next-action graph. |
| `source/commitment.template.json` | The shared installed commitment template package. |
| `source/*.model.json` | Complete canonical models, readable independently of this compiler. |
| `source/*.app-definition.json`, `source/*.app.json` | Authored definitions and exact pinned app packages. |
| `source/workflow.source.json` | Complete runtime authoring source, including the authored case schema. |
| `source/workflow.definition.json` | Sealed runtime definition used by the CLI. |
| `source/roster.workflow.json` | Supplied installable workflow publication. |
| `source/workbook.mapping.json`, `source/roster.workbook.json` | Authored Excel mapping and installable workflow release with that interface. |
| `cases/*.json` | Operational inputs for the five demonstrated situations. |
| `walkthrough.mjs` | Public CLI orchestration and assertions against actual native findings. |

`test/model.test.mjs` belongs to the source workspace's regression suite. The portable walkthrough itself imports only public npm modules and the local authoring files. It has no dependency on private package paths, the website repository or its retained article reports.

## Author the apps and workflow

The `author` stage revalidates and packs the shared template, then compiles the profile separately for each declared priority:

```js
import { rosterAuthor } from './model.mjs';

const model = rosterAuthor.makeModel('stability');
```

It saves each model and executes the equivalent of:

```sh
decision-lab app init --template commitment.template.json \
  --model stability.model.json --app-id roster-repair-stability \
  --release 1 --output stability.app-definition.yaml
decision-lab app validate stability.app-definition.yaml
decision-lab app pack stability.app-definition.yaml \
  --created-at 2026-11-20T20:00:00.000Z --output stability.app.json
```

The default YAML output uses the 8 MiB artifact budget for the complete app definition, which includes both its parsed model and exact source. The canonical model input keeps its separate 200,000-character limit. `--format json` remains available when you prefer JSON. Both representations recreate the same app package and calculation.

The authoring function then supplies the workflow's questions, exact app dependencies and mappings:

```js
import { makeRosterWorkflow } from './workflow.mjs';

const source = makeRosterWorkflow({ author: rosterAuthor, apps });
// Retain the supplied authored case schema as well.
```

The CLI validates and seals that complete JSON source:

```sh
decision-lab workflow create --source workflow.source.json \
  --output workflow.definition.json
decision-lab workflow validate workflow.definition.json
```

The walkthrough asserts that all three CLI-created app packages and the runtime definition exactly match the supplied published version. Fixed timestamps and exact model-source bytes make those comparisons reproducible.

**Creating a runtime definition and publishing a workflow are separate operations.** This walkthrough reopens the supplied installable publication only after verifying that it contains the exact definition just recreated. It does not fabricate author approvals or binding-review receipts. Adapting the structure requires deliberately authoring and publishing a new version; these fixture checks do not approve a different model.

The author stage also runs `workbook pack` with that exact workflow, supplied mapping and initial case. It asserts that the resulting Excel-ready release matches the supplied release. Case workers download the prefilled workbook from that release; they do not configure mappings.

## Work a case

The `cases` stage starts an independent run for each supplied input file, solves its applicable calculations and saves both complete output and the brief:

```sh
decision-lab workflow start --definition workflow.definition.json \
  --case full-availability.json --run-id roster-full --output started.run.json
decision-lab workflow solve --run started.run.json --output solved.run.json
decision-lab workflow inspect --run solved.run.json --output output.json
decision-lab workflow brief --run solved.run.json --output brief.json
```

The complete output retains current steps, native app assessments and report documents, all repair findings, the decision summary, supporting question views, the calculation map and the business-process graph. A custom application can render those outputs without recreating the staffing checks or preference rules.

The business-process graph exposes what the current finding makes available:

```mermaid
flowchart TD
  A[Supply the interrupted roster and working records] --> B[Calculate complete repairs]
  B --> C{Any supplied repair passes?}
  C -->|No| D[Inspect blockers and revise proposals or facts]
  D --> A
  C -->|Unknown, incomplete, invalid or outdated| E[Complete inputs or recalculate]
  E --> A
  C -->|Yes| F{An authored comparison priority is selected?}
  F -->|No| G[Compare passing repairs without ranking]
  F -->|Yes| H[Apply priority to passing repairs; retain ties]
  H --> G
  G --> I[Choose a repair, obtain staff agreement and communicate it]
  I -->|Availability changes| A
```

The graph is an explanation of available next actions. Inspecting its staff-agreement action does not contact employees, record agreement or publish a roster.

## Change facts without rebuilding an app

The `changes` stage continues the full-availability run. It changes priority twice using supplied inputs:

```sh
decision-lab workflow answer --run solved.run.json --question priority \
  --status supplied --value stability.value.json --output changed.run.json
decision-lab workflow solve --run changed.run.json --output reranked.run.json
```

`stability.value.json` contains the JSON string `"stability"`. Choosing `"cost"` activates the other pinned comparison. The script asserts that the original feasibility evaluation ID is preserved through both changes: the staffing facts and mandatory checks are identical.

It then changes `relief-window` to:

```json
{ "fromMinute": 1080, "throughMinute": 1200 }
```

These are Saturday clock minutes after midnight: 6 p.m. through 8 p.m. The previous feasibility and cost findings become outdated immediately. The decision summary withholds a current conclusion until recalculation. Solving again leaves only the coordinated repair available. The original ten-o'clock assignment is not shortened, and the solver does not invent cover for the final two hours.

This is a calculation workflow. Inputs use `supplied`, `unknown` or `unanswered`; there is no reviewer identity, answer approval or result signoff in this example.

## Authored structure versus operational inputs

| Author defines and publishes | Case worker supplies within that structure |
| --- | --- |
| Employee IDs and display identities; role and position catalog | Recorded qualifications, flat assignment fees, earlier worked minutes and latest shift ends |
| Published assignments, required intervals and complete repair identities | Who fills each existing position in each supplied repair |
| Mandatory check structure and the three comparison priorities | Working availability, other bookings and remaining-payroll cap |
| Cancellation/payroll semantics, units and workflow mappings | The selected authored comparison priority |
| Which controls are exposed and how outputs are presented | Known, unknown or unanswered values for those operational questions |

The general commitment pattern admits typed parameters. This particular workflow keeps its declared rest policy fixed and exposes each employee's recorded weekly limit in supporting records. Another deliberately authored profile can expose different controls. Publication decides that boundary.

For another bounded roster profile:

```js
import { createRosterAuthor } from './model.mjs';

const author = createRosterAuthor(myProfile);
const canonicalModel = author.makeModel('cost', author.makeCase());
```

The compiler generates every employee's hours consequence/check and every position's coverage, qualification, availability, rest, capacity and charge declarations. Adding an employee, position or repair is an authoring change, followed by new packages and regression checks. Adding a row directly to case data does not extend the compiled catalog; unknown IDs are rejected by native input admission. The `_counts` and `_resources` tables are generated implementation records, not spreadsheet inputs or worker controls.

## Units, limits and operating scope

- Monetary inputs are integer currency cents. Availability and worked-time inputs are integer minutes.
- Canonical intervals use minutes from Monday 00:00. The focused relief control uses minutes after midnight on the configured Saturday; the mapping converts that clock into canonical time.
- The display example anchors Monday to November 16, 2026 in `America/Chicago`. Its authored horizon has no daylight-saving transition.
- Full-interval availability and exclusive capacity use half-open intervals. Adjacent available intervals can combine; an uncovered break cannot.
- Fees are accepted flat amounts per complete assignment. Different authored durations contribute their actual minutes to hours, without silently prorating fees or inventing overtime premiums.
- The supplied ten-hour rest and forty-hour weekly limits are model assumptions. Earlier work is retained as totals and latest ends, not retrospectively audited. Existing bookings consume capacity; this profile does not audit their rest gaps.
- Canonical source and execution limits still apply. A larger authored profile can exceed the installed source, expression or execution bounds; the example does not claim unlimited scheduling capacity.
- No passing supplied repair means those proposals fail. It does not establish that every possible roster is infeasible.
- Demand forecasts, payroll taxes/premiums, seniority, fairness, employee consent, messaging and actual publication require additional rules or integrations.

## Retained outputs and UI handoff

Every stage writes `commands.json` with arguments, exit codes and captured output, plus a readable `commands.sh` transcript. Stage verification files record exact package identities and the native findings checked. The shell transcript describes commands already executed; use a fresh walkthrough output directory to repeat them.

| Output | Contents |
| --- | --- |
| `author/` | Recreated template, three models/definitions/packages, runtime definition, verified publication, Excel-ready release and validation receipts |
| `cases/` | Independent started/solved runs, full output, brief and verified findings for all five cases |
| `changes/` | Priority revisions, preserved feasibility identity, outdated availability findings and recalculated outputs |

Install **Restaurant operations** in the Marketplace and open **Repair a published restaurant roster**, or import the supplied `source/roster.workbook.json` release. Its app dependencies and runtime definition match the CLI-created artifacts. The UI adds Forms/YAML, Excel and report navigation around the same calculation. It contains no restaurant-specific feasibility or ranking implementation.
