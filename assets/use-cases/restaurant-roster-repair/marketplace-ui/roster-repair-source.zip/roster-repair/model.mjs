// Author a finite roster comparison. This compiler emits ordinary canonical
// Decision Lab data; feasibility and ranking remain the SDK's responsibility.
import initialProfile from './profile.json' with { type: 'json' };

export const ROSTER_PROFILE_FORMAT = 'restaurant-roster-profile/1';
export const ROSTER_PRIORITIES = Object.freeze(['feasibility', 'stability', 'cost']);
export const UNFILLED_EMPLOYEE = 'unfilled';
const clone = value => structuredClone(value);
const own = (value, key) => Object.hasOwn(value, key);
const record = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const safeId = value => typeof value === 'string' && /^[A-Za-z][A-Za-z0-9_-]{0,79}$/.test(value)
  && !['constructor', 'prototype', '__proto__', UNFILLED_EMPLOYEE].includes(value);
const fail = (path, message) => { throw Object.assign(new TypeError(`${path}: ${message}`), { code: 'ROSTER_PROFILE_INVALID', path }); };
const need = (condition, path, message) => { if (!condition) fail(path, message); };
const integer = (value, path) => need(Number.isSafeInteger(value) && value >= 0, path, 'needs a nonnegative safe integer.');
const text = (value, path) => need(typeof value === 'string' && value.trim().length > 0, path, 'needs nonempty text.');
const interval = (value, path, start = 'from', end = 'through') => {
  need(record(value), path, 'needs an interval.'); integer(value[start], `${path}.${start}`); integer(value[end], `${path}.${end}`);
  need(value[start] < value[end], path, 'must have a positive interval.');
};
const indexed = (rows, path) => {
  need(Array.isArray(rows) && rows.length > 0, path, 'needs at least one record.');
  const found = new Map();
  for (const [i, row] of rows.entries()) {
    need(record(row) && safeId(row.id), `${path}[${i}].id`, 'needs a safe identifier.');
    need(!found.has(row.id), `${path}[${i}].id`, 'duplicates an identifier.'); found.set(row.id, row);
  }
  return found;
};

/** Validate the authored structure before generating any repeated checks. */
export function validateRosterProfile(profile) {
  try {
    need(record(profile) && profile.format === ROSTER_PROFILE_FORMAT, 'profile.format', `must be ${ROSTER_PROFILE_FORMAT}.`);
    need(safeId(profile.id), 'profile.id', 'needs a safe identifier.');
    text(profile.version, 'profile.version'); text(profile.title, 'profile.title'); text(profile.timeOrigin, 'profile.timeOrigin'); text(profile.money, 'profile.money');
    need(/^[A-Z]{3} cent$/.test(profile.money), 'profile.money', 'needs an explicit three-letter currency in cent units.');
    need(record(profile.policies), 'profile.policies', 'needs recorded policies.');
    integer(profile.policies.minimumRestMinutes, 'profile.policies.minimumRestMinutes');
    integer(profile.policies.remainingLaborBudgetMinor, 'profile.policies.remainingLaborBudgetMinor');
    need(profile.policies.pricing === 'flat-fee-per-assignment', 'profile.policies.pricing', 'must explicitly declare flat-fee-per-assignment; no hourly-price conversion is inferred.');
    const roles = indexed(profile.roles, 'profile.roles'), employees = indexed(profile.employees, 'profile.employees');
    for (const role of roles.values()) text(role.label, `role.${role.id}.label`);
    for (const person of employees.values()) {
      text(person.name, `employee.${person.id}.name`);
      for (const field of ['assignmentFeeMinor', 'earlierWeekMinutes', 'weeklyLimitMinutes', 'lastEarlierShiftEnd']) integer(person[field], `employee.${person.id}.${field}`);
      need(Array.isArray(person.qualifiedRoles) && new Set(person.qualifiedRoles).size === person.qualifiedRoles.length, `employee.${person.id}.qualifiedRoles`, 'needs distinct declared role IDs.');
      for (const role of person.qualifiedRoles) need(roles.has(role), `employee.${person.id}.qualifiedRoles`, `unknown role ${role}.`);
      need(Array.isArray(person.availability), `employee.${person.id}.availability`, 'needs recorded availability intervals.');
      person.availability.forEach((window, i) => interval(window, `employee.${person.id}.availability[${i}]`));
    }
    const services = indexed(profile.services, 'profile.services'), positions = new Map();
    let previousStart = -1;
    for (const service of services.values()) {
      text(service.label, `service.${service.id}.label`);
      const declared = indexed(service.positions, `service.${service.id}.positions`);
      let serviceStart = Infinity;
      for (const position of declared.values()) {
        need(position.id !== 'id', `position.${position.id}`, 'id is reserved for the repair row key.');
        need(!positions.has(position.id), `position.${position.id}`, 'duplicates a position across services.');
        need(roles.has(position.role), `position.${position.id}.role`, 'references an unknown role.');
        need(employees.has(position.publishedEmployeeId), `position.${position.id}.publishedEmployeeId`, 'references an unknown employee.');
        interval(position, `position.${position.id}`, 'start', 'end');
        serviceStart = Math.min(serviceStart, position.start); positions.set(position.id, position);
      }
      need(serviceStart >= previousStart, `service.${service.id}`, 'services must be listed in chronological order.'); previousStart = serviceStart;
    }
    need(Array.isArray(profile.cancellations), 'profile.cancellations', 'needs an explicit cancellation list.');
    const cancelled = new Set();
    for (const cancellation of profile.cancellations) {
      const position = positions.get(cancellation.positionId);
      need(position && position.publishedEmployeeId === cancellation.employeeId, 'profile.cancellations', 'must identify the published employee at a declared position.');
      need(cancellation.unpaid === true, 'profile.cancellations', 'only explicitly unpaid cancellations are supported by this payroll basis.');
      need(!cancelled.has(cancellation.positionId), 'profile.cancellations', 'duplicates a cancelled position.'); cancelled.add(cancellation.positionId);
    }
    const repairs = indexed(profile.repairs, 'profile.repairs');
    for (const repair of repairs.values()) {
      text(repair.label, `repair.${repair.id}.label`);
      need(record(repair.assignments) && Object.keys(repair.assignments).length === positions.size, `repair.${repair.id}.assignments`, 'must supply every position exactly once.');
      for (const [id, employee] of Object.entries(repair.assignments)) {
        need(positions.has(id), `repair.${repair.id}.assignments.${id}`, 'references an unknown position.');
        need(employee === null || employees.has(employee), `repair.${repair.id}.assignments.${id}`, 'references an unknown employee; use null for an unfilled position.');
      }
    }
    return { valid: true, errors: [] };
  } catch (error) { return { valid: false, errors: [{ path: error.path ?? 'profile', message: error.message }] }; }
}

const L = literal => ({ literal }), R = ref => ({ ref }), O = (op, ...args) => ({ op, args });
const sum = args => args.length === 0 ? L(0) : args.length === 1 ? args[0] : O('add', ...args);
const lookup = (table, where, column) => ({ op: 'lookup', table, where, column });
const str = { type: 'string' }, money = { type: 'integer', unit: 'money', minimum: 0 }, time = { type: 'integer', unit: 'time', minimum: 0 }, count = { type: 'integer', unit: 'count', minimum: 0 };
const table = columns => ({ key: ['id'], columns });

/** Structural edits create a new author; case edits reuse this frozen structure. */
export function createRosterAuthor(inputProfile) {
  const validation = validateRosterProfile(inputProfile);
  if (!validation.valid) fail(validation.errors[0].path, validation.errors[0].message);
  const profile = clone(inputProfile);
  const currency = profile.money.slice(0, 3);
  const positions = profile.services.flatMap(service => service.positions.map(position => ({ ...position, serviceLabel: service.label }))).sort((a, b) => a.start - b.start || a.end - b.end || a.id.localeCompare(b.id));
  const employeeIds = [...profile.employees.map(person => person.id), UNFILLED_EMPLOYEE], repairIds = profile.repairs.map(repair => repair.id);
  const cancelled = new Set(profile.cancellations.map(row => row.positionId));
  const technical = {
    _counts: [{ flag: false, count: 0 }, { flag: true, count: 1 }],
    _resources: employeeIds.map(id => ({ id, capacity: 1 })),
  };
  const actor = position => R(`activity.${position.id}.actor`);
  const personValue = (employee, column) => lookup('employees', { id: typeof employee === 'string' ? L(employee) : employee }, column);
  const truthCount = expression => lookup('_counts', { flag: expression }, 'count');

  function makeCase(overrides = {}) {
    need(record(overrides), 'case', 'needs an input record.');
    const base = {
      id: 'restaurant-roster', parameters: { remainingLaborBudgetMinor: profile.policies.remainingLaborBudgetMinor, minimumRestMinutes: profile.policies.minimumRestMinutes },
      tables: {
        employees: [...profile.employees.map(({ id, name, assignmentFeeMinor, earlierWeekMinutes, weeklyLimitMinutes, lastEarlierShiftEnd }) => ({ id, name, assignmentFeeMinor, earlierWeekMinutes, weeklyLimitMinutes, lastEarlierShiftEnd })), { id: UNFILLED_EMPLOYEE, name: 'Unfilled', assignmentFeeMinor: 0, earlierWeekMinutes: 0, weeklyLimitMinutes: 0, lastEarlierShiftEnd: 0 }],
        qualifications: profile.employees.flatMap(person => person.qualifiedRoles.map(role => ({ employee: person.id, role }))),
        assignments: profile.repairs.map(repair => ({ id: repair.id, ...Object.fromEntries(positions.map(position => [position.id, repair.assignments[position.id] ?? UNFILLED_EMPLOYEE])) })),
        availability: profile.employees.flatMap(person => person.availability.map((window, i) => ({ id: `availability-${person.id}-${i + 1}`, employee: person.id, ...window }))),
        scenarios: [{ id: 'recorded-week' }], bookings: [], ...clone(technical),
      },
      provenance: [{ id: 'fictional-roster-basis', description: 'Fictional accepted roster facts. Fees are flat amounts for each complete accepted assignment, with no implicit hourly prorating. Earlier work is retained as totals and latest shift ends. Unpaid cancellations are excluded from the remaining-payroll baseline. No staff agreement, notification or roster publication occurs.' }],
    };
    return { ...base, ...clone(overrides), parameters: { ...base.parameters, ...clone(overrides.parameters ?? {}) }, tables: { ...base.tables, ...clone(overrides.tables ?? {}) } };
  }

  function validateCaseInput(input) {
    try {
      need(record(input) && record(input.tables) && record(input.parameters), 'case', 'needs parameters and tables.');
      text(input.id, 'case.id');
      for (const field of ['remainingLaborBudgetMinor', 'minimumRestMinutes']) integer(input.parameters[field], `case.parameters.${field}`);
      for (const [name, rows] of Object.entries(technical)) need(JSON.stringify(input.tables[name]) === JSON.stringify(rows), `case.tables.${name}`, 'is generated author-owned data.');
      for (const name of ['employees', 'assignments', 'availability', 'qualifications', 'scenarios', 'bookings']) need(Array.isArray(input.tables[name]), `case.tables.${name}`, 'needs a record list.');
      for (const [name, expected] of [['employees', employeeIds], ['assignments', repairIds]]) {
        const actual = input.tables[name].map(row => row.id);
        need(actual.length === expected.length && new Set(actual).size === actual.length && expected.every(id => actual.includes(id)), `case.tables.${name}`, 'must retain exactly the authored identities; structural edits require a new profile.');
      }
      for (const row of input.tables.employees) {
        text(row.name, `employee.${row.id}.name`);
        const authoredName = row.id === UNFILLED_EMPLOYEE ? 'Unfilled' : profile.employees.find(person => person.id === row.id).name;
        need(row.name === authoredName, `employee.${row.id}.name`, 'display identity belongs to the authored profile and its frozen report labels.');
        for (const field of ['assignmentFeeMinor', 'earlierWeekMinutes', 'weeklyLimitMinutes', 'lastEarlierShiftEnd']) integer(row[field], `employee.${row.id}.${field}`);
      }
      const unfilled = input.tables.employees.find(row => row.id === UNFILLED_EMPLOYEE);
      need(['assignmentFeeMinor', 'earlierWeekMinutes', 'weeklyLimitMinutes', 'lastEarlierShiftEnd'].every(field => unfilled[field] === 0), 'employee.unfilled', 'is the zero-cost unfilled sentinel.');
      for (const repair of input.tables.assignments) {
        need(Object.keys(repair).length === positions.length + 1 && positions.every(position => own(repair, position.id)), `repair.${repair.id}`, 'must contain exactly the authored positions.');
        for (const position of positions) need(employeeIds.includes(repair[position.id]), `repair.${repair.id}.${position.id}`, 'references an unknown employee.');
      }
      for (const name of ['availability', 'bookings']) {
        const ids = new Set();
        for (const row of input.tables[name]) {
          need(safeId(row.id) && !ids.has(row.id), `case.tables.${name}`, 'needs distinct safe IDs.'); ids.add(row.id);
          need(employeeIds.includes(row.employee) && row.employee !== UNFILLED_EMPLOYEE, `case.tables.${name}.${row.id}`, 'references an unknown actual employee.');
          interval(row, `case.tables.${name}.${row.id}`);
          if (name === 'bookings') need(row.amount === 1, `case.tables.bookings.${row.id}.amount`, 'an employee booking occupies one employee.');
        }
      }
      const qualified = new Set();
      for (const row of input.tables.qualifications) {
        const key = `${row.employee}/${row.role}`;
        need(employeeIds.includes(row.employee) && row.employee !== UNFILLED_EMPLOYEE && profile.roles.some(role => role.id === row.role) && !qualified.has(key), 'case.tables.qualifications', 'needs distinct declared employee/role pairs.'); qualified.add(key);
      }
      need(input.tables.scenarios.length === 1 && input.tables.scenarios[0].id === 'recorded-week', 'case.tables.scenarios', 'retains one explicitly recorded week.');
      return { valid: true, errors: [] };
    } catch (error) { return { valid: false, errors: [{ path: error.path ?? 'case', message: error.message }] }; }
  }

  function makeModel(priority = 'feasibility', caseInput = makeCase()) {
    need(ROSTER_PRIORITIES.includes(priority), 'priority', `must be ${ROSTER_PRIORITIES.join(', ')}.`);
    const admitted = validateCaseInput(caseInput);
    if (!admitted.valid) fail(admitted.errors[0].path, admitted.errors[0].message);
    const requirements = [
      ['COVERAGE', 'Every required position filled', 'Every authored position has an employee for its complete interval.'],
      ['QUALIFICATION', 'Required qualifications', 'Each assigned employee has the recorded qualification for that role.'],
      ['AVAILABILITY', 'Full-interval availability', 'Working availability covers the whole assignment; declared unpaid cancellations remain unavailable.'],
      ['CAPACITY', 'One assignment at a time', 'An employee cannot fill simultaneous positions or overlap an existing booking.'],
      ['REST', 'Declared rest between assignments', 'Prior work and remaining assignments leave the recorded minimum rest.'],
      ['HOURS', 'Declared weekly hours', 'Earlier worked minutes plus actual assignment durations fit the employee limit.'],
      ['BUDGET', 'Remaining payroll limit', 'Complete remaining payroll fits the recorded limit; unpaid cancellations are excluded from the retained baseline.'],
      ['BASIS', 'Authored calculation basis', 'Fixed identities, exclusive employee capacities and Boolean counts retain their authored meaning.'],
    ].map(([id, label, meaning]) => ({ id, label, meaning, waivable: false }));
    const constraints = [], constraintLabels = {};
    const positionLabel = position => `${position.serviceLabel}: ${profile.roles.find(role => role.id === position.role).label} (${position.id})`;
    const predicate = (id, requirement, expression, label) => {
      constraints.push({ id, requirement, kind: 'predicate', predicate: expression });
      constraintLabels[`constraint.${id}`] = label ?? `${requirements.find(row => row.id === requirement).label}: ${id}`;
    };
    for (const flag of [false, true]) predicate(`count-${flag}`, 'BASIS', O('eq', truthCount(L(flag)), L(Number(flag))));
    for (const id of employeeIds) predicate(`capacity-${id}`, 'BASIS', O('eq', lookup('_resources', { id: L(id) }, 'capacity'), L(1)));
    for (const id of employeeIds) predicate(`identity-${id}`, 'BASIS', O('eq', personValue(id, 'name'), L(id === UNFILLED_EMPLOYEE ? 'Unfilled' : profile.employees.find(person => person.id === id).name)));
    for (const column of ['assignmentFeeMinor', 'earlierWeekMinutes', 'weeklyLimitMinutes', 'lastEarlierShiftEnd']) predicate(`unfilled-${column}`, 'BASIS', O('eq', personValue(UNFILLED_EMPLOYEE, column), L(0)));
    for (const position of positions) {
      predicate(`filled-${position.id}`, 'COVERAGE', O('ne', actor(position), L(UNFILLED_EMPLOYEE)), `${positionLabel(position)} must be filled`);
      predicate(`qualified-${position.id}`, 'QUALIFICATION', { op: 'exists', table: 'qualifications', where: { employee: actor(position), role: L(position.role) } }, `${positionLabel(position)} needs a qualified employee`);
      predicate(`available-${position.id}`, 'AVAILABILITY', { op: 'interval-covered', table: 'availability', where: { employee: actor(position) }, start: R(`activity.${position.id}.start`), end: R(`activity.${position.id}.end`), startColumn: 'from', endColumn: 'through' }, `${positionLabel(position)} needs availability for the whole assignment`);
      predicate(`earlier-rest-${position.id}`, 'REST', O('gte', O('sub', R(`activity.${position.id}.start`), personValue(actor(position), 'lastEarlierShiftEnd')), R('parameter.minimumRestMinutes')), `${positionLabel(position)} needs enough rest after earlier work`);
    }
    for (const cancellation of profile.cancellations) predicate(`cancelled-${cancellation.positionId}`, 'AVAILABILITY', O('ne', R(`activity.${cancellation.positionId}.actor`), L(cancellation.employeeId)), `${profile.employees.find(person => person.id === cancellation.employeeId).name}'s cancelled assignment remains unavailable`);
    for (let first = 0; first < positions.length; first++) for (let second = first + 1; second < positions.length; second++) {
      const a = positions[first], b = positions[second];
      predicate(`rest-${a.id}-${b.id}`, 'REST', O('or', O('ne', actor(a), actor(b)), O('gte', O('sub', R(`activity.${b.id}.start`), R(`activity.${a.id}.end`)), R('parameter.minimumRestMinutes'))), `The same employee needs enough rest between ${positionLabel(a)} and ${positionLabel(b)}`);
    }
    constraints.push({ id: 'employee-capacity', requirement: 'CAPACITY', kind: 'resource-capacity' });
    constraintLabels['constraint.employee-capacity'] = 'An employee cannot cover overlapping assignments or bookings';
    for (const employee of profile.employees) predicate(`hours-${employee.id}`, 'HOURS', O('lte', R(`derived.minutes-${employee.id}`), personValue(employee.id, 'weeklyLimitMinutes')), `${employee.name}'s total worked minutes must fit the recorded weekly limit`);
    predicate('remaining-payroll-budget', 'BUDGET', O('lte', R('finance.expense'), R('parameter.remainingLaborBudgetMinor')), 'Complete remaining payroll must fit the recorded limit');
    const changes = R('derived.changedAssignments'), expense = R('finance.expense');
    const preference = priority === 'feasibility' ? { mode: 'feasibility-only' } : priority === 'stability'
      ? { direction: 'min', expression: changes, then: [{ direction: 'min', expression: expense }] }
      : { direction: 'min', expression: expense, then: [{ direction: 'min', expression: changes }] };
    const employeeRef = { type: 'string', enum: employeeIds, references: { table: 'employees', column: 'id' } };
    const roleIds = profile.roles.map(role => role.id);
    return {
      format: 'complete-a-commitment/1',
      module: {
        id: `${profile.id}-${priority}`, version: profile.version, template: { id: 'complete-a-commitment', version: 1 }, title: profile.title,
        question: 'Which supplied complete repairs cover every remaining service within the recorded staffing and payroll limits?',
        description: 'Compare supplied complete repairs for a published roster. Every remaining authored position is checked; a preferred repair is established only among these alternatives.',
        units: { time: 'minute', timeOrigin: profile.timeOrigin, money: profile.money, count: 'position' },
        assumptions: [
          'This bounded comparison evaluates supplied complete repairs; it does not search every possible employee assignment or generate service demand.',
          'Every position has an authored role and fixed positive interval. Required breaks must be omitted from working availability and explicitly covered by a supplied repair.',
          'Fees are flat accepted amounts per complete assignment. Different durations are counted accurately for hours; no hourly pay, proration, overtime premium or tax is inferred.',
          'The retained baseline sums published assignments after removing explicitly unpaid cancellations. Changed positions compare assigned people with the published roster, not employee disruption, consent or fairness.',
          'Earlier work is retained as totals and latest shift ends. Declared weekly-hours and rest limits are assumptions, not a labor-law assessment. Existing bookings are checked for capacity, not retrospectively audited for rest.',
          'A calculated proposal does not obtain staff agreement, notify employees or publish a roster. Demand forecasts and actual operation require separate records or integrations.',
        ],
        inputs: { parameters: { remainingLaborBudgetMinor: money, minimumRestMinutes: time }, tables: {
          employees: table({ id: { ...str, enum: employeeIds }, name: str, assignmentFeeMinor: money, earlierWeekMinutes: time, weeklyLimitMinutes: time, lastEarlierShiftEnd: time }),
          qualifications: { key: ['employee', 'role'], columns: { employee: employeeRef, role: { ...str, enum: roleIds } } },
          assignments: table({ id: { ...str, enum: repairIds }, ...Object.fromEntries(positions.map(position => [position.id, employeeRef])) }),
          availability: table({ id: str, employee: employeeRef, from: time, through: time }),
          _counts: { key: ['flag'], columns: { flag: { type: 'boolean' }, count: { ...count, enum: [0, 1] } } },
          _resources: table({ id: employeeRef, capacity: { ...count, enum: [1] } }),
          scenarios: table({ id: { ...str, enum: ['recorded-week'] } }),
          bookings: table({ id: str, employee: employeeRef, from: time, through: time, amount: { ...count, enum: [1] } }),
        } },
        choices: [{ id: 'repair', domain: { values: repairIds } }], scenarioDomain: { table: 'scenarios' },
        lookupCoverage: [
          { table: 'assignments', keys: { id: { domain: { values: repairIds } } } },
          { table: 'employees', keys: { id: { domain: { values: employeeIds } } } },
          { table: '_resources', keys: { id: { domain: { values: employeeIds } } } },
          { table: '_counts', keys: { flag: { domain: { values: [false, true] } } } },
        ],
        derived: [
          ...positions.map(position => ({ id: `duration-${position.id}`, type: 'integer', unit: 'time', expr: L(position.end - position.start) })),
          { id: 'changedAssignments', type: 'integer', unit: 'count', expr: sum(positions.map(position => truthCount(O('ne', actor(position), L(position.publishedEmployeeId))))) },
          { id: 'retainedBaselineExpense', type: 'integer', unit: 'money', expr: sum(positions.filter(position => !cancelled.has(position.id)).map(position => personValue(position.publishedEmployeeId, 'assignmentFeeMinor'))) },
          { id: 'additionalExpense', type: 'integer', unit: 'money', expr: O('sub', R('finance.expense'), R('derived.retainedBaselineExpense')) },
          ...profile.employees.map(employee => ({ id: `minutes-${employee.id}`, type: 'integer', unit: 'time', expr: sum([personValue(employee.id, 'earlierWeekMinutes'), ...positions.map(position => O('mul', truthCount(O('eq', actor(position), L(employee.id))), R(`activity.${position.id}.duration`)))]) })),
        ],
        activities: positions.map(position => ({ id: position.id, actor: lookup('assignments', { id: R('choice.repair') }, position.id), start: L(position.start), duration: R(`derived.duration-${position.id}`), resources: [{ resource: actor(position), amount: L(1) }] })),
        resources: { definitions: { table: '_resources', idColumn: 'id', capacityColumn: 'capacity' }, bookings: { table: 'bookings', resourceColumn: 'employee', startColumn: 'from', endColumn: 'through', amountColumn: 'amount' } },
        requirements, constraints, finance: { mode: 'expense', charges: positions.map(position => ({ id: `pay-${position.id}`, amount: personValue(actor(position), 'assignmentFeeMinor') })), holds: [] }, preference,
        labels: {
          plan: 'Complete roster repair', actor: 'Employee', scenario: 'Recorded week', financeExpense: 'Remaining payroll', 'choice.repair': 'Supplied repair', 'view.schedule.title': 'Complete remaining roster',
          ...Object.fromEntries(positions.map(position => [`activity.${position.id}`, positionLabel(position)])), ...constraintLabels,
          ...Object.fromEntries(profile.employees.map(employee => [`resource.${employee.id}`, employee.name])), 'resource.unfilled': 'Unfilled',
          ...Object.fromEntries(profile.repairs.map(repair => [`choice.repair.${repair.id}`, repair.label])),
        },
        metadata: { decisionPresentation: {
          format: 'decision-presentation/1', title: 'Compare complete roster repairs', question: 'Which supplied repairs can operate, and what does each change?',
          priorityLabel: priority === 'feasibility' ? 'Compare without ranking' : priority === 'stability' ? 'Preserve published assignments first, then minimize payroll' : 'Minimize remaining payroll first, then preserve published assignments',
          moneyFormat: { currency, divisor: 100 },
          columns: [
            { id: 'plan', label: 'Complete repair' },
            { id: 'status', label: 'Operating result' }, { id: 'expense', label: 'Remaining payroll', format: { kind: 'money', currency, divisor: 100 } },
            { id: 'additionalExpense', source: { kind: 'derived', id: 'additionalExpense' }, label: 'Additional expense', format: { kind: 'money', currency, divisor: 100 } },
            { id: 'changes', source: { kind: 'derived', id: 'changedAssignments' }, label: 'Changed positions', format: { kind: 'number' } },
            { id: 'blockers', label: 'Blocking condition' },
          ], charts: [{ viewId: 'commitment:schedule', defaultRepresentation: 'timeline' }],
        } },
      }, case: clone(caseInput),
    };
  }
  return Object.freeze({ profile: clone(profile), priorities: ROSTER_PRIORITIES, makeCase, makeModel, validateCaseInput });
}

export const rosterAuthor = createRosterAuthor(initialProfile);
export const makeCase = overrides => rosterAuthor.makeCase(overrides);
export const makeModel = (priority, input) => rosterAuthor.makeModel(priority, input);
