import assert from 'node:assert/strict';
import test from 'node:test';
import profile from '../profile.json' with { type: 'json' };
import { createRosterAuthor, makeCase, makeModel, validateRosterProfile } from '../model.mjs';
import { commitment, createDecisionLab } from '../../../../packages/sdk/src/index.js';
import { createNodeExecutor } from '../../../../packages/sdk/src/adapters/node/index.js';

const clone = value => structuredClone(value);
const assess = (input = makeCase(), priority = 'feasibility') => {
  const model = makeModel(priority, input), validation = commitment.validateModel(model);
  assert.equal(validation.valid, true, JSON.stringify(validation.errors));
  const assessment = commitment.evaluateCommitmentModel(model);
  assert.equal(commitment.isAssessmentComplete(assessment), true, JSON.stringify(assessment.errors));
  return assessment;
};
const plan = (assessment, id) => assessment.plans.find(row => row.choices.repair === id);
const feasible = assessment => assessment.plans.filter(row => row.feasible).map(row => row.choices.repair);
const blocker = (assessment, id, requirement) => assert.ok(plan(assessment, id).blockers.some(row => row.requirement === requirement));
const preferred = assessment => assessment.recommendation && assessment.plans.filter(row => assessment.recommendation.tiedPlanIds.includes(row.id)).map(row => row.choices.repair);
const rowan = input => input.tables.availability.find(row => row.employee === 'rowan');

test('the authored fixture reproduces all original complete repairs and their accounting basis', () => {
  const result = assess();
  assert.deepEqual(feasible(result), ['relief', 'coupled']);
  assert.deepEqual(result.plans.map(row => row.expense), [65600, 65600, 83600, 73600]);
  assert.deepEqual(result.plans.map(row => row.scenarios[0].derived.changedAssignments), [1, 2, 1, 3]);
  assert.deepEqual(result.plans.map(row => row.scenarios[0].derived.additionalExpense), [0, 0, 18000, 8000]);
  assert.ok(result.plans.every(row => row.scenarios[0].derived.retainedBaselineExpense === 65600));
  assert.equal(result.recommendation, null);
  blocker(result, 'hold', 'COVERAGE'); blocker(result, 'move-only', 'COVERAGE');
});

test('priorities preserve staffing facts and mandatory rules while ranking only feasible repairs', () => {
  const input = makeCase(), before = clone(input);
  const plain = makeModel('feasibility', input), stability = makeModel('stability', input), cost = makeModel('cost', input);
  assert.deepEqual(plain.case, stability.case); assert.deepEqual(plain.case, cost.case);
  for (const key of ['constraints', 'requirements', 'derived', 'activities', 'finance', 'inputs']) {
    assert.deepEqual(plain.module[key], stability.module[key]); assert.deepEqual(plain.module[key], cost.module[key]);
  }
  assert.deepEqual(preferred(assess(input, 'stability')), ['relief']);
  assert.deepEqual(preferred(assess(input, 'cost')), ['coupled']);
  assert.deepEqual(input, before);
  assert.throws(() => makeModel('cheapest-even-if-blocked'), /priority/);
});

test('the exact whole-assignment availability boundaries are inclusive at start/end', () => {
  assert.deepEqual(feasible(assess()), ['relief', 'coupled']);
  for (const change of [window => { window.through -= 1; }, window => { window.from += 1; }, window => { window.through -= 120; }]) {
    const input = makeCase(); change(rowan(input)); const result = assess(input);
    assert.deepEqual(feasible(result), ['coupled']); blocker(result, 'relief', 'AVAILABILITY');
  }
});

test('the payroll limit distinguishes no repair, one repair and two repairs at exact cents', () => {
  for (const [limit, expected] of [[73599, []], [73600, ['coupled']], [83599, ['coupled']], [83600, ['relief', 'coupled']]]) {
    const result = assess(makeCase({ parameters: { remainingLaborBudgetMinor: limit } }));
    assert.deepEqual(feasible(result), expected);
  }
});

test('qualification, exclusive capacity and omitted break intervals block the actual candidate', () => {
  const unqualified = makeCase(); unqualified.tables.qualifications = unqualified.tables.qualifications.filter(row => !(row.employee === 'ben' && row.role === 'cook'));
  blocker(assess(unqualified), 'coupled', 'QUALIFICATION');
  const double = makeCase(); double.tables.assignments.find(row => row.id === 'relief')['sat-dinner-cook-2'] = 'luis';
  blocker(assess(double), 'relief', 'CAPACITY');
  const gap = makeCase(), window = gap.tables.availability.find(row => row.employee === 'ava');
  window.through = 5 * 1440 + 20 * 60;
  gap.tables.availability.push({ id: 'ava-after-break', employee: 'ava', from: window.through + 20, through: 7 * 1440 });
  blocker(assess(gap), 'relief', 'AVAILABILITY');
});

test('employee hours and prior rest use exact recorded boundaries', () => {
  const hours = makeCase(), ava = hours.tables.employees.find(row => row.id === 'ava');
  ava.earlierWeekMinutes = 28 * 60; assert.equal(plan(assess(hours), 'coupled').feasible, true);
  ava.earlierWeekMinutes += 1; blocker(assess(hours), 'coupled', 'HOURS');
  const rest = makeCase(), person = rest.tables.employees.find(row => row.id === 'rowan');
  person.lastEarlierShiftEnd = rowan(rest).from - rest.parameters.minimumRestMinutes;
  assert.equal(plan(assess(rest), 'relief').feasible, true);
  person.lastEarlierShiftEnd += 1; blocker(assess(rest), 'relief', 'REST');
});

test('a relief booking prevents simultaneous use without changing its availability', () => {
  const input = makeCase(); input.tables.bookings.push({ id: 'outside-booking', employee: 'rowan', from: rowan(input).from + 30, through: rowan(input).through - 30, amount: 1 });
  blocker(assess(input), 'relief', 'CAPACITY');
});

test('unpaid cancellations remain unavailable and do not re-enter the retained-payroll baseline', () => {
  const input = makeCase();
  input.tables.availability.push({ id: 'nora-window', employee: 'nora', from: 0, through: 7 * 1440 });
  input.tables.assignments.find(row => row.id === 'relief')['sat-dinner-cook-2'] = 'nora';
  const result = assess(input); blocker(result, 'relief', 'AVAILABILITY');
  assert.equal(plan(result, 'relief').scenarios[0].derived.retainedBaselineExpense, 65600);
});

test('genuine priority ties are retained, including an author-added complete repair', () => {
  const expanded = clone(profile);
  expanded.repairs.push({ ...clone(expanded.repairs.find(row => row.id === 'coupled')), id: 'coordinated-copy', label: 'Equivalent supplied repair' });
  const author = createRosterAuthor(expanded), result = commitment.evaluateCommitmentModel(author.makeModel('cost'));
  assert.equal(commitment.isAssessmentComplete(result), true);
  assert.deepEqual(preferred(result), ['coupled', 'coordinated-copy']);
  assert.equal(result.coverage.totalCandidates, 5);
  assert.equal(result.recommendation.unique, false);
});

test('adding an employee to the profile generates that employee\'s hours constraint and consequence', () => {
  const expanded = clone(profile);
  expanded.employees.push({ id: 'new-cook', name: 'New cook', qualifiedRoles: ['cook'], assignmentFeeMinor: 9000, earlierWeekMinutes: 2200, weeklyLimitMinutes: 2400, lastEarlierShiftEnd: 0, availability: [{ from: 0, through: 7 * 1440 }] });
  expanded.repairs.find(row => row.id === 'relief').assignments['sat-dinner-cook-2'] = 'new-cook';
  const author = createRosterAuthor(expanded), model = author.makeModel();
  assert.ok(model.module.constraints.some(row => row.id === 'hours-new-cook'));
  assert.ok(model.module.derived.some(row => row.id === 'minutes-new-cook'));
  const result = commitment.evaluateCommitmentModel(model);
  assert.equal(commitment.isAssessmentComplete(result), true); blocker(result, 'relief', 'HOURS');
  assert.equal(plan(result, 'relief').scenarios[0].derived['minutes-new-cook'], 2440);
});

test('adding a varied-duration position generates all corresponding coverage, hours, payroll and change checks', () => {
  const expanded = clone(profile), id = 'sun-evening-server';
  expanded.services.push({ id: 'sun-evening', label: 'Sunday evening', positions: [{ id, role: 'server', start: 6 * 1440 + 18 * 60, end: 6 * 1440 + 20 * 60, publishedEmployeeId: 'ava' }] });
  expanded.policies.remainingLaborBudgetMinor = 100000;
  for (const repair of expanded.repairs) repair.assignments[id] = 'ava';
  const author = createRosterAuthor(expanded), model = author.makeModel();
  assert.equal(commitment.validateModel(model).valid, true);
  const result = commitment.evaluateCommitmentModel(model), coordinated = plan(result, 'coupled');
  assert.equal(commitment.isAssessmentComplete(result), true);
  assert.equal(coordinated.scenarios[0].derived['minutes-ava'], 2280); // 24h earlier + 12h original + 2h new.
  assert.equal(coordinated.expense, 81600); // Explicit flat assignment fee, never silently prorated.
  assert.equal(coordinated.scenarios[0].derived.retainedBaselineExpense, 73600);
  assert.equal(coordinated.scenarios[0].derived.changedAssignments, 3);
  assert.ok(model.module.constraints.some(row => row.id === `filled-${id}`));
  assert.equal(coordinated.activities.find(row => row.id === id).duration, 120);
});

test('raw canonical inputs cannot add assignable employees, repairs or bypass exclusive capacity', () => {
  for (const mutate of [
    input => { input.tables.employees.push({ ...input.tables.employees[0], id: 'extra-person' }); input.tables.assignments[0]['sat-dinner-cook-2'] = 'extra-person'; },
    input => { input.tables.assignments.push({ ...input.tables.assignments[0], id: 'extra-repair' }); },
    input => { input.tables._resources[0].capacity = 2; },
  ]) {
    const model = makeModel(); mutate(model.case); const admission = commitment.validateModel(model);
    assert.equal(admission.valid, false, JSON.stringify(admission));
  }
  const corrupted = makeModel(); corrupted.case.tables._counts[1].count = 0;
  const result = commitment.evaluateCommitmentModel(corrupted);
  assert.ok(result.plans.every(row => !row.feasible));
  assert.ok(result.plans.every(row => row.blockers.some(item => item.requirement === 'BASIS')));
  const renamed = makeModel(); renamed.case.tables.employees[0].name = 'Different frozen identity';
  assert.ok(commitment.evaluateCommitmentModel(renamed).plans.every(row => row.blockers.some(item => item.requirement === 'BASIS')));
});

test('profile validation rejects duplicates, incomplete repairs, dangling references and malformed chronology', () => {
  for (const mutate of [
    p => { p.employees.push(clone(p.employees[0])); },
    p => { delete p.repairs[0].assignments['sat-dinner-cook-2']; },
    p => { p.repairs[0].assignments['sat-dinner-cook-2'] = 'absent-person'; },
    p => { p.services[0].positions[0].role = 'unknown-role'; },
    p => { p.services[0].positions[0].end = p.services[0].positions[0].start; },
    p => { p.services.reverse(); },
    p => { p.cancellations[0].employeeId = 'ava'; },
    p => { p.cancellations[0].unpaid = false; },
    p => { p.policies.pricing = 'assume-hourly'; },
    p => { p.services[0].positions[0].id = 'id'; },
  ]) {
    const invalid = clone(profile); mutate(invalid);
    assert.equal(validateRosterProfile(invalid).valid, false);
    assert.throws(() => createRosterAuthor(invalid), /profile|employee|position|repair|service/);
  }
});

test('financial presentation follows the authored currency rather than a story-specific default', () => {
  const authored = clone(profile); authored.money = 'EUR cent';
  const model = createRosterAuthor(authored).makeModel();
  assert.equal(commitment.validateModel(model).valid, true);
  assert.equal(model.module.metadata.decisionPresentation.moneyFormat.currency, 'EUR');
  assert.ok(model.module.metadata.decisionPresentation.columns.filter(row => row.format?.kind === 'money').every(row => row.format.currency === 'EUR'));
});

test('case validation rejects unknown identities, modified internal data and invalid intervals', () => {
  const author = createRosterAuthor(profile);
  for (const mutate of [
    input => { input.tables.employees.pop(); },
    input => { input.tables.employees[0].name = 'Changed label'; },
    input => { input.tables.assignments[0]['sat-dinner-cook-2'] = 'ghost'; },
    input => { input.tables._counts.reverse(); },
    input => { rowan(input).through = rowan(input).from; },
    input => { input.tables.qualifications.push(clone(input.tables.qualifications[0])); },
  ]) {
    const input = author.makeCase(); mutate(input);
    assert.equal(author.validateCaseInput(input).valid, false);
    assert.throws(() => author.makeModel('feasibility', input));
  }
});

test('every blocker has a human-readable authored label and decision columns use retained SDK values', () => {
  const model = makeModel(), result = assess(), lab = createDecisionLab();
  assert.ok(model.module.constraints.every(row => typeof model.module.labels[`constraint.${row.id}`] === 'string'));
  const report = lab.reports.create({ model, assessment: result, identity: { runId: 'roster-columns', createdAt: '2026-11-20T12:00:00.000Z' } });
  const decision = lab.reports.decision(report);
  assert.equal(decision.comparison.rows.length, 4);
  assert.equal(decision.comparison.columns.length, 6);
  assert.equal(decision.status, 'complete');
});

test('the generic canonical model packages and executes through the public Node SDK boundary', async () => {
  const executor = createNodeExecutor(), lab = createDecisionLab({ executor });
  try {
    const template = lab.templates.pack(lab.templates.create({ templateId: 'complete-a-commitment', version: '1.0.0', pattern: 'complete-a-commitment/1', title: 'Complete a commitment' }));
    const model = makeModel('stability');
    const packed = lab.apps.pack(lab.apps.create({ template, appId: model.module.id, release: 1, model, source: JSON.stringify(model) }));
    const app = lab.apps.open(packed), bound = lab.cases.create({ app, inputs: makeCase() });
    const run = await lab.run({ app, case: bound, execution: { timeoutMs: 30000 } });
    assert.equal(run.execution.status, 'completed', JSON.stringify(run.execution));
    const assessment = commitment.resolveCommitmentAssessment(run.assessment, run.report);
    assert.equal(commitment.isAssessmentComplete(assessment), true);
    assert.deepEqual(preferred(assessment), ['relief']);
  } finally { await executor.close(); }
});
