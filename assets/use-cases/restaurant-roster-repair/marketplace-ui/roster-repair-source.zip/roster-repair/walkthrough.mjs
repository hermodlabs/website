import assert from 'node:assert/strict';
import { access, mkdir, readFile, readdir, writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { runCLI, CLI_EXIT_CODE, CLI_VERSION } from '@decision-lab/cli';
import { SDK_VERSION, commitment, WORKFLOW_ANSWER_STATUS, WORKFLOW_STEP_STATUS } from '@decision-lab/sdk';
import { rosterAuthor } from './model.mjs';
import { makeRosterWorkflow } from './workflow.mjs';
import configuration from './workflow-config.json' with { type: 'json' };

// A restaurant has a published roster and an unpaid cancellation. Covering
// Saturday by moving someone from Sunday is not necessarily a complete repair.
// This example authors three comparisons of the same supplied complete repairs,
// runs them through the public CLI, and keeps every native finding. The script
// assembles files and checks expectations; it does not decide feasibility.
const home = dirname(fileURLToPath(import.meta.url));
const args = process.argv.slice(2), stage = args.shift() ?? 'all';
const outputFlag = args.indexOf('--output-root');
if (outputFlag >= 0 && (!args[outputFlag + 1] || args[outputFlag + 1].startsWith('--'))) throw new Error('--output-root needs a directory.');
const output = outputFlag >= 0 ? resolve(args.splice(outputFlag, 2)[1]) : join(home, '.output');
const stages = ['author', 'cases', 'changes'];
const source = name => join(home, 'source', name);
const file = (group, name) => join(output, group, name);
const read = async path => JSON.parse(await readFile(path, 'utf8'));
const encode = value => `${JSON.stringify(value, null, 2)}\n`;
const save = (path, value) => writeFile(path, encode(value), { flag: 'wx' });
const shellQuote = value => `'${String(value).replaceAll("'", "'\\''")}'`;
const step = (result, id) => result.steps.find(row => row.id === id);
const hash = value => createHash('sha256').update(value).digest('hex');

if (args.length || ![...stages, 'all', 'help'].includes(stage)) throw new Error('Usage: node walkthrough.mjs [all|author|cases|changes] [--output-root DIRECTORY]');
if (stage === 'help') {
  console.log('Usage: node walkthrough.mjs [all|author|cases|changes] [--output-root DIRECTORY]');
  console.log('Use a fresh directory for all/author. Run author, cases and changes in order. Existing outputs are never overwritten.');
} else {
  if (stage === 'all' || stage === 'author') {
    await mkdir(output, { recursive: true });
    assert.equal((await readdir(output)).length, 0, `Choose a fresh output directory: ${output}`);
  }
  for (const name of stage === 'all' ? stages : [stage]) await runStage(name);
}

async function runStage(name) {
  const directory = file(name, '');
  await mkdir(directory); // A repeated stage fails before any output is changed.
  const transcript = [];
  console.log(`${name}: ${directory}`);
  async function cli(arguments_, expectedExitCode = CLI_EXIT_CODE.COMPLETED) {
    let stdout = '', stderr = '';
    const exitCode = await runCLI(arguments_, { stdout: { write: text => { stdout += text; } }, stderr: { write: text => { stderr += text; } } });
    transcript.push({ args: arguments_, expectedExitCode, exitCode, stdout, stderr });
    await writeFile(join(directory, 'commands.json'), encode(transcript));
    await writeFile(join(directory, 'commands.sh'), `#!/bin/sh\n# Exact inspection transcript. These immutable output paths already exist.\n# Run walkthrough.mjs with a fresh output root to repeat the example.\n${transcript.map(command => `# Expected exit ${command.expectedExitCode}\ndecision-lab ${command.args.map(shellQuote).join(' ')}`).join('\n\n')}\n`);
    assert.equal(exitCode, expectedExitCode, `${arguments_.join(' ')}\n${stderr || stdout}`);
  }
  async function inspect(run, stem) {
    const target = join(directory, `${stem}.output.json`);
    await cli(['workflow', 'inspect', '--run', run, '--output', target]);
    return read(target);
  }
  if (name === 'author') {
    const retainedTemplate = await read(source('commitment.template.json'));
    const templateDefinition = join(directory, 'commitment.template-definition.json'), template = join(directory, 'commitment.template.json');
    await save(templateDefinition, retainedTemplate.definition);
    await cli(['template', 'validate', templateDefinition, '--output', join(directory, 'template.validation.json')]);
    await cli(['template', 'pack', templateDefinition, '--created-at', retainedTemplate.createdAt, '--output', template]);
    assert.deepEqual(await read(template), retainedTemplate);
    const apps = {};
    for (const priority of rosterAuthor.priorities) {
      const model = rosterAuthor.makeModel(priority), modelPath = join(directory, `${priority}.model.json`);
      await save(modelPath, model);
      const definition = join(directory, `${priority}.app-definition.yaml`), appPath = join(directory, `${priority}.app.json`);
      await cli(['app', 'init', '--template', template, '--model', modelPath, '--app-id', model.module.id, '--release', '1', '--output', definition]);
      await cli(['app', 'validate', definition, '--output', join(directory, `${priority}.validation.json`)]);
      await cli(['app', 'pack', definition, '--created-at', configuration.publishedAt, '--output', appPath]);
      apps[priority] = await read(appPath);
      assert.deepEqual(apps[priority], await read(source(`${priority}.app.json`)), `${priority}: CLI authoring must reproduce the supplied package exactly.`);
    }
    const workflowSource = makeRosterWorkflow({ author: rosterAuthor, apps });
    // The reviewed source includes the case schema used by the YAML/Excel
    // interface. Reuse that authored schema; do not infer another schema from
    // current values or silently approve new field meanings.
    const retainedSource = await read(source('workflow.source.json'));
    workflowSource.metadata.caseSchema = retainedSource.metadata.caseSchema;
    assert.deepEqual(workflowSource, retainedSource, 'This walkthrough reconstructs the supplied authored workflow, including its interface contract.');
    const authoredSource = join(directory, 'workflow.source.json'), definition = join(directory, 'workflow.definition.json');
    await save(authoredSource, workflowSource);
    await cli(['workflow', 'create', '--source', authoredSource, '--output', definition]);
    await cli(['workflow', 'validate', definition, '--output', join(directory, 'workflow.validation.json')]);
    assert.deepEqual(await read(definition), await read(source('workflow.definition.json')));

    // Creating a runtime definition and publishing an installable package are
    // separate operations. Reopen the supplied publication only after proving
    // it contains the exact definition just authored. No binding reviews or
    // human approval receipts are synthesized by this example.
    const published = await read(source('roster.workflow.json'));
    assert.deepEqual(published.workflow, await read(definition));
    await cli(['workflow', 'package-validate', source('roster.workflow.json'), '--output', join(directory, 'package.validation.json')]);
    const packagePath = join(directory, 'roster.workflow.json');
    await cli(['workflow', 'package-open', source('roster.workflow.json'), '--output', packagePath]);
    await cli(['workbook', 'pack', '--target', packagePath, '--mapping', source('workbook.mapping.json'), '--starter', join(home, 'cases', 'full-availability.json'), '--starter-meaning', 'example', '--output', join(directory, 'roster.workbook.json')]);
    assert.deepEqual(await read(join(directory, 'roster.workbook.json')), await read(source('roster.workbook.json')));
    await save(join(directory, 'verification.json'), {
      cliVersion: CLI_VERSION, sdkVersion: SDK_VERSION,
      profileSha256: hash(await readFile(join(home, 'profile.json'))),
      appPackageHashes: Object.fromEntries(Object.entries(apps).map(([id, app]) => [id, app.contentHash])),
      workflowDefinitionHash: published.workflow.contentHash, publishedPackageHash: published.contentHash,
      conclusion: 'The CLI-created apps and runtime definition exactly match the supplied installable publication.',
    });
  } else if (name === 'cases') {
    const definition = file('author', 'workflow.definition.json'); await access(definition);
    const specifications = [
      { id: 'full-availability', active: 'feasibility', passing: ['relief', 'coupled'], preferred: [] },
      { id: 'short-availability', active: 'feasibility', passing: ['coupled'], preferred: [] },
      { id: 'stability-first', active: 'stability', passing: ['relief', 'coupled'], preferred: ['relief'] },
      { id: 'cost-first', active: 'cost', passing: ['relief', 'coupled'], preferred: ['coupled'] },
      { id: 'no-passing-repair', active: 'feasibility', passing: [], preferred: [] },
    ];
    const findings = [];
    for (const specification of specifications) {
      const initial = join(directory, `${specification.id}.started.run.json`), solved = join(directory, `${specification.id}.solved.run.json`);
      await cli(['workflow', 'start', '--definition', definition, '--case', join(home, 'cases', `${specification.id}.json`), '--run-id', `roster-${specification.id}`, '--created-at', configuration.publishedAt, '--output', initial]);
      await cli(['workflow', 'solve', '--run', initial, '--created-at', configuration.publishedAt, '--output', solved]);
      const result = await inspect(solved, specification.id);
      await cli(['workflow', 'brief', '--run', solved, '--output', join(directory, `${specification.id}.brief.json`)]);
      findings.push(checkFinding(result, specification));
    }
    await save(join(directory, 'verification.json'), { findings });
  } else {
    let currentRun = file('cases', 'full-availability.solved.run.json'); await access(currentRun);
    const initial = await read(file('cases', 'full-availability.output.json'));
    const originalFeasibilityId = step(initial, 'feasibility').evaluationId;
    const findings = [];
    for (const priority of ['stability', 'cost']) {
      const value = join(directory, `${priority}.value.json`); await save(value, priority);
      const answered = join(directory, `${priority}.supplied.run.json`);
      await cli(['workflow', 'answer', '--run', currentRun, '--question', 'priority', '--status', WORKFLOW_ANSWER_STATUS.SUPPLIED, '--value', value, '--at', configuration.publishedAt, '--output', answered]);
      const pending = await inspect(answered, `${priority}.before-calculation`);
      assert.equal(step(pending, 'feasibility').status, WORKFLOW_STEP_STATUS.COMPLETE);
      assert.equal(step(pending, 'feasibility').evaluationId, originalFeasibilityId, 'A changed comparison priority must reuse the same feasibility finding.');
      currentRun = join(directory, `${priority}.solved.run.json`);
      await cli(['workflow', 'solve', '--run', answered, '--created-at', configuration.publishedAt, '--output', currentRun]);
      const result = await inspect(currentRun, priority);
      assert.equal(step(result, 'feasibility').evaluationId, originalFeasibilityId);
      findings.push(checkFinding(result, { id: priority, active: priority, passing: ['relief', 'coupled'], preferred: [priority === 'stability' ? 'relief' : 'coupled'] }));
    }
    const value = join(directory, 'short-availability.value.json'); await save(value, { fromMinute: 1080, throughMinute: 1200 });
    const changed = join(directory, 'availability.supplied.run.json');
    await cli(['workflow', 'answer', '--run', currentRun, '--question', 'relief-window', '--status', WORKFLOW_ANSWER_STATUS.SUPPLIED, '--value', value, '--at', configuration.publishedAt, '--output', changed]);
    const stale = await inspect(changed, 'availability.before-calculation');
    assert.equal(step(stale, 'feasibility').status, WORKFLOW_STEP_STATUS.STALE);
    assert.equal(step(stale, 'cost').status, WORKFLOW_STEP_STATUS.STALE);
    assert.notEqual(stale.decisionSummary.finding.availability, 'available', 'Outdated recommendations must not remain current.');
    const updated = join(directory, 'availability.solved.run.json');
    await cli(['workflow', 'solve', '--run', changed, '--created-at', configuration.publishedAt, '--output', updated]);
    const result = await inspect(updated, 'availability');
    assert.notEqual(step(result, 'feasibility').evaluationId, originalFeasibilityId);
    findings.push(checkFinding(result, { id: 'changed-availability', active: 'cost', passing: ['coupled'], preferred: ['coupled'] }));
    await save(join(directory, 'verification.json'), { originalFeasibilityId, changedAvailabilityRequiresRecalculation: true, findings });
  }
}

function checkFinding(result, expected) {
  assert.equal(result.brief.complete, true, JSON.stringify(result.brief.issues));
  assert.deepEqual(result.reviews, []);
  assert.ok(result.questions.every(answer => answer.status === WORKFLOW_ANSWER_STATUS.SUPPLIED && !Object.hasOwn(answer, 'actor')));
  const active = step(result, expected.active);
  assert.equal(active.status, WORKFLOW_STEP_STATUS.COMPLETE);
  assert.equal(commitment.isAssessmentComplete(active.assessment), true);
  assert.equal(active.assessment.coverage.evaluatedCandidates, rosterAuthor.profile.repairs.length);
  const passing = active.assessment.plans.filter(candidate => candidate.feasible).map(candidate => candidate.choices.repair);
  const preferredIds = active.assessment.recommendation?.tiedPlanIds ?? [];
  const preferred = active.assessment.plans.filter(candidate => preferredIds.includes(candidate.id)).map(candidate => candidate.choices.repair);
  assert.deepEqual(passing, expected.passing); assert.deepEqual(preferred, expected.preferred);
  assert.equal(result.decisionSummary.finding.availability, 'available');
  assert.ok(result.decisionProcess.nodes.length > 0 && result.decisionProcess.edges.length > 0);
  const economics = active.assessment.plans.map(candidate => ({ repair: candidate.choices.repair, remainingPayrollMinor: candidate.expense,
    additionalExpenseMinor: candidate.scenarios[0].derived.additionalExpense, changedPositions: candidate.scenarios[0].derived.changedAssignments }));
  assert.deepEqual(economics.map(candidate => candidate.remainingPayrollMinor), [65600, 65600, 83600, 73600]);
  console.log(`${expected.id}: passing [${passing.join(', ')}]; preferred [${preferred.join(', ')}]`);
  return { case: expected.id, passing, preferred, economics, actionIds: result.brief.actions.map(action => action.id) };
}
