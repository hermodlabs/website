// Authoring only: these expressions become ordinary portable workflow metadata.
// The CLI and UI execute the same pinned commitment apps. This file neither
// evaluates roster rules nor chooses a repair in JavaScript.
import configuration from './workflow-config.json' with { type: 'json' };

const ref = path => ({ ref: path });
const literal = value => ({ literal: value });
const op = (operator, ...args) => ({ op: operator, args });
const get = (value, key) => op('get', value, key);
const eq = (left, right) => op('eq', left, right);
const and = (...args) => op('and', ...args);
const choose = (condition, yes, no) => op('if', condition, yes, no);
const map = (source, as, projection) => ({ op: 'map', args: [source, projection], as });
const filter = (source, as, predicate) => ({ op: 'filter', args: [source, predicate], as });
const size = source => op('length', source);
const row = path => ref(`vars.${path}`);
const priorities = [
  { value: 'feasibility', label: 'Compare without ranking' },
  { value: 'stability', label: 'Preserve published assignments first' },
  { value: 'cost', label: 'Minimize remaining payroll first' },
];

export function makeRosterWorkflow({ author, apps, config = configuration }) {
  const base = author.makeCase(), profile = author.profile;
  const positions = profile.services.flatMap(service => service.positions.map(position => ({ ...position, serviceLabel: service.label })));
  const focus = base.tables.availability.find(record => record.id === config.focusAvailabilityId)
    ?? base.tables.availability.find(record => record.employee === config.focusEmployeeId);
  if (!focus) throw new Error('The authored focus availability must identify an existing employee interval.');
  const name = profile.employees.find(person => person.id === config.focusEmployeeId)?.name;
  const regularAvailability = base.tables.availability.filter(record => record.id !== focus.id);
  const labels = Object.fromEntries(profile.repairs.map(repair => [repair.id, repair.label]));
  const model = apps.feasibility.app.model;
  const conditionLabels = Object.fromEntries(model.module.constraints.map(condition => [condition.id,
    model.module.labels?.[`constraint.${condition.id}`] ?? model.module.requirements.find(requirement => requirement.id === condition.requirement)?.label ?? condition.id]));
  const published = Object.fromEntries(positions.map(position => [position.id, position.publishedEmployeeId]));
  const cancelledPositions = new Set(profile.cancellations.map(cancellation => cancellation.positionId));
  const positionLabels = Object.fromEntries(positions.map(position => [position.id, `${position.serviceLabel}: ${profile.roles.find(role => role.id === position.role).label}${position.id.endsWith('-1') ? ' 1' : position.id.endsWith('-2') ? ' 2' : ''}`]));
  const initialCase = { roster: {
    reliefWindow: { fromMinute: focus.from - config.focusDayStartMinute, throughMinute: focus.through - config.focusDayStartMinute },
    remainingPayrollLimitMinor: base.parameters.remainingLaborBudgetMinor,
    comparisonPriority: 'feasibility', employees: base.tables.employees,
    qualifications: base.tables.qualifications, assignments: base.tables.assignments,
    otherAvailability: regularAvailability, bookings: base.tables.bookings,
  } };
  const operatingQuestions = ['relief-window', 'payroll-limit', 'employees', 'qualifications', 'assignments', 'other-availability', 'bookings'];
  const question = (id, label, questionText, meaning, path, type) => ({ id, label, question: questionText, meaning, path: `roster.${path}`, type, role: 'roster-owner', required: true });
  const questions = [
    question('relief-window', 'Relief cook availability', 'When can the relief cook cover the affected service?', `The complete working interval for ${name} on ${config.focusDayLabel}. An early finish does not shorten the required service.`, 'reliefWindow', 'object'),
    question('payroll-limit', 'Remaining payroll limit', 'What is the maximum complete payroll for the remaining services?', 'Complete remaining payroll in USD cents, including retained assignments and the repair. Additional expense is calculated against the retained baseline.', 'remainingPayrollLimitMinor', 'number'),
    question('priority', 'Comparison priority', 'How should passing repairs be compared?', 'Choose an authored priority. Every mandatory staffing and expense requirement remains unchanged. Compare without ranking leaves every passing repair available.', 'comparisonPriority', 'string'),
    question('employees', 'Employee work records', 'What fees and previous work apply to the listed employees?', 'Only authored employee identities are supported. Fees are flat amounts per assignment. Earlier work is retained as minutes and the latest previous shift end.', 'employees', 'array'),
    question('qualifications', 'Recorded qualifications', 'Which listed employees can fill each role?', 'Recorded qualifications for the authored roles. A missing qualification cannot establish suitability for that role.', 'qualifications', 'array'),
    question('assignments', 'Complete proposed repairs', 'Who covers every position in each proposed repair?', 'Complete assignments to every authored position. Changing the employee, position or proposal catalog requires authoring a new profile and publishing a new version.', 'assignments', 'array'),
    question('other-availability', 'Other working availability', 'When are the other listed employees available?', 'Working intervals for the other employees, with breaks and unavailable periods omitted. The relief cook interval is supplied separately.', 'otherAvailability', 'array'),
    question('bookings', 'Other employee commitments', 'Which retained commitments consume employee capacity?', 'Existing overlapping work using the same employee identities and week clock. Empty means no other commitments are recorded for this comparison.', 'bookings', 'array'),
  ];
  const validPriority = op('or', ...priorities.map(priority => eq(ref('case.roster.comparisonPriority'), priority.value)));
  const selected = field => choose(ref('conditions.stability-selected'), ref(`steps.stability.output${field ? `.${field}` : ''}`),
    choose(ref('conditions.cost-selected'), ref(`steps.cost.output${field ? `.${field}` : ''}`), ref(`steps.feasibility.output${field ? `.${field}` : ''}`)));
  const input = { ...Object.fromEntries(Object.entries(base).filter(([key]) => !['parameters', 'tables'].includes(key)).map(([key, value]) => [key, literal(value)])),
    parameters: { ...base.parameters, remainingLaborBudgetMinor: ref('case.roster.remainingPayrollLimitMinor') },
    tables: { ...Object.fromEntries(Object.entries(base.tables).filter(([key]) => !['employees', 'qualifications', 'assignments', 'availability', 'bookings'].includes(key)).map(([key, value]) => [key, literal(value)])),
      employees: ref('case.roster.employees'), qualifications: ref('case.roster.qualifications'), assignments: ref('case.roster.assignments'), bookings: ref('case.roster.bookings'),
      availability: op('concat', ref('case.roster.otherAvailability'), [{ id: focus.id, employee: config.focusEmployeeId,
        from: op('add', config.focusDayStartMinute, ref('case.roster.reliefWindow.fromMinute')),
        through: op('add', config.focusDayStartMinute, ref('case.roster.reliefWindow.throughMinute')) }]),
    } };
  const firstScenario = get(row('plan.scenarios'), 0), derived = get(firstScenario, 'derived');
  const output = { finding: ref('assessment.finding'),
    plans: map(ref('assessment.plans'), 'plan', {
      id: row('plan.choices.repair'), planId: row('plan.id'), label: get(literal(labels), row('plan.choices.repair')),
      feasible: row('plan.feasible'),
      preferred: and(eq(ref('assessment.recommendation.preferenceEstablished'), true), { op: 'any', args: [ref('assessment.recommendation.tiedPlanIds'), eq(ref('item'), row('plan.id'))] }),
      remainingPayrollMinor: row('plan.expense'), additionalExpenseMinor: get(derived, 'additionalExpense'),
      baselineMinor: get(derived, 'retainedBaselineExpense'), changedPositions: get(derived, 'changedAssignments'),
      blockers: map(row('plan.blockers'), 'blocker', { condition: get(literal(conditionLabels), row('blocker.constraintId')), requirement: row('blocker.requirement') }),
      assignments: map(row('plan.activities'), 'activity', { position: get(literal(positionLabels), row('activity.id')), employee: row('activity.actor'),
        publishedEmployee: get(literal(published), row('activity.id')), changed: op('ne', row('activity.actor'), get(literal(published), row('activity.id'))), start: row('activity.start'), end: row('activity.end') }),
    }), preferenceEstablished: ref('assessment.recommendation.preferenceEstablished') };
  const checks = [{ id: 'focused-availability', message: `Supply an ordered working interval within ${config.focusDayLabel}.`, test: and(
    op('matchesSchema', ref('case.roster.reliefWindow'), literal({ type: 'object', additionalProperties: false, required: ['fromMinute', 'throughMinute'], properties: {
      fromMinute: { type: 'integer', minimum: 0, maximum: 1440 }, throughMinute: { type: 'integer', minimum: 0, maximum: 1440 } } })),
    op('lt', ref('case.roster.reliefWindow.fromMinute'), ref('case.roster.reliefWindow.throughMinute'))) }];
  const steps = ['feasibility', 'stability', 'cost'].map(id => ({ id, title: ({ feasibility: 'Find passing complete repairs', stability: 'Compare by published-assignment stability', cost: 'Compare by remaining payroll' })[id], app: id, role: 'roster-owner',
    dependsOn: id === 'feasibility' ? [] : ['feasibility'], requires: [...operatingQuestions, ...(id === 'feasibility' ? [] : ['priority'])],
    ...(id === 'feasibility' ? {} : { when: ref(`conditions.${id}-selected`) }), input, output, checks,
    acceptWhen: and(eq(ref('assessment.status'), 'complete'), eq(ref('assessment.coverage.complete'), true)) }));
  const passing = filter(selected('plans'), 'candidate', eq(row('candidate.feasible'), true));
  const preferred = filter(passing, 'candidate', eq(row('candidate.preferred'), true));
  const priorityLabel = choose(ref('conditions.stability-selected'), 'Preserve published assignments first; use payroll to break ties.',
    choose(ref('conditions.cost-selected'), 'Minimize remaining payroll first; use changed positions to break ties.', 'Compare without ranking; no preferred repair is declared.'));
  const current = and(eq(ref('steps.feasibility.status'), 'complete'), choose(ref('conditions.stability-selected'), eq(ref('steps.stability.status'), 'complete'),
    choose(ref('conditions.cost-selected'), eq(ref('steps.cost.status'), 'complete'), true)));
  const condition = (id, label, test, requires) => ({ id, label, ...(requires ? { requires } : {}), test });
  const conditions = [
    condition('priority-valid', 'Use one of the three authored comparison priorities', op('require', validPriority, true, 'Choose Compare without ranking, Preserve published assignments first, or Minimize remaining payroll first.'), ['priority']),
    condition('stability-selected', 'Preserve published assignments first is selected', and(ref('conditions.priority-valid'), eq(ref('case.roster.comparisonPriority'), 'stability')), ['priority']),
    condition('cost-selected', 'Minimize remaining payroll first is selected', and(ref('conditions.priority-valid'), eq(ref('case.roster.comparisonPriority'), 'cost')), ['priority']),
    condition('ranked', 'An authored ranking priority is selected', and(ref('conditions.priority-valid'), op('ne', ref('case.roster.comparisonPriority'), 'feasibility')), ['priority']),
    condition('result-current', 'The selected comparison has a current complete calculation', current),
    condition('has-repairs', 'At least one supplied complete repair meets every requirement', op('gt', size(filter(ref('steps.feasibility.output.plans'), 'candidate', eq(row('candidate.feasible'), true))), 0)),
    condition('can-compare', 'Current passing repairs are available to compare', and(ref('conditions.result-current'), ref('conditions.has-repairs'))),
    condition('must-revise', 'No supplied repair meets the requirements', and(ref('conditions.result-current'), op('not', ref('conditions.has-repairs')))),
  ];
  const heading = choose(op('eq', size(passing), 0), 'No supplied repair meets every recorded requirement.',
    choose(ref('conditions.ranked'), choose(op('eq', size(preferred), 1),
      op('stringConcat', get(get(preferred, 0), 'label'), ' is preferred under the selected priority.'), 'Several passing repairs share the selected priority.'),
    choose(eq(size(passing), 1), 'One supplied repair meets every recorded requirement.',
      op('stringConcat', op('stringify', size(passing)), ' supplied repairs meet every recorded requirement.'))));
  const summary = choose(ref('conditions.result-current'), {
    status: choose(op('eq', size(passing), 0), 'blocked', choose(ref('conditions.ranked'), 'supported', 'choice')), heading, priorityLabel,
    qualification: 'Only the supplied complete repairs are compared. Staff agreement and communicating the revised roster remain separate business actions.',
    metrics: [{ id: 'retained-baseline', label: 'Retained remaining payroll', value: get(get(selected('plans'), 0), 'baselineMinor'), format: 'money' },
      { id: 'limit', label: 'Remaining payroll limit', value: ref('case.roster.remainingPayrollLimitMinor'), format: 'money' }],
    conditions: [{ id: 'remaining-services', label: 'Every remaining service stays in scope',
      detail: `${profile.services.map(service => service.label).join(', ')}. The published baseline identifies unpaid cancellations; a repair must cover the complete remaining roster.`, tabId: 'published' }], rows: passing,
  }, null);
  const columns = [
    { key: 'label', label: 'Complete repair' }, { key: 'remainingPayrollMinor', label: 'Remaining payroll', format: 'money' },
    { key: 'additionalExpenseMinor', label: 'Additional expense', format: 'money' }, { key: 'changedPositions', label: 'Changed positions', format: 'number' },
  ];
  const brief = { sections: [
    { id: 'decision-summary', title: 'Decision summary', value: summary },
    { id: 'repair-comparison', title: 'All supplied repairs', value: choose(ref('conditions.result-current'), selected('plans'), []) },
    { id: 'roster-basis', title: 'Published roster and remaining services', value: literal(positions.map(position => ({ position: positionLabels[position.id], employee: position.publishedEmployeeId,
      recordedChange: cancelledPositions.has(position.id) ? 'Unpaid cancellation; replacement needed' : 'Published assignment retained in the baseline', start: position.start, end: position.end }))) },
    { id: 'assignments', title: 'Complete remaining roster', value: ref('steps.feasibility.output.plans') },
    { id: 'decision-basis', title: 'Material roster-repair basis', value: {
      scope: 'Compare the supplied complete repairs across every remaining service. All priorities use the same operating facts and mandatory requirements; changing the comparison priority does not relax feasibility.',
      assumptions: ['The remaining published assignments, recorded interruption, employee qualifications, availability and bookings define the complete operating basis.',
        'Recorded durations, rest requirements, hour limits and remaining-payroll costs apply across all remaining services, not just the disrupted service.',
        'Stability counts changed published positions, while payroll compares complete remaining expense. A tie remains a tie under the authored priority.'],
      unresolvedQuestions: [{ id: 'agreement', label: 'Staff agreement and publication of a changed roster require separate operating action.' }],
    } },
  ], actions: [
    { id: 'compare-repairs', label: 'Compare the passing complete repairs', when: ref('conditions.can-compare'), value: { summary: 'Inspect the full assignments and tradeoff before choosing a repair.' } },
    { id: 'revise-repairs', label: 'Revise the proposed repairs or operating facts', when: ref('conditions.must-revise'), value: { summary: 'Inspect the failed conditions. The absence of a passing supplied repair does not rule out other repairs.' } },
    { id: 'agree-assignments', label: 'Obtain staff agreement and communicate the chosen roster', when: ref('conditions.can-compare'), value: { summary: 'This calculation does not contact employees, record agreement or publish a roster.' } },
  ], completion: ref('conditions.result-current') };
  const e = (id, from, to, label, outcome, kind) => ({ id, from, to, label, ...(outcome ? { outcome } : {}), ...(kind ? { kind } : {}) });
  const decisionProcess = { title: 'Choose a complete roster repair', description: 'Follow the findings from complete coverage to the selected comparison priority and remaining business actions.', entryNodeIds: ['inputs'],
    nodes: [
      { id: 'inputs', kind: 'stage', label: 'Supply the interrupted roster and working records', questionIds: operatingQuestions, sectionIds: ['roster-basis'] },
      { id: 'calculate', kind: 'stage', label: 'Calculate every supplied complete repair', stepIds: ['feasibility'] },
      { id: 'passing', kind: 'decision', label: 'Does any supplied repair meet every requirement?', conditionId: 'has-repairs' },
      { id: 'priority', kind: 'decision', label: 'Is a comparison priority selected?', conditionId: 'ranked', questionIds: ['priority'] },
      { id: 'rank', kind: 'stage', label: 'Apply the selected priority to passing repairs', stepIds: ['stability', 'cost'] },
      { id: 'compare', kind: 'action', label: 'Compare the passing complete repairs', actionId: 'compare-repairs' },
      { id: 'revise', kind: 'action', label: 'Revise proposals or operating facts', actionId: 'revise-repairs' },
      { id: 'complete-inputs', kind: 'outcome', label: 'Complete missing inputs, correct invalid data or finish calculation', questionIds: operatingQuestions },
      { id: 'agree', kind: 'action', label: 'Obtain agreement and communicate the chosen roster', actionId: 'agree-assignments' },
    ], edges: [
      e('inputs-calculate', 'inputs', 'calculate', 'Use the same operating facts for every comparison'),
      e('calculate-passing', 'calculate', 'passing', 'Use the complete coverage finding'),
      e('passing-priority', 'passing', 'priority', 'One or more repairs pass', 'true'),
      e('passing-revise', 'passing', 'revise', 'No supplied repair passes', 'false'),
      ...['unknown', 'not-calculated', 'stale', 'error'].map(state => e(`passing-${state}`, 'passing', 'complete-inputs', ({ unknown: 'Required facts are unknown', 'not-calculated': 'Calculation is not complete', stale: 'Inputs changed; recalculate', error: 'Inputs or calculation need correction' })[state], state)),
      e('priority-rank', 'priority', 'rank', 'Apply the authored priority', 'true'),
      e('priority-compare', 'priority', 'compare', 'Compare without ranking', 'false'),
      ...['unknown', 'error'].map(state => e(`priority-${state}`, 'priority', 'complete-inputs', 'Supply a supported comparison priority', state)),
      e('rank-compare', 'rank', 'compare', 'Keep genuine ties visible'),
      e('compare-agree', 'compare', 'agree', 'After a person chooses a supported proposal'),
      e('revise-inputs', 'revise', 'inputs', 'Reassess revised proposals and facts', null, 'reassessment'),
      e('complete-inputs-return', 'complete-inputs', 'inputs', 'Supply or correct the required facts', null, 'reassessment'),
      e('agree-inputs', 'agree', 'inputs', 'Recalculate if agreement changes availability', null, 'reassessment'),
    ], groups: [
      { id: 'interrupted-commitment', label: '1. Establish the remaining commitment', nodeIds: ['inputs'] },
      { id: 'complete-coverage', label: '2. Check every remaining service', nodeIds: ['calculate', 'passing', 'complete-inputs'] },
      { id: 'comparison-priority', label: '3. Apply an optional priority', nodeIds: ['priority', 'rank'] },
      { id: 'operating-response', label: '4. Choose a response', nodeIds: ['compare', 'revise', 'agree'] },
    ], actionGroups: [
      { id: 'repair-response', label: 'Available operating response', selection: 'exclusive', actionIds: ['compare-repairs', 'revise-repairs'] },
      { id: 'staff-handoff', label: 'After choosing a repair', selection: 'all-matching', actionIds: ['agree-assignments'] },
    ] };
  const number = (label, extras = {}) => ({ type: 'number', label, integer: true, minimum: 0, ...extras });
  const text = (label, options) => ({ type: 'string', label, ...(options ? { options } : {}) });
  const employeeOptions = profile.employees.map(person => ({ value: person.id, label: person.name }));
  const tableSchema = (label, fields, maxItems) => ({ type: 'array', label, collapseRecords: true, summaryFields: ['id', 'employee'], ...(maxItems ? { maxItems } : {}), items: { type: 'object', label, fields } });
  const clockOptions = Array.from({ length: 49 }, (_, index) => { const minutes = index * 30; return { value: minutes, label: minutes === 1440 ? 'Midnight at end of day' : `${Math.floor(minutes / 60) % 12 || 12}:${minutes % 60 ? '30' : '00'} ${minutes < 720 ? 'a.m.' : 'p.m.'}` }; });
  const fields = {
    'relief-window': { type: 'object', label: 'Relief cook availability', fields: {
      fromMinute: number(`Available from on ${config.focusDayLabel}`, { options: clockOptions }),
      throughMinute: number(`Available until on ${config.focusDayLabel}`, { options: clockOptions }),
    }, help: `${name} must be available for the complete required interval. The full remaining service window stays in scope.` },
    'payroll-limit': number('Remaining payroll limit', { displayScale: 100, unit: 'USD; complete remaining services', help: 'Includes retained assignments and the complete repair. Additional expense is calculated separately.' }),
    priority: text('Comparison priority', priorities),
    employees: tableSchema('Employee work records', { id: text('Employee', employeeOptions), name: text('Display name'), assignmentFeeMinor: number('Flat fee per assignment (USD cents)'),
      earlierWeekMinutes: number('Minutes already worked this week'), weeklyLimitMinutes: number('Recorded weekly limit (minutes)'), lastEarlierShiftEnd: number('Latest previous shift end (minute from Monday)') }, base.tables.employees.length),
    qualifications: tableSchema('Recorded qualifications', { employee: text('Employee', employeeOptions), role: text('Qualified role', profile.roles.map(role => ({ value: role.id, label: role.label }))) }),
    assignments: tableSchema('Complete proposed repairs', { id: text('Supplied repair', profile.repairs.map(repair => ({ value: repair.id, label: repair.label }))),
      ...Object.fromEntries(positions.map(position => [position.id, text(positionLabels[position.id], [...employeeOptions, { value: 'unfilled', label: 'Unfilled' }])])) }, profile.repairs.length),
    'other-availability': tableSchema('Other working availability', { id: text('Interval reference'), employee: text('Employee', employeeOptions.filter(person => person.value !== config.focusEmployeeId)), from: number('From (minute from Monday)'), through: number('Through (minute from Monday)') }),
    bookings: tableSchema('Other employee commitments', { id: text('Commitment reference'), employee: text('Employee', employeeOptions), from: number('From (minute from Monday)'), through: number('Through (minute from Monday)'), amount: number('Capacity used', { maximum: 1 }) }),
  };
  const sourceStepConditions = [{ stepId: 'stability', conditionId: 'stability-selected' }, { stepId: 'cost', conditionId: 'cost-selected' }];
  const metadata = { caseStart: { starterMeaning: 'example', supportsOwnData: false,
    scope: 'The configured employees, service positions and four complete repair proposals. Change availability, payroll or comparison priority here; a different restaurant roster needs an adapted author profile.' },
    presentation: { version: 1, questions: fields,
    groups: [
      { id: 'decision-inputs', label: 'Repair decision', question: 'Which complete repairs remain usable, and how should they be compared?', subtabs: [
        { id: 'availability', label: 'Availability', questionIds: ['relief-window'] },
        { id: 'payroll', label: 'Payroll boundary', questionIds: ['payroll-limit'] },
        { id: 'priority', label: 'Comparison priority', questionIds: ['priority'] },
      ] },
      { id: 'supporting-inputs', label: 'Supporting records', question: 'Which records support the complete roster comparison?', subtabs: [
        { id: 'people', label: 'People and qualifications', questionIds: ['employees', 'qualifications'] },
        { id: 'working-time', label: 'Working intervals', questionIds: ['other-availability', 'bookings'] },
        { id: 'proposals', label: 'Proposed repairs', questionIds: ['assignments'] },
      ] },
      { id: 'planning', kind: 'evaluations', label: 'Calculation dependencies', question: 'Which pinned calculations establish feasibility and the selected comparison?', subtabs: [] },
      { id: 'next-action', kind: 'brief', label: 'Decision summary', question: 'Which supplied repairs cover every service and fit the selected priority?', subtabs: [] },
    ], display: { currency: 'USD', amountUnit: 'cent', timeUnit: 'minute', timeOrigin: config.calendarOrigin,
      names: { ...labels, ...Object.fromEntries(profile.employees.map(person => [person.id, person.name])), unfilled: 'Unfilled' },
      nameSources: [{ questionId: 'employees', idField: 'id', labelField: 'name' }],
      formats: { remainingPayrollMinor: 'money', additionalExpenseMinor: 'money', baselineMinor: 'money', start: { type: 'time', timeZone: config.timeZone }, end: { type: 'time', timeZone: config.timeZone }, time: { type: 'time', timeZone: config.timeZone }, duration: 'duration' },
    }, workflowMap: { title: 'Roster repair calculations', description: 'Feasibility uses the shared operating facts. An optional authored priority compares only passing repairs; changing priorities preserves the feasibility calculation.',
      steps: {
        feasibility: { label: 'Complete repair feasibility', description: 'Check every supplied repair against all mandatory requirements and all remaining services.' },
        stability: { label: 'Stability-first comparison', description: 'Preserve published positions first, then use remaining payroll to break ties.', inactiveReasons: [{ id: 'not-selected', label: 'Stability-first is not the selected priority.', when: op('not', ref('conditions.stability-selected')) }] },
        cost: { label: 'Cost-first comparison', description: 'Minimize remaining payroll first, then use changed positions to break ties.', inactiveReasons: [{ id: 'not-selected', label: 'Cost-first is not the selected priority.', when: op('not', ref('conditions.cost-selected')) }] },
      }, groups: [{ id: 'coverage', label: 'Operating feasibility', stepIds: ['feasibility'] }, { id: 'priority', label: 'Optional comparison', stepIds: ['stability', 'cost'] }],
    }, report: { title: 'Roster repair reports',
      readableBrief: { format: 'workflow-readable-brief/1', sectionId: 'decision-basis', sourceStepIds: [] },
      tabs: [
        { id: 'conditions', label: 'All repairs', question: 'Which supplied repairs pass, and why are the others blocked?', sectionId: 'repair-comparison', viewId: 'repair-details' },
        { id: 'assignments', label: 'Complete roster', question: 'Who covers each service in the selected complete repair?', kind: 'schedules', stepIds: ['feasibility'], sectionId: 'assignments',
          selection: { group: 'roster-repair', keyField: 'choices.repair', labelField: 'choices.repair' },
          columns: [{ key: 'activity', label: 'Service position' }, { key: 'actor', label: 'Employee' }, { key: 'start', label: 'Start' }, { key: 'end', label: 'Finish' }],
          timeline: { extent: 'activities', label: 'Service time' } },
        { id: 'published', kind: 'records', label: 'Published baseline', question: 'Which remaining services and assignments form the comparison baseline?', sectionId: 'roster-basis', columns: [{ key: 'position', label: 'Service position' }, { key: 'employee', label: 'Published employee', format: 'name' }, { key: 'recordedChange', label: 'Recorded interruption' }, { key: 'start', label: 'Start', format: { type: 'time', timeZone: config.timeZone } }, { key: 'end', label: 'Finish', format: { type: 'time', timeZone: config.timeZone } }] },
      ],
      questionViews: [{ id: 'repair-details', sectionId: 'repair-comparison', title: 'Complete repair comparison', question: 'Which supplied complete repairs meet the recorded requirements?',
        selection: { group: 'roster-repair', keyField: 'id', labelField: 'label' }, comparison: { columns: [...columns, { key: 'feasible', label: 'Meets requirements', format: 'boolean' }, { key: 'preferred', label: 'Preferred under selected priority', format: 'boolean' }] },
        details: [{ id: 'blockers', title: 'Unmet requirements', question: 'Which conditions prevent this repair?', fields: [{ key: 'blockers', label: 'Unmet requirements' }] },
          { id: 'assignments', title: 'Published assignment changes', question: 'Which people and service positions change?', fields: [{ key: 'assignments', label: 'Complete assignments and changes' }] }],
      }],
      decisionSummary: { format: 'workflow-decision-summary/1', sectionId: 'decision-summary', sourceStepIds: ['feasibility'], sourceStepConditions,
        comparison: { title: 'Passing complete repairs', keyField: 'id', labelField: 'label', tabId: 'assignments', inspectionKeyField: 'id', columns },
        actionGroups: [{ id: 'repair-response', presentation: 'actions' }, { id: 'staff-handoff', presentation: 'link', tabId: 'assignments', label: 'Inspect assignments before obtaining staff agreement' }],
        links: [{ tabId: 'conditions', label: 'Inspect blocked repairs' }, { tabId: 'published', label: 'Inspect published baseline' }] },
    } } };
  return { id: config.id, version: config.version, title: config.title,
    question: 'Which supplied complete repairs cover every remaining service, and which fit the chosen priority?',
    description: 'Compare complete repairs to a disrupted published restaurant roster across every remaining service. Check coverage, qualifications, availability, capacity, rest, hours and remaining payroll; optionally compare passing repairs by stability or payroll. The calculation compares supplied proposals and does not generate or publish a roster.',
    execution: { mode: 'calculation' }, dependencies: ['feasibility', 'stability', 'cost'].map(id => ({ id, app: apps[id], packageHash: apps[id].contentHash })),
    initialCase, questions, steps, conditions, brief, decisionProcess, metadata };
}
