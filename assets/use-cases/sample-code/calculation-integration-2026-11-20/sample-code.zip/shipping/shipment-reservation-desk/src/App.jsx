import React, { useId, useRef, useState } from 'react';
import { DecisionView, DecisionSummaryView, DecisionProcessView, WorkflowMapView, QuestionView, RecordsView, CommitmentReports } from '@decision-lab/react-views';
import useShipmentReview from './useShipmentReview.js';
import { formatMoney, formatTime } from './shipment.js';
import { REVIEW_STATE, SLOT_CONFIRMATION_STATUS } from './semantics.js';
import './styles.css';

function Icon({ name, size = 18 }) {
  const paths = {
    truck: (
      <>
        <path d="M3 6h11v11H3zM14 10h4l3 4v3h-7" />
        <circle cx="7" cy="18" r="2" />
        <circle cx="18" cy="18" r="2" />
      </>
    ),
    upload: <path d="M12 16V3m-5 5 5-5 5 5M4 15v6h16v-6" />,
    download: <path d="M12 3v13m-5-5 5 5 5-5M4 17v4h16v-4" />,
    arrow: <path d="m9 5 7 7-7 7M3 12h13" />,
    check: <path d="m5 12 4 4L19 6" />,
    info: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M12 11v6m0-10v1" />
      </>
    ),
    clock: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M12 7v5l3 2" />
      </>
    ),
  };

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {paths[name] ?? paths.info}
    </svg>
  );
}

function Field({ label, value, onChange, type = 'text', hint, readOnly = false, ...props }) {
  const id = useId();

  return (
    <div className={`field${readOnly ? ' field-readonly' : ''}`}>
      <label htmlFor={id}>{label}</label>
      <input
        id={id}
        type={type}
        value={value ?? ''}
        onChange={event => onChange?.(event.target.value)}
        readOnly={readOnly}
        aria-describedby={hint ? `${id}-hint` : undefined}
        {...props}
      />
      {hint && <span id={`${id}-hint`} className="field-hint">{hint}</span>}
    </div>
  );
}

function Select({ label, value, onChange, children }) {
  const id = useId();

  return (
    <div className="field">
      <label htmlFor={id}>{label}</label>
      <select id={id} value={value ?? ''} onChange={event => onChange(event.target.value)}>
        {children}
      </select>
    </div>
  );
}

function SectionHeading({ eyebrow, title, children, number, id }) {
  return (
    <div className="section-heading">
      <div>
        {eyebrow && <p className="eyebrow">{eyebrow}</p>}
        <h2 id={id}>
          {number && <span className="section-number">{number}</span>}
          {title}
        </h2>
      </div>
      {children}
    </div>
  );
}

function Issues({ issues = [], error }) {
  if (!error && !issues.length) return null;

  return (
    <div className="issues" role="alert">
      <strong>Review needs attention</strong>
      {error && <p>{error}</p>}
      {issues.length > 0 && (
        <ul>
          {issues.map((issue, index) => (
            <li key={`${issue.path}-${index}`}>
              {typeof issue === 'string' ? issue : issue.message}
              {typeof issue !== 'string' && issue.path && (
                <span className="issue-path">{issue.path}</span>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function ShipmentBasis({ caseData, config }) {
  const values = caseData.parameters;

  return (
    <section className="shipment-basis" aria-label="Shipment commitment">
      <div className="basis-identity">
        <span className="eyebrow">Current shipment</span>
        <strong>
          {values.orderId}
          <span className="revision">Revision {values.orderRevision}</span>
        </strong>
        <span>{values.recipient} · {values.quantity} units · Ship {values.shipDate}</span>
        <span className="review-as-of">As of {formatTime(values.currentTime, config)}</span>
      </div>
      <dl className="basis-facts">
        <div>
          <dt>Expense limit</dt>
          <dd>{formatMoney(values.expenseLimit, config)}</dd>
        </div>
        <div>
          <dt>Reserve by</dt>
          <dd>{formatTime(values.reservationDeadline, config)}</dd>
        </div>
        <div>
          <dt>Delivery deadline</dt>
          <dd>{formatTime(values.receiptDeadline, config)}</dd>
        </div>
      </dl>
    </section>
  );
}

function QuoteForm({ draft, editQuote, config }) {
  const [selectedId, setSelectedId] = useState('consolidated');
  const quotes = draft.quotes;
  const quote = quotes.find(row => row.id === selectedId) ?? quotes[0];
  const label = id => config.labels.arrangements[id] ?? id;
  const edit = field => value => editQuote(quote.id, field, value);

  return (
    <section className="panel record-panel" aria-labelledby="quotes-heading">
      <div className="panel-content">
        <SectionHeading id="quotes-heading" number="1" title="Freight quote">
          <span className="subtle-tag">Editable record</span>
        </SectionHeading>
        <p className="section-description">
          Update the complete quoted amount and transport details for an arrangement.
        </p>
        <div className="quote-tabs" role="group" aria-label="Arrangement to edit">
          {quotes.map(row => (
            <button
              type="button"
              key={row.id}
              aria-pressed={row.id === quote.id}
              onClick={() => setSelectedId(row.id)}
            >
              {label(row.id)}
            </button>
          ))}
        </div>
        <fieldset>
          <legend className="sr-only">{label(quote.id)} quote</legend>
          <div className="quote-context">
            <strong>{label(quote.id)}</strong>
            <span>Ship point {quote.shipPoint}</span>
          </div>
          <div className="form-grid">
            <Field
              label="Complete quote amount"
              type="number"
              value={quote.totalCost}
              onChange={edit('totalCost')}
              min="0"
              step="0.01"
              hint="All quoted shipment costs, in the currency shown."
            />
            <Select label="Quote currency" value={quote.currency} onChange={edit('currency')}>
              <option value="USD">USD — US dollar</option>
              <option value="EUR">EUR — Euro</option>
            </Select>
            <Field
              label="Departure"
              type="datetime-local"
              value={quote.departure}
              onChange={edit('departure')}
            />
            <Field
              label="Travel time (minutes)"
              type="number"
              value={quote.travelMinutes}
              onChange={edit('travelMinutes')}
              min="0"
              step="1"
            />
            <Field
              label="Shipment capacity (units)"
              type="number"
              value={quote.capacity}
              onChange={edit('capacity')}
              min="0"
              step="1"
            />
            <div className="field static-field">
              <span className="field-label">Ship point</span>
              <span>{quote.shipPoint}</span>
            </div>
            <Field label="Quote reference" value={quote.quoteId} onChange={edit('quoteId')} />
            <Field label="Quote revision" value={quote.quoteRevision} onChange={edit('quoteRevision')} />
            <Field label="Quote order" value={quote.quoteOrderId} onChange={edit('quoteOrderId')} />
            <Field label="Quote order revision" value={quote.quoteOrderRevision} onChange={edit('quoteOrderRevision')} />
          </div>
          <details className="record-details">
            <summary>Quote validity and booking cutoff</summary>
            <div className="form-grid">
              {['quoteKnownAt', 'quoteValidFrom', 'quoteValidUntil', 'bookingCutoff'].map((field, index) =>
                <Field key={field} label={['Quote known at', 'Quote valid from', 'Quote valid until (exclusive)', 'Carrier booking cutoff'][index]}
                  type="datetime-local" value={quote[field]} onChange={edit(field)} />)}
            </div>
          </details>
        </fieldset>
      </div>
      <div className="panel-footnote">
        <Icon name="info" size={16} />
        <span>Changing a quote keeps the app’s delivery, spending and permission checks in force.</span>
      </div>
    </section>
  );
}

function ConfirmationForm({ draft, editConfirmation }) {
  const record = draft.confirmation;
  const edit = field => value => editConfirmation(field, value);

  return (
    <section className="panel record-panel" aria-labelledby="confirmation-heading">
      <div className="panel-content">
        <SectionHeading id="confirmation-heading" number="2" title="Consolidation confirmation" />
        <p className="section-description">
          Record what the slot confirmation actually covers. An earlier order revision stays an earlier revision.
        </p>
        <fieldset>
          <legend className="sr-only">Consolidation confirmation record</legend>
          <div className="form-grid">
            <Select label="Confirmation status" value={record.status} onChange={edit('status')}>
              <option value={SLOT_CONFIRMATION_STATUS.NONE}>No confirmation</option>
              <option value={SLOT_CONFIRMATION_STATUS.CONFIRMED}>Confirmed</option>
              <option value={SLOT_CONFIRMATION_STATUS.CANCELLED}>Cancelled</option>
              <option value={SLOT_CONFIRMATION_STATUS.CONFLICTING}>Conflicting records</option>
            </Select>
            <Field
              label="Confirmation reference"
              value={record.slotReference}
              onChange={edit('slotReference')}
              placeholder="For example, SLOT-C104"
            />
          </div>
          <details className="record-details" open>
            <summary>Order and location covered by this record</summary>
            <div className="form-grid scope-fields">
              <Field label="Confirmation order" value={record.orderId} readOnly />
              <Field
                label="Confirmation order revision"
                value={record.orderRevision}
                onChange={edit('orderRevision')}
              />
              <Field
                label="Confirmation ship point"
                value={record.shipPoint}
                onChange={edit('shipPoint')}
              />
              <Field
                label="Confirmation destination"
                value={record.recipient}
                onChange={edit('recipient')}
              />
              <Field
                label="Confirmation ship date"
                type="date"
                value={record.shipDate}
                onChange={edit('shipDate')}
              />
              <Field label="Confirmation profile version" value={record.profileVersion} readOnly />
            </div>
          </details>
          <details className="record-details">
            <summary>Confirmation and validity times</summary>
            <div className="form-grid scope-fields">
              <Field
                label="Confirmed at"
                type="datetime-local"
                value={record.confirmedAt}
                onChange={edit('confirmedAt')}
              />
              <Field
                label="Known at"
                type="datetime-local"
                value={record.knownAt}
                onChange={edit('knownAt')}
              />
              <Field
                label="Valid from"
                type="datetime-local"
                value={record.validFrom}
                onChange={edit('validFrom')}
              />
              <Field
                label="Valid until"
                type="datetime-local"
                value={record.validUntil}
                onChange={edit('validUntil')}
              />
            </div>
          </details>
        </fieldset>
      </div>
      <div className="panel-footnote">
        <Icon name="clock" size={16} />
        <span>Times use the worked case’s fixed UTC−06:00 zone.</span>
      </div>
    </section>
  );
}

function Results({ desk }) {
  const { status, current, config, inspection } = desk;
  const [activeTab, setActiveTab] = useState('summary');
  const [supportingTab, setSupportingTab] = useState('');
  const [inspectionKey, setInspectionKey] = useState(undefined);
  const [processNavigation, setProcessNavigation] = useState({});
  const [dependencyNavigation, setDependencyNavigation] = useState({});
  const [reportNavigation, setReportNavigation] = useState({});
  const [sectionId, setSectionId] = useState(null);
  const [returnToDependencies, setReturnToDependencies] = useState(false);
  const complete = status === REVIEW_STATE.COMPLETE && current?.available;
  const running = status === REVIEW_STATE.RUNNING;
  const output = inspection?.output;
  const tabs = desk.journey?.definition.metadata?.presentation?.report?.tabs ?? [];
  const selectedTab = tabs.find(tab => tab.id === supportingTab) ?? tabs[0];
  const selectedView = output?.questionViews?.find(view => view.id === selectedTab?.viewId);
  const section = output?.brief?.sections.find(row => row.id === (sectionId ?? selectedTab?.sectionId));
  const display = output?.decisionSummary?.displayContext ?? {};
  const rowValues = selectedTab?.rowsPath ? selectedTab.rowsPath.split('.').reduce((value, key) => value?.[key], section?.value) : section?.value;
  const recordView = selectedTab?.columns?.length ? { format: 'record-view/1', id: selectedTab.id,
    title: selectedTab.label, columns: selectedTab.columns, rows: Array.isArray(rowValues) ? rowValues : [] } : null;
  function openReport(tabId, key) {
    setSupportingTab(tabId); setInspectionKey(key); setSectionId(null); setActiveTab('supporting');
  }
  function openSection(id) { setSectionId(id); setActiveTab('supporting'); }
  function openComplete() { setSectionId('complete-native-report'); setActiveTab('supporting'); }
  const label = running ? 'Calculating' : desk.hasDraft ? 'Pending input changes' : complete ? 'Current result' : 'Ready to calculate';
  return <section className="panel results-panel" aria-labelledby="review-heading">
    <div className="panel-content">
      <SectionHeading id="review-heading" eyebrow="Decision support" title="Shipment analysis">
        <span className={`review-state ${complete ? 'review-state-complete' : ''}`}>{label}</span>
      </SectionHeading>
      <Issues issues={desk.issues} />
      <p className="section-description">Owner: {inspection?.context.owner ?? config.owner.name}. {config.policy.reason}</p>
      {desk.findingChanges?.available && desk.findingChanges.status === 'changed' && <p className="notice">
        Since the retained calculation: {[
          desk.findingChanges.findings.feasibility.changed && 'available responses changed',
          desk.findingChanges.findings.preference.changed && 'the preferred response changed',
          desk.findingChanges.findings.blockers.changed && 'required follow-up changed',
        ].filter(Boolean).join('; ') || 'the recorded basis changed'}.
      </p>}
      {desk.legacy ? <div className="notice" role="status">
        <p>This saved review retains its original reviewed workflow and history. New calculation controls apply to new analyses.</p>
        <button className="button button-secondary" onClick={desk.startNewAnalysis}>Start a new analysis from these inputs</button>
      </div> : <div className="review-actions">
        <button className="button button-primary" onClick={desk.evaluate}
          disabled={running || status === REVIEW_STATE.LOADING || !desk.draft || desk.hasDraft}>
          <Icon name="arrow" />{running ? 'Calculating…' : desk.journey?.evaluations.length ? 'Recalculate' : 'Calculate'}
        </button>
        {running && <button className="button button-secondary" onClick={desk.cancel}>Cancel calculation</button>}
      </div>}
      {desk.hasDraft && <div className="notice" role="status"><strong>Pending input changes.</strong> Apply or discard the edits before calculating. Reports describe the last applied inputs.</div>}
    </div>
    <nav className="analysis-tabs" aria-label="Workflow reports">
      {[[ 'summary', 'Decision summary' ], [ 'supporting', 'Supporting reports' ],
        ...(output?.decisionProcess ? [['process', 'Decision process']] : [])].map(([id, label]) =>
        <button type="button" key={id} aria-current={activeTab === id ? 'page' : undefined} onClick={() => setActiveTab(id)}>{label}</button>)}
    </nav>
    {activeTab === 'summary' && (desk.legacy ? desk.run && <DecisionView report={desk.run.report} profile={config.decisionPresentation} />
      : !desk.hasDraft && status !== REVIEW_STATE.INVALID && <DecisionSummaryView
          summary={output?.decisionSummary}
          onOpenReport={openReport}
          onViewProcess={() => setActiveTab('process')}
        />)}
    {activeTab === 'supporting' && <div className="supporting-content">
      {returnToDependencies && <button className="text-button" onClick={() => { setActiveTab('dependencies'); setReturnToDependencies(false); }}>Return to calculation dependencies</button>}
      <nav className="analysis-tabs" aria-label="Supporting report questions">
        {tabs.map(tab => <button key={tab.id} type="button" aria-current={!sectionId && selectedTab?.id === tab.id ? 'page' : undefined}
          onClick={() => { setSupportingTab(tab.id); setSectionId(null); }}>{tab.label}</button>)}
        {desk.run && <button type="button" onClick={openComplete}>Complete calculation</button>}
      </nav>
      {sectionId === 'complete-native-report' ? <CommitmentReports report={desk.run?.report} navigation={reportNavigation} onNavigate={setReportNavigation} stale={!complete} />
        : selectedView && !sectionId ? <QuestionView view={selectedView} inspectionKey={inspectionKey} onInspectionChange={setInspectionKey} context={display} />
          : recordView && !sectionId ? <RecordsView view={recordView} context={display} />
            : section ? <div className="retained-section"><h3>{section.title}</h3><RecordsView view={{ format: 'record-view/1', id: section.id, columns: Object.keys(section.value ?? {}).map(key => ({ key, label: key })), rows: [section.value] }} context={display} /></div>
              : <p className="section-description">Calculate the applied inputs to populate the supporting reports.</p>}
    </div>}
    {activeTab === 'process' && <div className="supporting-content">
      <DecisionProcessView process={output?.decisionProcess} navigation={processNavigation} onNavigate={setProcessNavigation}
        onOpenInput={() => document.getElementById('quotes-heading')?.scrollIntoView({ behavior: 'smooth' })}
        onOpenStep={openComplete} onOpenOutput={openSection} />
      <button className="text-button" onClick={() => setActiveTab('dependencies')}>Inspect calculation dependencies</button>
    </div>}
    {activeTab === 'dependencies' && <div className="supporting-content">
      <h3>Calculation dependencies</h3>
      <WorkflowMapView map={output?.workflowMap} navigation={dependencyNavigation} onNavigate={setDependencyNavigation}
        onOpenInput={() => document.getElementById('quotes-heading')?.scrollIntoView({ behavior: 'smooth' })}
        onOpenStep={() => { setReturnToDependencies(true); openComplete(); }} onOpenOutput={openSection} />
      <button className="text-button" onClick={() => setActiveTab('process')}>Return to decision process</button>
    </div>}
    {desk.before && <details className="previous-review"><summary>Last calculated proposal</summary>
      <p>Earlier inputs, retained for comparison. This finding does not describe pending or changed inputs.</p>
      <DecisionView report={(desk.previousRun ?? desk.run)?.report} profile={config.decisionPresentation} stale />
    </details>}
    <div className="result-boundary"><Icon name="info" size={17} /><p>This calculation supports a proposal. Choosing a response, obtaining authority and recording actual shipment events remain separate.</p></div>
  </section>;
}

function ReplacementRecord({ desk }) {
  const [record, setRecord] = useState({ kind: 'reservation', arrangement: 'consolidated', reference: '',
    orderId: '', orderRevision: '', recipient: '', shipDate: '', profileVersion: '', actor: '',
    shipPoint: '', start: '', end: '', registered: '' });
  const edit = field => value => setRecord(current => ({ ...current, [field]: value }));
  return <details className="panel record-panel"><summary className="supporting-record-toggle">Add a received permission or registration record</summary><div className="panel-content">
    <SectionHeading number="3" title="Received supporting record" />
    <p>Record an actual replacement. Its scope and validity come from the received document; requesting it does not satisfy a requirement.</p>
    <div className="form-grid">
      <Select label="Record type" value={record.kind} onChange={edit('kind')}>
        <option value="reservation">Reservation permission</option><option value="release">Final release grant</option>
        <option value="readiness">Transportation registration</option>
      </Select>
      <Select label="Arrangement" value={record.arrangement} onChange={edit('arrangement')}>
        {desk.draft.quotes.map(quote => <option key={quote.id} value={quote.id}>{desk.config.labels.arrangements[quote.id]}</option>)}
      </Select>
      <Field label="Source record reference" value={record.reference} onChange={edit('reference')} />
      <Field label="Order covered" value={record.orderId} onChange={edit('orderId')} />
      <Field label="Order revision covered" value={record.orderRevision} onChange={edit('orderRevision')} />
      <Field label="Ship point covered" value={record.shipPoint} onChange={edit('shipPoint')} />
      <Field label="Destination covered" value={record.recipient} onChange={edit('recipient')} />
      <Field label="Shipment date covered" type="date" value={record.shipDate} onChange={edit('shipDate')} />
      <Field label="Profile version covered" value={record.profileVersion} onChange={edit('profileVersion')} />
      {record.kind === 'release' && <Field label="Release officer covered" value={record.actor} onChange={edit('actor')} />}
      {record.kind !== 'readiness' && <>
        <Field label="Permission valid from" type="datetime-local" value={record.start} onChange={edit('start')} />
        <Field label="Permission valid until" type="datetime-local" value={record.end} onChange={edit('end')} />
      </>}
      {record.kind === 'readiness' && <Select label="Registration recorded" value={record.registered} onChange={edit('registered')}>
        <option value="">Choose the supplied finding</option><option value="true">Registered</option><option value="false">Not registered</option></Select>}
    </div>
    <button className="button button-secondary" onClick={() => desk.addSupportingRecord(record)}>Add received record for review</button>
  </div></details>;
}

function OperatingReview({ desk }) {
  const [actor, setActor] = useState(desk.config.owner.name);
  const [optionId, setOptionId] = useState('');
  const [kind, setKind] = useState('reservation');
  const [reference, setReference] = useState('');
  const [note, setNote] = useState('');
  const [eventScope, setEventScope] = useState({ orderId: '', orderRevision: '', arrangement: '',
    recipient: '', shipDate: '', profileVersion: '', shipPoint: '', source: '', amount: '', authorizedAt: '',
    reservedAt: '', deliveredAt: '', quoteId: '', quoteRevision: '', quantity: '', bookingReference: '', result: '' });
  const inspection = desk.inspection;
  if (!inspection) return null;
  const operatingStatus = inspection.output.brief.sections.find(row => row.id === 'actual-shipment')?.value;
  const actionWindows = inspection.output.brief.sections.find(row => row.id === 'next-work')?.value ?? [];
  return <section className="panel"><div className="panel-content">
    <SectionHeading title="Decision and operating handoff" />
    <p>Owner: {inspection.context?.owner ?? desk.config.owner.name}. {desk.config.policy.reason}</p>
    <details className="record-details"><summary>Response action windows</summary><ul>
      {actionWindows.map(window => <li key={window.arrangement}>{desk.config.labels.arrangements[window.arrangement]}:
        {' '}latest modeled selection/preparation start {formatTime(window.dueMinute, desk.config)}; {window.remainingMinutes} minutes remaining.</li>)}
    </ul><p className="field-hint">{actionWindows[0]?.meaning}</p></details>
    {desk.current && desk.config.operatingActions.flatMap(action => desk.current.plans
      .filter(plan => plan.blockers.some(blocker => blocker.id === action.when))
      .map(plan => ({ action, plan }))).map(({ action, plan }) => <p key={`${action.id}-${plan.id}`}>
      <strong>{plan.label}: {action.owner}</strong> — {action.action}<br />
      {action.closesWith} Latest modeled selection/preparation start: {formatTime(actionWindows.find(row => row.arrangement === plan.arrangementId).dueMinute, desk.config)}.
    </p>)}
    <Field label="Person recording the operating response" value={actor} onChange={setActor} hint="Records responsibility for a choice or received event; this field does not authenticate identity." />
    {desk.current?.plans.some(plan => plan.feasible) && <>
      <Select label="Arrangement to hand off" value={desk.current.plans.some(plan => plan.feasible && plan.arrangementId === optionId) ? optionId : ''} onChange={setOptionId}>
        <option value="">Choose a supported arrangement</option>
        {desk.current.plans.filter(plan => plan.feasible).map(plan => <option key={plan.id} value={plan.arrangementId}>{plan.label}</option>)}
      </Select>
      <button className="button button-primary" disabled={!desk.current.plans.some(plan => plan.feasible && plan.arrangementId === optionId)} onClick={() => desk.recordDecision(optionId, actor)}>Record chosen response</button>
    </>}
    {inspection.decision && <p><strong>Recorded response:</strong> {inspection.decision.optionId ?? inspection.decision.planId}. This records a choice, not a carrier booking.</p>}
    {inspection.staleDecision && <p role="status">The earlier operating decision needs reassessment because its basis changed.</p>}
    <details className="record-details"><summary>Record an actual operating event or escalation</summary>
      <Select label="Event" value={kind} onChange={setKind}>
        <option value="authorization">External authority received</option><option value="reservation">Carrier reservation received</option>
        <option value="handoff">Operating handoff recorded</option><option value="delivery">Delivery evidence received</option>
        <option value="escalation">Escalate the commitment</option>
      </Select>
      <Field label="External source reference" value={reference} onChange={setReference} />
      <Field label="Source of the received document" value={eventScope.source}
        onChange={value => setEventScope(current => ({ ...current, source: value }))} />
      <Field label="What the record establishes" value={note} onChange={setNote} />
      {kind !== 'escalation' && <>
        <p>Current recorded response: {inspection.decision?.choices?.arrangement ?? 'Choose a current supported response first'}. Enter the event document’s actual scope.</p>
        {['orderId', 'orderRevision', 'arrangement', 'recipient', 'shipDate', 'profileVersion', 'shipPoint'].map((field,index) => <Field key={field}
          label={['Event order', 'Event order revision', 'Event arrangement', 'Event destination', 'Event shipment date', 'Event profile version', 'Event ship point'][index]} value={eventScope[field]}
          onChange={value => setEventScope(current => ({ ...current, [field]: value }))} />)}
        {['authorization', 'reservation', 'delivery'].includes(kind) && <Select label="Document records a successful result"
          value={eventScope.result} onChange={value => setEventScope(current => ({ ...current, result: value }))}>
          <option value="">Choose what the document says</option><option value="true">Yes</option><option value="false">No</option>
        </Select>}
        {(kind === 'authorization' ? ['amount', 'authorizedAt', 'validFrom', 'validUntil'] : kind === 'reservation'
          ? ['quoteId', 'quoteRevision', 'reservedAt'] : kind === 'delivery' ? ['quantity', 'bookingReference', 'deliveredAt'] : []).map(field => <Field
          key={field} label={{ amount: 'Authorized amount (USD)', authorizedAt: 'Actual authorization time', quoteId: 'Booked quote reference',
            validFrom: 'Authority valid from', validUntil: 'Authority valid until (exclusive)',
            quoteRevision: 'Booked quote revision', reservedAt: 'Actual carrier reservation time', quantity: 'Actual received quantity',
            bookingReference: 'Carrier reservation reference', deliveredAt: 'Actual accepted delivery time' }[field]}
          type={field.endsWith('At') || ['validFrom','validUntil'].includes(field) ? 'datetime-local' : 'text'} value={eventScope[field]}
          onChange={value => setEventScope(current => ({ ...current, [field]: value }))} />)}
      </>}
      <button className="button button-secondary" onClick={() => desk.recordOperation(kind, { reference, note, ...eventScope }, actor)}>Record received event</button>
    </details>
    {inspection.operations?.length > 0 && <ul>{inspection.operations.map((event,index) =>
      <li key={index}>{event.kind}: {event.record?.reference ?? event.reference} — {event.record?.note ?? event.note}</li>)}</ul>}
    {operatingStatus && desk.status === REVIEW_STATE.COMPLETE && <table><caption>Authored operating checks</caption><tbody>
      <tr><th scope="row">Current sourced authorization</th><td>{operatingStatus.authorizationRecorded ? 'Recorded support passes' : 'Not established'}</td></tr>
      <tr><th scope="row">Current sourced carrier reservation</th><td>{operatingStatus.reservationRecorded ? 'Recorded support passes' : 'Not established'}</td></tr>
      <tr><th scope="row">Original delivery commitment completed</th><td>{operatingStatus.originalCommitmentCompleted ? 'Recorded support passes' : 'Not established'}</td></tr>
      {operatingStatus.promiseRevised && <tr><th scope="row">Delivery under revised terms</th><td>{operatingStatus.currentCommitmentCompleted ? 'Recorded support passes; original promise remains separate' : 'Not established'}</td></tr>}
      <tr><th scope="row">Escalation recorded</th><td>{operatingStatus.escalationRecorded ? 'Recorded' : 'None recorded'}</td></tr>
    </tbody></table>}
    <p className="field-hint">Recorded assertions do not authenticate authority. A reservation is not delivery, and a revised customer promise is not fulfillment of the original promise.</p>
    <button className="button button-secondary" onClick={desk.downloadJourney}>Download continuation</button>
    <button className="button button-secondary" onClick={desk.saveJourney}>Save this review locally</button>
  </div></section>;
}

export default function App() {
  const desk = useShipmentReview();
  const fileInput = useRef(null);
  const [importError, setImportError] = useState(null);
  const loading = desk.status === REVIEW_STATE.LOADING;
  const canDownload = desk.status === REVIEW_STATE.COMPLETE && desk.current?.available && desk.run;

  async function importFile(event) {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;
    setImportError(null);

    try {
      await desk.importCaseText(await file.text());
    } catch (error) {
      setImportError(error.message ?? 'The case could not be imported.');
    }
  }

  return (
    <div className="desk-app">
      <a className="skip-link" href="#main">Skip to shipment review</a>
      <header className="site-header">
        <div className="header-inner">
          <div className="brand-mark"><Icon name="truck" size={22} /></div>
          <div className="brand-name">
            Shipment Reservation Desk
            <span>Team application · Powered by Decision Lab SDK</span>
          </div>
          <span className="demo-badge">Fictional worked example</span>
        </div>
      </header>
      <main id="main" className="page-shell">
        <div className="page-intro">
          <div>
            <p className="eyebrow">A focused logistics workspace</p>
            <h1>
              Choose the arrangement.<br className="mobile-break" /> Keep the evidence in view.
            </h1>
            <p>
              Review one shipment’s quotes and confirmation before putting an
              arrangement forward for reservation.
            </p>
          </div>
          <div className="top-actions">
            <button
              className="button button-secondary"
              onClick={() => fileInput.current.click()}
              disabled={loading}
            >
              <Icon name="upload" />Import case
            </button>
            <button
              className="button button-secondary"
              onClick={desk.downloadRun}
              disabled={!canDownload}
            >
              <Icon name="download" />Download SDK run
            </button>
            <input
              ref={fileInput}
              type="file"
              className="sr-only"
              accept=".json,application/json"
              aria-label="Import canonical case JSON"
              onChange={importFile}
            />
          </div>
        </div>
        <section className="sample-section" aria-labelledby="sample-heading">
          <div className="sample-heading">
            <h2 id="sample-heading">Try a worked case</h2>
            <span>Same app rules. Different records.</span>
          </div>
          <div className="sample-cards">
            {desk.cases.map((item, index) => (
              <button
                type="button"
                className={`sample-card ${item.id === desk.selectedCaseId ? 'sample-selected' : ''}`}
                key={item.id}
                aria-pressed={item.id === desk.selectedCaseId}
                disabled={loading}
                onClick={() => {
                  setImportError(null);
                  desk.selectCase(item.id);
                }}
              >
                <span className="sample-index">0{index + 1}</span>
                <span>
                  <strong>{item.label}</strong>
                  <span>{item.description}</span>
                </span>
                {item.id === desk.selectedCaseId && <Icon name="check" size={17} />}
              </button>
            ))}
          </div>
        </section>
        <Issues error={importError} issues={!desk.caseData ? desk.issues : []} />
        {loading ? (
          <div className="loading-state" role="status">Loading the pinned shipment app…</div>
        ) : desk.caseData && desk.draft ? (
          <>
            <ShipmentBasis caseData={desk.caseData} config={desk.config} />
            <section className="panel"><div className="panel-content form-grid">
              <div className="review-actions">
                <button className="button button-primary" onClick={desk.applyInputs} disabled={!desk.hasDraft || loading || desk.legacy}>Apply inputs</button>
                <button className="button button-secondary" onClick={desk.discardInputs} disabled={!desk.hasDraft || loading}>Discard edits</button>
                <span className="field-hint">Forms retain a draft until you apply it. Calculate uses the applied case.</span>
              </div>
              <Field label="Assessment as of" type="datetime-local" value={desk.draft.asOf} onChange={desk.editAsOf}
                hint="Advance this time to reassess an unchanged quote or permission. Artifact creation time does not advance the case." />
              <button className="button button-secondary" onClick={desk.restoreJourney}>Restore saved review</button>
            </div></section>
            <div className="desk-layout">
              <div className="input-column">
                <QuoteForm
                  key={desk.selectedCaseId}
                  draft={desk.draft}
                  editQuote={desk.editQuote}
                  config={desk.config}
                />
                <ConfirmationForm draft={desk.draft} editConfirmation={desk.editConfirmation} />
                <ReplacementRecord desk={desk} />
                <div className="input-footer">
                  <button
                    className="text-button"
                    onClick={desk.downloadCase}
                    disabled={desk.status === REVIEW_STATE.RUNNING}
                  >
                    <Icon name="download" size={16} />Download case inputs
                  </button>
                  <span>
                    Complete resources and permission records remain in the imported
                    case. Apply edits before recalculating; supplying facts does not grant operating authority.
                  </span>
                </div>
              </div>
              <div className="review-column"><Results desk={desk} /><OperatingReview desk={desk} /></div>
            </div>
          </>
        ) : (
          <div className="loading-state">
            {desk.issues.length
              ? 'Correct the issue above and try again.'
              : 'Select or import a shipment case to start.'}
          </div>
        )}
        <footer className="page-footer">
          <span>One shipment · Independent arrangement review</span>
          <span>Fictional data. No freight is booked.</span>
        </footer>
      </main>
    </div>
  );
}
